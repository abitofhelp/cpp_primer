// main.cpp - Composition root for the RS-485 <-> USB RawHID bridge firmware.
//
// Owns every concrete adapter (RS-485 PHY, line codec, USB transport, board
// platform) and wires them into the templated BridgeController. setup() does the
// hardware bring-up; loop() pumps the bridge. All wiring lives here so the
// composition root is explicit and the controller stays hardware-free.
//
// USB type must be set to Raw HID (PlatformIO: -D USB_RAWHID; Arduino IDE:
// Tools -> USB Type -> Raw HID). See README.md.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include <Arduino.h>

#include "BridgeController.hpp"
#include "PadilLineCodec.hpp"
#include "Rs485Phy.hpp"
#include "TeensyPlatform.hpp"
#include "UsbTransport.hpp"

namespace {

// Concrete adapters (the composition root owns them).
bridge::rs485::Rs485Phy g_phy;
bridge::padil::PadilLineCodec g_codec;
bridge::usb::UsbTransport g_usb;
bridge::platform::TeensyPlatform g_platform;

// The controller binds to the adapters by reference (CTAD via deduction guide).
bridge::app::BridgeController g_bridge{g_usb, g_codec, g_platform};

}  // namespace

auto setup() -> void {
  g_platform.begin();      // Board pins: status/transfer/error LEDs, all forced off.
  g_phy.begin();           // RS-485 pins; enters receive mode.
  g_codec.begin(g_phy);    // DWT, edge ISR, default speed.
  g_usb.begin();           // RawHID endpoint.
  g_bridge.begin();        // Service-timer baselines.
}

auto loop() -> void { g_bridge.poll(); }
