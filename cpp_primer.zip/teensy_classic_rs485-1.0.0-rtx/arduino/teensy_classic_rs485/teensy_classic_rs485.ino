// teensy_classic_rs485.ino - Arduino CLI composition root for the RS-485 <-> USB
// RawHID bridge.
//
// This is a THIN composition root, intentionally identical in structure to the
// PlatformIO root (../../src/main.cpp): it owns the concrete adapters and wires
// them into the templated BridgeController. It contains NO bridge implementation
// of its own - the behavior lives once, canonically, in the TeensyRs485Bridge
// library (../../lib/TeensyRs485Bridge), which both frontends compile.
//
// Build/upload it with the Arduino CLI via the Makefile:
//   make arduino-build     # compile with GNU C++20 against the canonical library
//   make arduino-upload    # build + flash the connected Teensy 4.1
// The Makefile selects USB Raw HID via `--board-options usb=rawhid` and passes
// the repository-local library with `--library lib/TeensyRs485Bridge` plus the
// required GNU C++20 build flags (Arduino/Teensyduino defaults to C++17).
//
// NOTE: Arduino IDE support is intentionally NOT provided; this sketch is built
// and validated through the Arduino CLI only (see docs/BUILD.md).
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include <Arduino.h>

// Canonical implementation, from the TeensyRs485Bridge library (shared with the
// PlatformIO root).
#include <BridgeController.hpp>
#include <PadilLineCodec.hpp>
#include <Rs485Phy.hpp>
#include <TeensyPlatform.hpp>
#include <UsbTransport.hpp>

namespace {

// Concrete adapters (the composition root owns them).
bridge::rs485::Rs485Phy g_phy;
bridge::padil::PadilLineCodec g_codec;
bridge::usb::UsbTransport g_usb;
bridge::platform::TeensyPlatform g_platform;

// The controller binds to the adapters by reference (CTAD via deduction guide).
bridge::app::BridgeController g_bridge{g_usb, g_codec, g_platform};

}  // namespace

void setup() {
  g_platform.begin();      // Board pins: status/transfer/error LEDs, all forced off.
  g_phy.begin();           // RS-485 pins; enters receive mode.
  g_codec.begin(g_phy);    // DWT, edge ISR, default speed.
  g_usb.begin();           // RawHID endpoint.
  g_bridge.begin();        // Service-timer baselines.
}

void loop() { g_bridge.poll(); }
