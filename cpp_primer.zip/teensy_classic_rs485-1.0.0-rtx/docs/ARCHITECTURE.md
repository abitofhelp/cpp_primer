# Architecture

RTX/Raytheon, Michael Gardner.

Firmware that bridges a half-duplex **RS-485-side timed PADIL protocol** to a host
over **USB RawHID**, on a hexagonal (ports & adapters) / DDD / Clean hybrid in
C++20. This document is the module map and — most importantly — the **execution-context
ownership map** for the shared state that crosses the ISR / timer / main boundary.

## Layers

```
Composition root   src/main.cpp  (PlatformIO)   arduino/.../*.ino  (Arduino CLI)
                     owns the adapters, wires the bridge, runs the loop
        │
Application        BridgeController<Usb, Line, Platform>   (header-only template)
        │            ACK policy, backpressure, numbering, LEDs, status  ← host-tested
        │            depends on ports as C++20 concepts (Ports.hpp), not concretes
        ├───────────── UsbPort ────── UsbTransport   RawHID send/recv (only usb_rawhid_* caller)
        │                              └ UsbProtocol  frame codec (encode/decode)  ← host-tested
        ├───────────── LinePort ───── PadilLineCodec hardware glue: edge ISR, DWT, IntervalTimer TX
        │                              └ PadilBitLayer differential-Manchester bit logic  ← host-tested
        │                              └ Rs485Phy      DE//RE direction + raw pin I/O
        └───────────── PlatformPort ─ TeensyPlatform micros, LEDs, CPU temperature
Kernel             Core.hpp  Result / Option / FixedQueue (SPSC ring)   ← host-tested
Domain             Domain.hpp  PadilMessage, UsbFrame, Outbound/Hostbound, AdapterStatus
Config             Config.hpp  pins, timing, queue sizes, service periods, line code
```

The bridge and everything under the kernel/domain are **Arduino-free** and unit-tested
on the host through fake ports. Only the concrete adapters and the composition roots
touch the Teensy core.

## Ports (contracts)

`Ports.hpp` defines the three concepts (`UsbPort`, `LinePort`, `PlatformPort`) that
`BridgeController` requires. They are **exact and `noexcept`**: methods must be
`noexcept` (the controller is `noexcept` end to end — a throwing adapter would call
`std::terminate()`) and return the exact type (not merely convertible). Positive and
negative `static_assert`s in `Ports.hpp` pin the semantics.

## Error handling

The firmware uses **functional error handling**, not exceptions: fallible
operations return `core::Result<T, E>` (a success value or a typed error) or
`core::Option<T>` (a value or nothing), and the build disables exceptions and RTTI
(`-fno-exceptions -fno-rtti`). The whole firmware, including the ports, is
`noexcept`. This is chosen for **traceability** (every error is an explicit,
`[[nodiscard]]`-checked value, not an invisible unwind path), **determinism** (no
variable-latency unwinding on the ~4 µs ISR path), and **footprint** (no unwind
tables/RTTI on a constrained MCU). [`ERROR_HANDLING.md`](ERROR_HANDLING.md) is the
developer's guide to the model — the layered boundary rule, why there is no
`try`/`catch` even at the boundary, the adapter outcome-mapping table, and how to
extend it; the decision, options, and validation gate are in
[`decisions/`](decisions/), ADR-8.

## Execution contexts

Three contexts run concurrently on the single Cortex-M7 core:

- **main** — the `loop()` calling `BridgeController::poll()`.
- **GPIO edge ISR** — `PadilLineCodec::on_edge_isr()`, fired on every RX pin change.
- **TX timer ISR** — `PadilLineCodec::on_tx_tick()`, fired by `IntervalTimer` every
  half bit-cell while transmitting.

## Shared-state ownership map

| State | Writer(s) | Reader(s) | Mechanism |
|---|---|---|---|
| `FixedQueue::head_` (`edge_queue_`) | GPIO edge ISR (producer) | main `poll()` | `std::atomic` **release** on publish / **acquire** on read (ADR-1) |
| `FixedQueue::tail_` (`edge_queue_`) | main `poll()` (consumer) | GPIO edge ISR | `std::atomic` release/acquire (ADR-1) |
| tx / rx / to-host `FixedQueue`s | main | main | same atomic type; main-context only today |
| `Rs485Phy::transmitting_` | main + TX timer ISR | GPIO edge ISR + main | `std::atomic<bool>` + explicit `dmb` DE sequencing (ADR-2) |
| `PadilLineCodec::edge_overflows_` | GPIO edge ISR | main | `std::atomic<uint32_t>` `fetch_add(relaxed)` (ADR-2) |
| `PadilLineCodec::tx_state_` | main (`begin_transmit`/`poll`) + TX timer ISR (`finish_transmit`) | main + timer | `std::atomic<TxState>` `Idle→Active→CleanupPending→Idle` (ADR-7) |
| `tx_slot_`, `tx_buffer_`, `tx_current_level_` | main **before** `IntervalTimer.begin()`, then TX timer ISR | TX timer ISR | non-atomic, **lifecycle-owned** (ADR-3) |
| `have_prev_edge_`, decoder state | main `poll()` only | main | plain (single-context) |

## Two critical orderings

1. **Self-reception suppression (ADR-2).** Entering TX publishes `transmitting_`
   **before** enabling the driver; leaving TX disables the driver **before** clearing
   `transmitting_`. An explicit `dmb` orders the normal-memory flag against the DE//RE
   MMIO writes, so the edge ISR never decodes the adapter's own transmitted edges.

2. **TX completion cleanup (ADR-7).** `finish_transmit()` (timer ISR) moves the state
   to `CleanupPending` only after the bus is back in receive; `begin_transmit()` (main)
   refuses any non-`Idle` state; `poll()` (main, run before the transmit service in the
   same cycle) resets the decoder and publishes `Idle`. The next transmission therefore
   cannot start until the prior one's decoder cleanup has run.

See [`docs/decisions/`](decisions/) for the full ADRs, options, and validation gates.
