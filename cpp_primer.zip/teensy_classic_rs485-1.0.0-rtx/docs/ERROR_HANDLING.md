# Error Handling

RTX/Raytheon, Michael Gardner.

How this firmware reports and handles failure. The short version: **errors are
values, not exceptions.** Fallible operations return `core::Result<T, E>` (a
success value or a typed error) and optional values return `core::Option<T>` (a
value or nothing). Exceptions and RTTI are disabled at the compiler
(`-fno-exceptions -fno-rtti`), and the whole firmware — controller, adapters, and
ports — is `noexcept` end to end.

## Philosophy

The software follows the **functional-programming error-handling paradigm**:
failure is modeled as **data returned from a function**, not as a control-flow
event thrown out of it. A function that can fail says so *in its own type* — it
returns `Result<T, E>` — and a function whose answer may legitimately be absent
returns `Option<T>`. There is no separate, invisible channel (exceptions,
`errno`, sentinel return codes) down which failure can travel unannounced. This
is the same discipline found in Rust's `Result`/`Option`, Haskell's
`Either`/`Maybe`, and the Result monad used across the wider codebase family; we
adopt it here deliberately, for concrete engineering reasons:

- **Honesty in the type system.** The signature is the contract. If a function
  returns `Result`, the caller *cannot* pretend it always succeeds — the failure
  case is a value they must inspect. `[[nodiscard]]` makes ignoring it a compiler
  warning. Nothing can fail silently and nothing can fail *invisibly*.
- **Traceability.** Every error travels the normal return path, in the open. The
  full set of things that can go wrong is visible by reading the function
  signatures — to a reviewer, to static analysis, and to the next developer — with
  no hidden `throw` three call-levels down that unwinds past code that looks total.
- **Determinism on a real-time path.** Exception unwinding has variable,
  data-dependent latency and no fixed cost. On the GPIO-edge and TX-timer paths,
  where the half-bit-cell budget is on the order of **4 µs**, that is
  unacceptable. Returning a value is straight-line, constant-shape control flow
  the compiler and the reader can both predict.
- **Footprint and fit for the target.** `-fno-exceptions -fno-rtti` removes the
  unwind tables and RTTI metadata from the image and drops the exception runtime
  entirely — a smaller, simpler binary on a constrained MCU, with one fewer
  runtime subsystem to reason about.
- **Composability.** Because errors are ordinary values, they compose with
  ordinary code — checked at the call site, forwarded, counted, or mapped to a
  status the host can see — without the special-case machinery a thrown exception
  demands.
- **Explicit absence vs. failure.** Functional style insists these are different
  questions. "No temperature sensor fitted" and "the read failed" are not the same
  event; `Option<T>` says *absent*, `Result<T, E>` says *failed with this reason*,
  and the code never conflates them behind a null or a magic value.

The rest of this document is the working guide: the layered model that puts this
paradigm into practice, the one place it adapts to bare-metal reality, and how to
extend it. This is a runtime-affecting design decision — the **decision itself,
the options weighed, and the validation gate** live in [`decisions/`](decisions/)
as **ADR-8**.

---

## The layered model

The codebase is a hexagonal (ports & adapters) / DDD / Clean hybrid, and error
handling follows the layering:

```
   ┌─────────────────────────────────────────────────────────────┐
   │  Composition root  (src/main.cpp, arduino/.../*.ino)          │
   │     wires adapters, runs loop()                               │
   ├─────────────────────────────────────────────────────────────┤
   │  CORE  (Arduino-free, host-tested)                            │
   │     BridgeController, Core.hpp, Domain.hpp, UsbProtocol       │
   │     → NEVER throws, NEVER catches. Result / Option only.      │
   ├─────────────────────────────────────────────────────────────┤
   │  BOUNDARY ADAPTERS  (touch the Teensy core)                   │
   │     UsbTransport, Rs485Phy, PadilLineCodec, TeensyPlatform    │
   │     → map hardware outcomes to Result / Option for the core   │
   ├─────────────────────────────────────────────────────────────┤
   │  THE OUTSIDE WORLD  (Teensy core / hardware registers)        │
   │     usb_rawhid_*, digitalWriteFast, micros, IntervalTimer, …  │
   └─────────────────────────────────────────────────────────────┘
```

**The rule:** the outside world may fail in messy, external ways; the **boundary
adapters** are the only place that talks to it, and they translate every outcome
into a typed value before it crosses into the core. The core then handles only
explicit, checked values — it has no `try`, no `catch`, no `throw`, and no hidden
unwind path. If a failure ever reached the core as anything other than a value, it
would be a bug in an adapter, not something the core is expected to cope with.

This is the same "exceptions only at the boundary; the core speaks Result/Option"
model used across the wider codebase family. The one thing that is specific to
*this* project is what the boundary actually is — see the next section.

---

## Why there is no `try`/`catch` anywhere (not even at the boundary)

In a desktop or server build, the boundary layer typically wraps
exception-throwing calls (`std::cout`, a database client, an HTTP library) in a
catch-and-convert helper — the C++ equivalent of a `try → Result` shim — so a
thrown `std::exception` becomes an `Err` value. Those builds compile the
infrastructure files with exceptions **enabled** for exactly that reason.

**This firmware's boundary cannot throw.** The outside world here is the Teensy
core: `usb_rawhid_send()`, `usb_rawhid_recv()`, `digitalWriteFast()`, `micros()`,
`IntervalTimer`, `tempmonGetTemp()`. Every one of them is a `noexcept` C-linkage
function that reports failure by **return value or absence**, never by raising a
C++ exception. There is nothing to catch.

So the "catch exceptions at the boundary" requirement is satisfied *vacuously*, and
the adapters do the other half of the same contract — **map the hardware outcome
to a value**:

| Adapter | Boundary call | Failure signal | Mapped to |
|---|---|---|---|
| `UsbTransport::send` | `usb_rawhid_send` returns a byte count | count ≠ 64 (timeout / backpressure) | `bool` (caller counts the drop) |
| `UsbTransport::recv` | `usb_rawhid_recv` returns a byte count | count ≠ 64 (nothing waiting) | `bool` |
| `TeensyPlatform::cpu_temp_tenths` | `tempmonGetTemp` may be unavailable | monitor absent | `core::Option<int32_t>` (`some`/`none`) |
| `UsbProtocol::decode_host_frame` | raw 64 bytes from the host | malformed frame | `core::Result<HostFrame, DecodeError>` |
| `Rs485Phy`, `PadilLineCodec` | pin I/O, DE//RE, ISR edge capture, timer TX | n/a — no failure to report | `bool` / direct effect, all `noexcept` |

Because nothing throws, the firmware compiles under a **single** profile
(`-fno-exceptions -fno-rtti`) for *every* file, core and adapter alike — there is
no second "exceptions-enabled" profile and no catch-and-convert helper. That is the
one intended departure from the reference-library shape; it is recorded in ADR-8's
*Consequences*. A reviewer arriving from a desktop build who goes looking for a
`try_to_result`-style shim will not find one, and that is correct here.

---

## Using the types

`Result<T, E>` and `Option<T>` are defined in
[`../lib/TeensyRs485Bridge/src/Core.hpp`](../lib/TeensyRs485Bridge/src/Core.hpp).
They are allocation-free, trivially copyable, `constexpr`-friendly, and
`[[nodiscard]]` so the compiler flags an ignored result.

```cpp
// Fallible: succeeds with a value or fails with a typed error.
[[nodiscard]] auto decode_host_frame(const uint8_t* data, size_t length) noexcept
    -> core::Result<domain::HostFrame, domain::DecodeError>;

const auto r = decode_host_frame(buf, n);
if (r.is_ok()) {
  handle(r.value());        // use the HostFrame
} else {
  count_error(r.error());   // typed DecodeError, no exception unwound
}

// Optional: a value or nothing — absence is NOT an error.
const core::Option<int32_t> t = platform.cpu_temp_tenths();
const int32_t tenths = t.value_or(0);   // returns by value; safe on a temporary
```

**Choosing between them:**

- Use **`Result<T, E>`** when the operation can *fail* and the reason matters
  (a malformed frame, a rejected transmit). The caller must be able to tell *why*.
- Use **`Option<T>`** when a value is simply *absent* and that is a normal,
  reason-less outcome (no temperature sensor, an empty queue, nothing received).
- Use a plain **`bool`** only for a hot-path binary outcome where there is no error
  payload to carry (`send` accepted the frame, or it did not). This is deliberate
  on the ISR/poll path where a `Result` would be needless weight; the drop is
  counted by the caller.

---

## Adding a new fallible operation or adapter

1. **Decide where it lives.** If it touches the Teensy core / hardware, it is a
   boundary adapter. If it is pure logic over domain types, it is core.
2. **In the core**, return `Result<T, E>` or `Option<T>` and mark the function
   `noexcept`. Never `try`/`catch`/`throw` — they will not even compile under the
   core flags.
3. **In a boundary adapter**, call the hardware, inspect its return value or
   absence, and translate that outcome into a `Result`/`Option`/`bool` before
   returning. Keep the adapter `noexcept`; if you are ever tempted to call
   something that *can* throw, that call does not belong on this device — stop and
   reconsider, because the port contract forbids it (below).
4. **Add a typed error** to the relevant domain enum rather than overloading an
   existing one, so the failure surface stays legible to reviewers.
5. **Host-test it.** The core and the codecs are unit-tested on the host through
   fake ports; a new `Result`/`Option` path should come with a test.

---

## How the model is enforced

- **Compiler.** `-fno-exceptions -fno-rtti` (set in `platformio.ini` and the
  Arduino `build.flags.cpp`) makes any `throw`, `try`, `catch`, `dynamic_cast`, or
  `typeid` a hard compile error, and links the image with no exception runtime.
- **Ports.** The three port concepts in
  [`../lib/TeensyRs485Bridge/src/Ports.hpp`](../lib/TeensyRs485Bridge/src/Ports.hpp)
  require their methods to be `noexcept`. `BridgeController` is `noexcept` end to
  end, so a throwing adapter is a **compile error**, not a runtime `terminate()`.
- **Host suites.** The `Result`/`Option` paths — including `value_or` returning by
  value and the codec's `Result<HostFrame, DecodeError>` — are exercised by the
  host unit tests (`make test`).

---

## See also

- [`decisions/`](decisions/) — **ADR-8** (decision, options, rationale, gate) and
  the concurrency ADRs.
- [`ARCHITECTURE.md`](ARCHITECTURE.md) — module map, execution contexts, and the
  shared-state ownership table.
- [`../lib/TeensyRs485Bridge/src/Core.hpp`](../lib/TeensyRs485Bridge/src/Core.hpp)
  — the `Result`/`Option` implementations.
