# Build Guide

How to build, test, flash, and document this firmware. The build is intentionally
simple:

- **`platformio.ini`** is the authoritative embedded firmware build definition.
- **`Makefile`** is the developer command surface (a thin wrapper).
- **Arduino CLI** is a second, co-equal command-line frontend (`make arduino-build`)
  that compiles the same canonical `lib/TeensyRs485Bridge`. The Arduino IDE is not supported.
- **CMake is intentionally not used** in this POC.

Run `make check-tools` first to see what is installed.

---

## Required tools

| Tool | Needed for | Install |
|---|---|---|
| **PlatformIO CLI** (`pio`) | firmware build / upload / monitor | `pip install platformio` or `brew install platformio` |
| **C++20 host compiler** (`c++`/`clang++`/`g++`) | host unit tests | Xcode CLT / a system toolchain (already present on most dev machines) |
| **PlantUML** | regenerating diagrams | `brew install plantuml`, or set `PLANTUML_JAR=/path/plantuml.jar` (needs Java 11+). Optional — only needed when changing `docs/diagrams/*.puml` |
| **Typst** | building the original-POC review issue PDFs | `brew install typst` (or see https://typst.app). Optional — only needed for `make issues` |
| **Teensy USB / loader** | `burn`/`upload` | PlatformIO fetches the Teensy platform + loader on first `make build`; a Teensy 4.1 must be connected over USB to upload |

The host tests need **only** the C++20 compiler — no Teensy toolchain, no PlantUML, no Typst.

---

## Primary commands

| Command | What it does |
|---|---|
| `make check-tools` | Report which tools are found (PlatformIO, host C++, PlantUML, Typst) |
| `make test` | Build & run all host unit suites (Core, USB, PADIL, BridgeController) |
| `make build` | Compile the firmware for Teensy 4.1 (PlatformIO) |
| `make arduino-build` | Compile the firmware via Arduino CLI (RawHID) against the canonical library |
| `make arduino-upload` | Build + flash via Arduino CLI (dynamic port; override `ARDUINO_PORT=`) |
| `make build-all` | Build BOTH frontends (PlatformIO + Arduino CLI) |
| `make flash HEX=…` | Flash a prebuilt `.hex` with `teensy_loader_cli` (air-gap; no PlatformIO/network) |
| `make burn` / `make upload` | Build and flash a connected Teensy 4.1 (PlatformIO) |
| `make monitor` | Open the USB serial monitor |
| `make diagrams` | Regenerate `docs/diagrams/*.svg` from `*.puml` (PlantUML) |
| `make issues` | Compile the original-POC review issue docs to `docs/original_poc_issues/build/*.pdf` (Typst) |
| `make clean` | Remove firmware (`.pio`) and host-test (`.build-host`) artifacts |
| `make build-offline` | Build firmware using only the project-local `vendor/platformio` cache (see [Offline / restricted-network builds](#offline--restricted-network-builds)) |
| `make pio-prime` | Populate `vendor/platformio` on a connected, same-OS/arch machine |
| `make pio-bundle` | Pack `vendor/platformio` into a transferable `.tar.gz` |
| `make pio-clean-vendor` | Remove `vendor/platformio` and generated cache archives |

---

## Offline / restricted-network builds

`make build` drives PlatformIO, which on first use fetches the Teensy **platform**,
the **ARM GCC toolchain**, and the **Arduino framework** from the PlatformIO
registry. On a locked-down corporate/DoD network that fetch can fail (e.g.
`HttpClientError` / hostname not resolved) because outbound access is blocked or
must traverse a proxy. There are two supported ways through this.

> The firmware is always cross-compiled by PlatformIO's own bundled
> `arm-none-eabi-gcc` — never the host's compiler and never MSVC. So this is a
> **network** problem, not a compiler problem. The host unit tests (`make test`)
> need no network at all and work behind any proxy.

The platform is pinned in `platformio.ini` (`platform = platformio/teensy@5.2.0`)
so both paths resolve the same package versions deterministically.

### Path A — proxy + corporate CA (network reachable through a proxy)

Use this when the machine can reach the internet *through* a proxy. PlatformIO
uses Python's `requests`, so it honours the standard environment variables:

```sh
export HTTPS_PROXY=http://PROXY_HOST:PORT
export HTTP_PROXY=http://PROXY_HOST:PORT
export NO_PROXY=localhost,127.0.0.1
# If the proxy does TLS inspection with a corporate/DoD root CA, trust it or the
# TLS handshake fails even with the proxy set:
export REQUESTS_CA_BUNDLE=/path/to/corporate-root-ca.pem
export SSL_CERT_FILE=/path/to/corporate-root-ca.pem
pio settings set enable_telemetry No   # avoid blocking calls to the telemetry host
make build
```

To confirm the proxy hypothesis before configuring anything, compare a direct
fetch (expected to fail) with one through the proxy (expected to succeed):

```sh
curl -v https://api.registry.platformio.org/v3/packages                 # direct
curl -v -x http://PROXY_HOST:PORT https://api.registry.platformio.org/v3/packages
```

A certificate error on the second command means TLS inspection is in play and you
need the corporate CA (`REQUESTS_CA_BUNDLE`) above.

### Path B — air-gap / package cache (no egress at all)

Prime the cache on a **connected machine**, transfer it, and build offline:

```sh
# 1. On a connected machine of the SAME OS/architecture as the offline target:
make pio-prime      # installs the platform/toolchain/framework into vendor/platformio
                    #   and runs a verification build to prove it works
make pio-bundle     # -> teensy-pio-cache-<os>-<arch>.tar.gz

# 2. Transfer the archive to the restricted machine, then unpack into the project root:
tar -xzf teensy-pio-cache-<os>-<arch>.tar.gz     # creates vendor/platformio/

# 3. On the restricted machine:
make build-offline  # builds using only vendor/platformio - no install/update
```

`make build` also **auto-detects** `vendor/platformio`: if the directory is
present, a plain `make build` routes through it and prints
`Using project-local PlatformIO core: vendor/platformio`. `build-offline` is the
explicit, fail-loud form that *requires* the cache.

### Critical caveats

- **Cache bundles are OS/architecture-specific.** The toolchain and upload tool
  are native binaries. Prime on the **same platform family** as the target:
  - For the corporate **Windows 11** box, prime on the **Parallels Windows 11 VM**
    (MSYS2 mingw64), **not** on macOS.
  - For a Linux target, prime on Linux; for macOS, prime on macOS.
- **The bundle does not include PlatformIO Core.** The target machine still needs
  **PlatformIO Core / `pio` installed by an approved method** (e.g. Homebrew, the
  PlatformIO installer, the VS Code extension, pip, or an internally approved install
  process). The bundle supplies only the platform/toolchain/framework **packages**,
  not the `pio` executable.
- **No hard offline flag.** PlatformIO 6.1.19 has no switch that guarantees zero
  network. `build-offline` uses only the local core and does not intentionally
  install or update packages, but **true no-network behaviour must be verified by
  disconnecting the target machine or running on the restricted network.** Keeping
  `enable_telemetry No` (set automatically by `make pio-prime`) and not running
  `pio pkg update` on the closed box avoids incidental outbound calls.
- **Windows: keep the checkout on the same drive as `TEMP`.** PlatformIO unpacks
  packages with `os.path.relpath`, which fails with *"Paths don't have the same
  drive"* when the project (and its `vendor/platformio`) sit on a different drive
  than Windows `TEMP` — e.g. a checkout on a mapped/shared drive (`W:`) while `TEMP`
  is on `C:`. PlatformIO misreports this as a package-mirror failure and gives up,
  so it can look like an arch problem when it is not. Check out on the same drive as
  `TEMP` (usually `C:`). `make build`/`pio-prime`/`build-offline` print a loud
  `check-drive` warning when they detect this layout.
- `vendor/platformio/` and `teensy-pio-cache-*.tar.gz` are git-ignored and are
  rejected by the `make package` hygiene self-check, so they can never leak into a
  review ZIP or the repository.

---

## Build assumptions

- **Board:** Teensy 4.1.
- **Framework:** Arduino / Teensyduino via PlatformIO (`framework = arduino`).
- **USB type:** Raw HID (`-D USB_RAWHID` in `platformio.ini`).
- **Language:** C++20 (`-std=gnu++20`).
- **No exceptions** (`-fno-exceptions`), **no RTTI** (`-fno-rtti`) — errors are
  handled with functional `Result`/`Option` values instead; see
  [`ERROR_HANDLING.md`](ERROR_HANDLING.md) for the model and
  [`decisions/`](decisions/) ADR-8 for the decision rationale.
- **No OLED/display** code in this slice.
- **Current POC target is MAX485 hardware** (the TI THVD2450V board is a later
  physical-layer swap confined to `Rs485Phy`/pins).

---

## Host-test assumptions

- The **Arduino-free modules are host-tested**: `Core` (Result/Option/FixedQueue),
  `Domain`, `UsbProtocol` (codec), and `PadilBitLayer` (differential-Manchester
  decode + TX schedule).
- **`BridgeController` is tested through fake ports/platform** — it is a template
  over the `UsbPort` / `LinePort` / `PlatformPort` concepts, so the host tests
  substitute `FakeUsb` / `FakeLine` / `FakePlatform` for the real adapters.
- The **hardware glue is not host-tested** and still requires physical validation:
  `PadilLineCodec` (ISR edge capture, DWT timing, `IntervalTimer` TX), `Rs485Phy`
  (DE//RE + pin I/O), `UsbTransport` (RawHID), and `TeensyPlatform` (LEDs, clock,
  temperature). See `docs/HARDWARE_VALIDATION.md`.

---

## Burn-candidate rule

Flash to hardware only when **all** of the following hold:

1. `make test` passes.
2. `make build` passes (compiles for Teensy 4.1).
3. The pin wiring has been reviewed against
   [`lib/TeensyRs485Bridge/src/Config.hpp`](../lib/TeensyRs485Bridge/src/Config.hpp).
4. The **hardware validation checklist** has been reviewed
   (`docs/HARDWARE_VALIDATION.md`).
5. The **MAX485 RO → Teensy pin 2 protection divider** (2.2 kΩ / 3.3 kΩ) is
   **physically verified** with a meter — RO must never reach pin 2 directly, and
   pin 2 must never exceed 3.3 V.
