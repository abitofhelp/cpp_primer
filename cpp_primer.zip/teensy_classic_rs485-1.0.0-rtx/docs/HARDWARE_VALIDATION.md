# Hardware Validation Checklist — Teensy 4.1 + MAX485 POC

Bench validation for the current MAX485 POC. Work top to bottom: **DMM/power-off
first**, then power-on, then GPIO, then scope, then live RS-485 input. Nothing
here can be proven in software — the host tests cover logic, this covers wiring
and timing.

> Pin assignments are defined in [`lib/TeensyRs485Bridge/src/Config.hpp`](../lib/TeensyRs485Bridge/src/Config.hpp); verify wiring
> against it and the protection-divider requirement below.

The protected RX divider MUST be present exactly as drawn:

```
MAX485 RO ---- 2.2 kΩ ----+---- Teensy pin 2
                          |
                        3.3 kΩ
                          |
                         GND
```

---

## A. DMM / power-OFF checks (do these first)

- [ ] Teensy GND ↔ MAX485 GND continuity ≈ **0 Ω** (common ground).
- [ ] **+5 V rail ↔ GND** not shorted (high resistance / no continuity beep).
- [ ] **+3.3 V rail ↔ GND** not shorted.
- [ ] RS-485 **A ↔ B** termination:
  - ≈ **120 Ω** with one terminator installed,
  - ≈ **60 Ω** with two terminators installed,
  - **high/open** with no terminator.
- [ ] **Divider topology verified** by measurement/continuity:
  - 2.2 kΩ in series from MAX485 RO to the pin-2 node,
  - 3.3 kΩ from the pin-2 node to GND,
  - MAX485 RO is **not** directly wired to Teensy pin 2.
- [ ] Divider ratio sanity: with 5 V at RO, node = 5 × 3.3/(2.2+3.3) ≈ **3.0 V**
      (safely ≤ 3.3 V).

## B. Power-ON checks

- [ ] Teensy **3.3 V rail ≈ 3.3 V**.
- [ ] MAX485 **VCC ≈ 5 V**.
- [ ] Common-ground difference (Teensy GND vs MAX485 GND) ≈ **0 V**.
- [ ] **Teensy pin 2 never exceeds 3.3 V** under any RO state (drive RO high, measure).
- [ ] Confirm again that **raw MAX485 RO is not connected directly** to pin 2.

## C. Static GPIO checks (idle / receive mode)

- [ ] Pin 4 (DE) **LOW** in receive mode.
- [ ] MAX485 **DE LOW** in receive mode.
- [ ] MAX485 **/RE LOW** in receive mode (if tied/shared with DE).
- [ ] Pin 3 (TX / DI) at a **known idle level** (driven LOW by `Rs485Phy::begin`).
- [ ] LEDs behave as documented at boot and idle:
  - **Pin 13** status/heartbeat — toggles ~once/second.
  - **Pin 35** transfer LED — **off** at idle; pulses on a successful PADIL transfer.
  - **Pin 34** debug/error LED — **off** at idle; pulses on a decode/framing/overflow error.

## D. Oscilloscope checks — transmit path (highest risk)

Probe **DE (pin 4)**, **Teensy TX (pin 3)**, the **protected RX node (pin 2)**,
and optionally the **A/B differential**.

- [ ] **DE asserts before or at** the first transmitted symbol (never after).
- [ ] **First symbol is emitted immediately** on transmit start — the line does
      **not** sit idle for one bit period first.
- [ ] **DE releases only after** the final symbol's hold time.
- [ ] **No extra bit cell** appears at the end of the frame.
- [ ] **A/B differential is present only while transmitting**; no bus drive when
      DE is LOW.

Differential-Manchester timing (boundary transition every cell + mid-cell
transition for a `0`; the TX timer ticks at the **half**-cell):

- [ ] **LDRP:** bit cell = **32 µs**, half-cell = **16 µs**.
- [ ] **MDRP:** bit cell = **8 µs**, half-cell = **4 µs** (~250 kHz timer) — verify
      it is stable and not jittered by the edge ISR.

## E. Oscilloscope / logic checks — receive + decode

- [ ] The line transitions **at least once per bit period** (must hold for
      differential Manchester), so the partial-frame timeout never fires on
      valid traffic.
- [ ] A captured message shows **SOM `0xAA 0xCC`** then exactly **27 payload bytes**.
- [ ] **Line-code convention/polarity confirmed** against the device: mid-cell
      transition means `0`. If inverted, only `PadilBitLayer` changes.
- [ ] `edge_overflows` stays 0 under a back-to-back MDRP burst (Status frame).

---

## F. Simulating RS-485 input on the bench

### Preferred: a second Teensy + MAX485 as a PADIL source

- Second Teensy + second MAX485 (or compatible transceiver) acts as the device.
- The simulator emits **differential-Manchester**:
  - SOM `0xAA 0xCC`,
  - a known 27-byte payload,
  - both **LDRP** and **MDRP** variants.
- Wire simulator **A/B to the POC A/B**, with a **common ground**, and a
  terminator per the DMM section.
- This is the highest-fidelity test — it exercises the transceiver, the divider,
  and the decoder together.

### Secondary options

- **Function / arbitrary waveform generator** into Teensy pin 2 at **0–3.3 V**
  for **decoder-only** testing (bypasses the transceiver; keep within 3.3 V).
- **Pattern generator** driven into the **divider input** (where MAX485 RO would
  connect), to exercise the protection network too.
- **Same-board loopback** only as a **special test mode**, not primary
  validation: normal firmware **suppresses self-reception during TX** (the edge
  ISR is gated while `is_transmitting()`), so a plain loopback will not decode
  what this board transmits without a dedicated test build.

---

## G. Open questions to resolve on hardware

Keep these visible until confirmed on the bench (also shown on the schematic):

1. **Differential-Manchester polarity/convention** on the real device.
2. **MDRP timing:** 4 µs half-cell, 8 µs bit cell — stable under load.
3. **First-transmit-symbol timing** and **DE release timing** (no extra/missing cell).
4. **Host-protocol policy:** device→host **TOM** (POC author left a `//TODO`; spec
      says PADIL=1) and device→host **message start number** (now 0, POC-aligned).
5. **New firmware drives pin 34 (error) and pin 35 (transfer) LEDs** as intended.
