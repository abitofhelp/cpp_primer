# Package Inventory

RTX/Raytheon, Michael Gardner.

The toolchain versions and build outputs that produced and validated this firmware.
Record the actual versions from the build host with `make check-tools`,
`pio --version`, and `arduino-cli version`.

## Firmware image (both frontends)

Both command-line frontends compile the one canonical library
(`lib/TeensyRs485Bridge`) to the **same** size:

| Region | Bytes | Notes |
|---|---|---|
| FLASH `code` | 15,972 | + `data` 9,128 + `headers` 8,688 |
| RAM1 | `variables` 11,904 + `code` 13,416 + `padding` 19,352 | ITCM; padding is block alignment |
| RAM2 | `variables` 1,632 | OCRAM |

Under ½ % of the Teensy 4.1's 7.75 MB flash. The size includes the concurrency
hardening (atomics + `dmb` barriers + the TX state machine); a pre-hardening image
was `FLASH code:15636` (see [`decisions/`](decisions/), ADR-1).

## Build toolchain

### PlatformIO frontend (default)

| Component | Version |
|---|---|
| PlatformIO Core | 6.1.19 |
| Teensy platform (`platformio/teensy`) | 5.2.0 (pinned in `platformio.ini`) |
| Framework (`framework-arduinoteensy`) | 1.162.0 |
| Cross-compiler (`arm-none-eabi-gcc`) | 15.2.1 |
| Upload tool (`tool-teensy`) | 1.162.0 |

### Arduino CLI frontend

| Component | Version |
|---|---|
| `arduino-cli` | 1.5.1 |
| Teensy core (`teensy:avr`) | 1.62.0 (validated; pinned by `ARDUINO_CORE_VERSION`) |
| Board FQBN | `teensy:avr:teensy41` with `--board-options usb=rawhid` |
| C++ standard | GNU C++20 |

### Host unit tests

| Host | Compiler |
|---|---|
| macOS | `c++` (Apple Clang, `-std=c++20`) |
| Linux | `c++`/`g++` (`-std=c++20`) |
| Windows / MSYS2 UCRT64 | `g++` (`-std=c++20`), `.exe` suffix |

Host tests need only a C++20 compiler — no Teensy toolchain, no network.

## Offline / air-gapped builds

For restricted networks, `make pio-prime` + `make pio-bundle` produce an OS/arch
named cache (`teensy-pio-cache-<os>-<arch>.tar.gz`) consumed by `make build-offline`.
Bundles are **OS/architecture-specific** — prime on the same platform family as the
target. See [`BUILD.md`](BUILD.md), "Offline / restricted-network builds".

## Reproducing

```sh
make check-tools     # report the toolchain present on this host
make test            # host unit suites (no toolchain/network needed)
make build           # PlatformIO firmware
make arduino-build   # Arduino CLI firmware (identical size)
make build-all       # both frontends
```
