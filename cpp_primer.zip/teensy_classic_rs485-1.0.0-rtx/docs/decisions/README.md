# Architecture Decision Records

RTX/Raytheon, Michael Gardner.

These ADRs record the **runtime-affecting** design decisions for the firmware's
concurrency core, its port contracts, and its error-handling model. Each states
the problem, the options weighed, the decision, and the validation gate, and is
recorded here as-built.

**Status legend:** `Implemented` (in the firmware) · `Accepted (pending HW)`
(agreed; final acceptance gated on the bench timing qualification) · `Documented`
(a semantics note, no code change).

| ADR | Decision | Status |
|---|---|---|
| ADR-1 | Edge-queue SPSC memory ordering → `std::atomic` acquire/release | Implemented; acceptance pending HW timing (ADR-4) |
| ADR-2 | Cross-context flags → atomics + explicit `dmb` DE sequencing | Implemented |
| ADR-3 | TX schedule fields → non-atomic, lifecycle-owned (documented contract) | Implemented |
| ADR-4 | ISR timing budget (bench thresholds) | Accepted (pending HW) |
| ADR-5 | Arduino vs PlatformIO RawHID = functional (not byte) equivalence | Accepted |
| ADR-6 | `FixedQueue::count()` is non-linearizable (diagnostic only) | Documented |
| ADR-7 | TX completion → explicit `Idle→Active→CleanupPending→Idle` state machine | Implemented |
| ADR-8 | Functional error handling (`Result`/`Option`), not C++ exceptions | Implemented |

---

## ADR-1 — Edge-queue (SPSC) memory ordering · Implemented (acceptance pending HW)

**Context.** `FixedQueue` backs `edge_queue_`, filled by the GPIO edge **ISR**
(producer) and drained by `poll()` in the main loop (consumer) on the
differential-Manchester path, where the timer fires every **~4 µs** half-cell. The
former `volatile uint32_t` indices are **not** a C++ synchronization primitive: the
compiler may reorder the (non-volatile) slot write relative to the (volatile) index
publish, so the consumer could read a slot before it is fully written — a latent
correctness bug.

**Decision.** `head_`/`tail_` are `std::atomic<uint32_t>`. The producer writes the
slot then publishes `head_` with **release**; the consumer reads `head_` with
**acquire**, so it can never observe an advanced index before the slot write it
guards. `static_assert(is_always_lock_free)` guards against a hidden libcall in the
ISR. Considered and rejected: relaxed atomics + `atomic_signal_fence` (single-core
only; silent-breakage risk) and keeping `volatile` (not real synchronization).

**As-built.** FLASH `code` moved 15,636 → 15,972 B (**+336 B**) for the combined
concurrency + contract hardening. Disassembly of the release build confirms the
queue is **fully lock-free** (no `__atomic_*` libcalls) and the acquire/release
barriers lower to `dmb`. The uniform atomic type also adds a small ordering cost to
the three currently main-context message queues (tx/rx/to-host) — accepted for one
simple, future-safe type.

**Validation gate.** (1) Disassembly lock-free/no-libcall check — **met**. (2) Bench
timing qualification per ADR-4 (worst-case `on_edge_isr()` cycles, `edge_overflows`
= 0 under MDRP + USB load) — **pending hardware**. (3) Record new flash/RAM — done.

---

## ADR-2 — Cross-context shared flags + driver-direction sequencing · Implemented

**Context.** `Rs485Phy::transmitting_` and `PadilLineCodec::edge_overflows_` are
shared across main / GPIO-ISR / timer-ISR contexts. As `volatile` they gave
tear-free access but **no ordering**. Separately, a **self-reception race** exists:
the edge ISR can capture the adapter's *own* transmitted transitions unless the
receive-suppression flag is ordered correctly against enabling the RS-485 driver.

**Decision.** `transmitting_` → `std::atomic<bool>`; `edge_overflows_` →
`std::atomic<uint32_t>` with `fetch_add(relaxed)` (a pure counter). A relaxed atomic
on normal memory does **not** order against the DE//RE GPIO (MMIO) writes, so
`Rs485Phy::set_direction()` adds an explicit ARM **`dmb`** (`data_memory_barrier()`,
also a compiler barrier):

- **Entering TX:** publish suppression flag → `dmb` → drive DE//RE (driver on).
- **Leaving TX:** drive DE//RE (driver off) → `dmb` → clear suppression flag.

`static_assert(is_always_lock_free)` guards both atomics. Considered and rejected:
critical sections (`__disable_irq`) — larger interrupts-off windows on a 4 µs path.

**Validation gate.** GCC output shows flag → `dmb` → GPIO order (met); scope DE//RE
against the edge-capture window during TX and confirm no self-captured edges —
**pending hardware bench**.

---

## ADR-3 — TX schedule fields: lifecycle-owned, not atomic · Implemented

**Context.** `tx_slot_`, `tx_buffer_`, `tx_current_level_` are written by **main**
at initialization and thereafter owned by the **timer ISR** while transmitting.

**Decision.** Keep them **non-atomic** with an enforced, documented contract: main
writes them **only before** `IntervalTimer.begin()`; the timer is stopped
(`.end()`) before any main rewrite. The ADR-7 state machine enforces the lifecycle —
`begin_transmit()` succeeds only from `Idle`, and `Idle` is reached only after
`poll()` runs post-cleanup, which is after `finish_transmit()` called `.end()`. Zero
overhead on the hot timer path. The contract is stated in `PadilLineCodec.hpp`.

---

## ADR-4 — ISR timing budget (bench thresholds) · Accepted (pending HW)

**Context.** ADR-1/ADR-2 add atomics/barriers to the hot ISR/timer path. "No timing
regression" is not measurable and is not a release gate.

**Decision.** The Slice-3 entry criterion is a concrete, measured budget set on
hardware: baseline and max `on_edge_isr()` cycles, max % of the 4 µs half-cell,
max timer-ISR cycles, max queue high-water under MDRP, acceptable overflow
(normally 0), the USB-load + status-frame test conditions, and the exact
compiler/opt-profile/clock. Measured via the DWT cycle counter + oscilloscope.
Because `FixedQueue::count()` is non-linearizable (ADR-6), queue high-water uses
producer-side instrumentation in the qualification build. **This gate is open until
a bench run on real hardware records the numbers.**

---

## ADR-5 — Arduino vs PlatformIO RawHID equivalence · Accepted

**Context.** Two frontends build the same library: PlatformIO (`-D USB_RAWHID`) and
Arduino CLI (`--board-options usb=rawhid`). A byte-identical `.elf`/`.hex` gate is
**wrong** — recipes, flags, paths, and timestamps differ even with an equal library
and toolchain.

**Decision.** Require **functional / RawHID equivalence**: `USB_RAWHID` present in
the Arduino build metadata; RawHID symbols linked; expected VID/PID/report sizes;
device enumerates; a host RawHID smoke test passes 64-byte in/out frames + ACK /
status; both frontends pass the same bench PADIL test. Byte-diff is informational.
Both frontends currently compile to identical size (`FLASH code:15972`); the host
smoke + bench test are **pending hardware**.

---

## ADR-6 — `FixedQueue::count()` concurrency semantics · Documented

`count()` performs two separate atomic loads, so under a concurrent
producer/consumer it is a **non-linearizable** snapshot — the two indices may
reflect different logical instants. It is kept as a diagnostic, documented as exact
only when the queue is quiescent or the caller owns both ends. The hot edge path
never calls it. No code change beyond the doc comment in `Core.hpp`.

---

## ADR-7 — TX completion: explicit state machine, not a two-flag protocol · Implemented

**Context (control-flow race).** The former `tx_active_` + `tx_complete_` two-flag
protocol had an interleaving where the prior transmission's decoder / stale-edge
reset could be **skipped**: `poll()` sees `tx_complete_ == false`; the timer ISR then
completes TX; the controller sees `is_transmitting() == false`, ACKs, and calls
`begin_transmit()` for the next message; that cleared `tx_complete_` before the next
`poll()` — so the prior TX's cleanup never ran. This occurs even with every atomic
op in source order — it is a control-flow bug, not just memory ordering.

**Decision.** One atomic state `Idle → Active → CleanupPending → Idle`:

- `begin_transmit()` succeeds **only from `Idle`**.
- The timer ISR moves `Active → CleanupPending` in `finish_transmit()`, **only after**
  the bus is safely back in receive.
- `is_transmitting()` is true **only for `Active`** (so a controller may ACK on
  physical completion while `CleanupPending`).
- `poll()` observes `CleanupPending`, resets the decoder + stale-edge state, then
  publishes `Idle`.

A new TX therefore cannot begin until cleanup has run and reached `Idle` — the
skipped-cleanup race is closed by construction.

**Validation gate.** A deterministic host regression test
(`test_adr7_tx_cleanup_not_skipped`) injects TX completion **between** the
controller's `line.poll()` and its transmit servicing and proves the next
transmission begins only after the prior TX's cleanup ran. **Met** (host suite).

---

## ADR-8 — Functional error handling (`Result`/`Option`), not exceptions · Implemented

**Context.** This is constrained, timing-sensitive firmware on a Teensy 4.1, built
with **`-fno-exceptions -fno-rtti`**. Fallible operations still need a way to report
failure. The choice of error-handling model affects the flash image, the ISR/main
timing, and how visible the error surface is to reviewers.

**Decision.** All fallible operations return `core::Result<T, E>` (a success value or
a typed error) or `core::Option<T>` (a value or nothing) — explicit values, never a
thrown exception. Exceptions and RTTI are disabled at the compiler; the whole
firmware, including the ports, is `noexcept`.

**Options.**

| Option | Verdict |
|---|---|
| **`Result`/`Option` values** ⭐ | Chosen — explicit, checked, zero hidden control flow |
| C++ exceptions | Rejected — unwinding is variable-latency and invisible on the 4 µs path; adds unwind tables/RTTI to the image; a throw in `noexcept` firmware calls `std::terminate()` |
| Error codes / `errno`-style | Rejected — easy to ignore silently and carries no typed payload |

**Rationale (the "why").**

- **Traceability.** Every failure is an explicit value in the function signature and
  must be handled at the call site (`[[nodiscard]]` enforces it). The full error
  surface is visible to reviewers and static analysis — errors cannot silently
  propagate up an invisible unwind path.
- **Determinism / real-time.** No exception unwinding means straight-line, predictable
  control flow on the GPIO-ISR and TX-timer paths, where the half-cell budget is
  ~4 µs. There is no hidden, variable-latency runtime.
- **Footprint.** `-fno-exceptions -fno-rtti` removes the unwind tables and RTTI
  metadata — a smaller flash image and no exception runtime on a constrained MCU.
- **`noexcept` end to end.** The controller and its ports are `noexcept`; making
  "cannot throw" the natural style keeps the port concepts (ADR: port hardening)
  honest — a throwing adapter is a compile error, not a runtime `terminate()`.
- **Portability of the pattern.** `Result`/`Option` map cleanly onto Rust's
  `Result`/`Option` and Ada's contract style, easing a future re-implementation.

**Consequences.** Boundary adapters translate hardware/library failures into typed
domain errors rather than exceptions; constructors do not throw; callers check
`is_ok()` / `has_value()`. The types live in `Core.hpp`, are allocation-free and
trivially copyable, and are exercised by the host unit tests.

**Validation gate.** The build sets `-fno-exceptions -fno-rtti` (see `platformio.ini`
and the Arduino `build.flags.cpp`); the firmware links with no exception runtime, and
the host suites cover the `Result`/`Option` paths.
