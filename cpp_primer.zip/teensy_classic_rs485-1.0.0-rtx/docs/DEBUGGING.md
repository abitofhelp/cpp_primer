# Debugging

RTX/Raytheon, Michael Gardner.

**The release firmware is USB RawHID, not USB Serial.** There is no `Serial` and no
serial console — so the Arduino Serial Monitor and `pio device monitor` (the
`make monitor` target) show **nothing useful** for this firmware. Debug it the ways
below instead.

## What to observe on a running device

- **Status frames (TOM = 3).** The bridge emits a 64-byte RawHID Status frame about
  once per second (`kStatusPeriodUs`) carrying the adapter state and every traffic
  and error counter (`host_rx/tx`, `rs485_rx/tx`, `framing_errors`, `edge_overflows`,
  `rx_msg_overflows`, `tx_msg_overflows`, `to_host_overflows`, `invalid_commands`,
  `usb_send_drops`, `usb_decode_errors`, and CPU temperature). Read them with a
  host-side RawHID reader — this is the primary telemetry channel. See the frame
  layout in [`README.md`](../README.md).
- **LEDs.**
  - **Pin 13** (on-board, amber) — heartbeat: toggles ~once/second. A steady 1 s
    blink means the main loop is alive.
  - **Pin 35** — transfer LED: pulses on a successful PADIL transfer.
  - **Pin 34** — error LED: pulses when any error counter advances.
- **Logic analyzer / oscilloscope.** Probe **DE (pin 4)**, **TX/DI (pin 3)**, and the
  **protected RX node (pin 2)** for direction timing and differential-Manchester
  symbols. See [`HARDWARE_VALIDATION.md`](HARDWARE_VALIDATION.md).

## Debugging logic on the host (no hardware needed)

The domain and application logic is Arduino-free and unit-tested on the host:

```sh
make test                          # run all host suites
make debug-host SUITE=bridge       # build a suite with -Og -g3 and launch a debugger
```

`make debug-host` accepts `SUITE=core|usb|padil|bridge` (default `bridge`) and
`DEBUGGER=lldb|gdb` (default: lldb on macOS, gdb on Linux/MSYS2). The `usb` and
`bridge` suites also compile the `UsbProtocol` translation unit. This is the fastest
way to step through the ACK policy, backpressure, numbering, the PADIL bit layer, and
the codec.

## On-chip (firmware) debugging

The **Teensy 4.1 has no on-board debug probe.** `make build-debug` builds the
symbol-rich `env:teensy41_debug` image (`-Og -g3 -fno-omit-frame-pointer`; it still
selects USB RawHID) that you can inspect with `arm-none-eabi-gdb` /
`arm-none-eabi-objdump` against `.pio/build/teensy41_debug/firmware.elf`.

**Live** source-level debugging of the running chip (breakpoints, single-step)
requires an **external SWD/J-Link probe** wired to the Teensy's SWD pads;
`platformio.ini` pins `debug_tool = jlink` for that path. Without a probe, use the
host unit tests (`make debug-host`) for logic and the Status frames + LEDs + a logic
analyzer for on-target behavior.

## Concurrency notes

The ISR / timer / main shared-state ownership and orderings are documented in
[`ARCHITECTURE.md`](ARCHITECTURE.md). When chasing an RS-485 timing or self-reception
issue, start from that ownership map: `edge_overflows` advancing under load points at
the edge queue / ISR budget (see ADR-1 / ADR-4); unexpected self-decoded edges during
TX point at the DE sequencing (ADR-2).
