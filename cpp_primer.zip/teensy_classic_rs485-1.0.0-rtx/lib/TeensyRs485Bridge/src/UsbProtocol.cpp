// UsbProtocol.cpp - Implementation of the USB RawHID frame codec.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include "UsbProtocol.hpp"

#include <cstring>

namespace bridge::usb {

using domain::AdapterCommand;
using domain::DecodeError;
using domain::HostFrame;
using domain::HostFrameKind;
using domain::Tom;

// ---------------------------------------------------------------------------
// Encoders
// ---------------------------------------------------------------------------

auto encode_padil(domain::UsbFrame& frame, domain::MessageNumber number,
                  const domain::PadilMessage& payload) noexcept -> void {
  frame.clear();
  frame.bytes[0] = static_cast<uint8_t>(Tom::Padil);
  write_u64_be(&frame.bytes[1], number);
  // Copy exactly 27 bytes into USB bytes 9..35 inclusive. (The POC copied only
  // 26 by iterating i = 9; i < 35.)
  std::memcpy(&frame.bytes[domain::kPadilPayloadOffset], payload.bytes,
              domain::kPadilPayloadSize);
}

auto encode_ack(domain::UsbFrame& frame, domain::MessageNumber number) noexcept -> void {
  frame.clear();
  frame.bytes[0] = static_cast<uint8_t>(Tom::Ack);
  write_u64_be(&frame.bytes[1], number);
}

auto encode_status(domain::UsbFrame& frame, const domain::AdapterStatus& status) noexcept
    -> void {
  frame.clear();
  frame.bytes[0] = static_cast<uint8_t>(Tom::Status);
  frame.bytes[1] = static_cast<uint8_t>(status.state);
  write_u64_be(&frame.bytes[2], status.host_rx);
  write_u64_be(&frame.bytes[10], status.host_tx);
  write_u64_be(&frame.bytes[18], status.rs485_rx);
  write_u64_be(&frame.bytes[26], status.rs485_tx);
  const int32_t temp =
      status.temp_available ? status.cpu_temp_tenths_c : domain::kTempUnavailableSentinel;
  write_i32_be(&frame.bytes[34], temp);
}

// ---------------------------------------------------------------------------
// Decoder
// ---------------------------------------------------------------------------

[[nodiscard]] auto decode_host_frame(const uint8_t* data, size_t length) noexcept
    -> DecodeResult {
  if (data == nullptr || length < domain::kUsbFrameSize) {
    return DecodeResult::err(DecodeError::ShortFrame);
  }

  const auto tom = static_cast<Tom>(data[0]);
  switch (tom) {
    case Tom::Illegal:
      return DecodeResult::err(DecodeError::IllegalTom);

    case Tom::Padil: {
      HostFrame out;
      out.kind = HostFrameKind::Padil;
      out.number = read_u64_be(&data[1]);
      std::memcpy(out.payload.bytes, &data[domain::kPadilPayloadOffset],
                  domain::kPadilPayloadSize);
      return DecodeResult::ok(out);
    }

    case Tom::Command: {
      const auto raw = data[1];
      if (raw != static_cast<uint8_t>(AdapterCommand::ClearCounters) &&
          raw != static_cast<uint8_t>(AdapterCommand::SetLdrp) &&
          raw != static_cast<uint8_t>(AdapterCommand::SetMdrp)) {
        return DecodeResult::err(DecodeError::UnknownCommand);
      }
      HostFrame out;
      out.kind = HostFrameKind::Command;
      out.command = static_cast<AdapterCommand>(raw);
      return DecodeResult::ok(out);
    }

    case Tom::Ack:
    case Tom::Status:
      // Valid frame kinds, but the device never receives them from the host.
      return DecodeResult::err(DecodeError::UnsupportedInbound);
  }

  return DecodeResult::err(DecodeError::UnknownTom);
}

}  // namespace bridge::usb
