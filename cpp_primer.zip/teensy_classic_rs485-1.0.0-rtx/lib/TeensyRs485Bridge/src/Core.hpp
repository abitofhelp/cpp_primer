// Core.hpp - Minimal, header-only, embedded-friendly building blocks.
//
// Contains the small Result<T, E> / Option<T> monads mandated by the C++ house
// standard and a fixed-capacity SPSC ring buffer (FixedQueue). All three are
// noexcept, allocation-free, RTTI-free, and depend only on <cstdint>/<cstddef>.
// They are safe to include from host-side unit tests.
//
// Deliberate scope limits (per review guidance):
//   * Result/Option store their payload inline; keep T small and trivially
//     copyable, which every use in this firmware is.
//   * FixedQueue IS used across an interrupt boundary: PadilLineCodec::edge_queue_
//     is filled by the GPIO edge ISR (producer) and drained by poll() in the main
//     loop (consumer). Its head_/tail_ indices are therefore std::atomic with
//     acquire/release ordering (see the FixedQueue concurrency contract below),
//     so the slot write is published before the index advance is observed. The
//     tx/rx/to-host message queues use the same hardened type but are main-context
//     only today; they pay the same (small) ordering cost for one uniform type.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>

namespace bridge::core {

// ---------------------------------------------------------------------------
// Option<T> - an explicit "value or nothing", replacing sentinel returns.
// ---------------------------------------------------------------------------
template <typename T>
class Option {
 public:
  constexpr Option() noexcept : has_value_(false), value_{} {}
  constexpr explicit Option(const T& value) noexcept
      : has_value_(true), value_(value) {}

  [[nodiscard]] static constexpr auto none() noexcept -> Option { return Option{}; }
  [[nodiscard]] static constexpr auto some(const T& value) noexcept -> Option {
    return Option{value};
  }

  [[nodiscard]] constexpr auto has_value() const noexcept -> bool { return has_value_; }
  [[nodiscard]] constexpr explicit operator bool() const noexcept { return has_value_; }

  // Precondition: has_value() is true. Never throws; reading an empty Option
  // returns the default-constructed T so behaviour stays deterministic.
  [[nodiscard]] constexpr auto value() const noexcept -> const T& { return value_; }
  // Returns BY VALUE, not by reference: a common call site passes a temporary
  // fallback (e.g. value_or(0)), and returning const T& would dangle the moment
  // the full expression ends. By value is safe for the small trivially-copyable
  // T this firmware uses.
  [[nodiscard]] constexpr auto value_or(const T& fallback) const noexcept -> T {
    return has_value_ ? value_ : fallback;
  }

 private:
  bool has_value_;
  T value_;
};

// ---------------------------------------------------------------------------
// Result<T, E> - a success value or a typed error, with no exceptions.
// ---------------------------------------------------------------------------
template <typename T, typename E>
class Result {
 public:
  [[nodiscard]] static constexpr auto ok(const T& value) noexcept -> Result {
    return Result{true, value, E{}};
  }
  [[nodiscard]] static constexpr auto err(E error) noexcept -> Result {
    return Result{false, T{}, error};
  }

  [[nodiscard]] constexpr auto is_ok() const noexcept -> bool { return is_ok_; }
  [[nodiscard]] constexpr auto is_err() const noexcept -> bool { return !is_ok_; }
  [[nodiscard]] constexpr explicit operator bool() const noexcept { return is_ok_; }

  // Precondition: is_ok(). Reading value() on an error returns a default T.
  [[nodiscard]] constexpr auto value() const noexcept -> const T& { return value_; }
  // Precondition: is_err(). Reading error() on a success returns a default E.
  [[nodiscard]] constexpr auto error() const noexcept -> E { return error_; }

 private:
  constexpr Result(bool is_ok, const T& value, E error) noexcept
      : is_ok_(is_ok), value_(value), error_(error) {}

  bool is_ok_;
  T value_;
  E error_;
};

// ---------------------------------------------------------------------------
// FixedQueue<T, Capacity> - lock-free single-producer / single-consumer ring.
//
// Concurrency contract: exactly ONE producer (may be an ISR) calling push(),
// and exactly ONE consumer (the main loop) calling pop()/peek(). Do NOT share a
// single queue across multiple producers or multiple consumers.
//
// Memory ordering (ADR-1): head_/tail_ are std::atomic<uint32_t>. The producer
// writes the slot, then publishes the new head with RELEASE; the consumer reads
// head with ACQUIRE, so it can never observe an advanced index before the slot
// write it guards. The consumer's tail advance is the symmetric release the
// producer acquires to know a slot is free. Plain volatile is NOT a C++
// synchronization primitive (the compiler may reorder the non-volatile slot
// write past the index publish), so acquire/release replaces it. is_always_lock_free
// is asserted so push()/pop() never emit a libcall inside the GPIO ISR.
//
// One slot is always left empty to distinguish full from empty, so the usable
// capacity is Capacity - 1. push() returns false when full (the caller counts
// the overflow); pop() returns Option::none() when empty.
// ---------------------------------------------------------------------------
template <typename T, size_t Capacity>
class FixedQueue {
  static_assert(Capacity >= 2, "FixedQueue needs at least 2 slots");
  static_assert(std::atomic<uint32_t>::is_always_lock_free,
                "FixedQueue indices must be lock-free for ISR-safe SPSC use");

 public:
  [[nodiscard]] auto push(const T& item) noexcept -> bool {
    const uint32_t head = head_.load(std::memory_order_relaxed);  // Producer owns head.
    const uint32_t next = increment(head);
    if (next == tail_.load(std::memory_order_acquire)) {
      return false;  // Full (acquire: see the consumer's latest tail release).
    }
    buffer_[head] = item;
    head_.store(next, std::memory_order_release);  // Publish only after the slot is written.
    return true;
  }

  [[nodiscard]] auto pop() noexcept -> Option<T> {
    const uint32_t tail = tail_.load(std::memory_order_relaxed);  // Consumer owns tail.
    if (tail == head_.load(std::memory_order_acquire)) {
      return Option<T>::none();  // Empty (acquire: pair with the producer's head release).
    }
    const T item = buffer_[tail];
    tail_.store(increment(tail), std::memory_order_release);  // Release only after the slot is read.
    return Option<T>::some(item);
  }

  // Return the front item WITHOUT removing it. Enables peek -> use -> pop-on-
  // success so a consumer (e.g. a USB send that may fail) never loses the item.
  // Consumer-side only, same SPSC contract as pop().
  [[nodiscard]] auto peek() const noexcept -> Option<T> {
    const uint32_t tail = tail_.load(std::memory_order_relaxed);
    if (tail == head_.load(std::memory_order_acquire)) {
      return Option<T>::none();
    }
    return Option<T>::some(buffer_[tail]);
  }

  [[nodiscard]] auto empty() const noexcept -> bool {
    return head_.load(std::memory_order_acquire) == tail_.load(std::memory_order_acquire);
  }

  // Diagnostic-only occupancy (ADR-6): this performs two separate atomic loads,
  // so under a concurrent producer/consumer it is a NON-linearizable snapshot -
  // the two indices may reflect different logical instants. It is exact only when
  // the queue is quiescent or the caller owns both ends. The hot edge path never
  // calls it.
  [[nodiscard]] auto count() const noexcept -> size_t {
    const uint32_t head = head_.load(std::memory_order_acquire);
    const uint32_t tail = tail_.load(std::memory_order_acquire);
    return (head >= tail) ? (head - tail) : (Capacity - tail + head);
  }

  [[nodiscard]] static constexpr auto capacity() noexcept -> size_t { return Capacity - 1; }

 private:
  [[nodiscard]] static constexpr auto increment(uint32_t index) noexcept -> uint32_t {
    return (index + 1U == Capacity) ? 0U : index + 1U;
  }

  T buffer_[Capacity]{};
  std::atomic<uint32_t> head_{0};  // Written by producer, read by consumer (release/acquire).
  std::atomic<uint32_t> tail_{0};  // Written by consumer, read by producer (release/acquire).
};

}  // namespace bridge::core
