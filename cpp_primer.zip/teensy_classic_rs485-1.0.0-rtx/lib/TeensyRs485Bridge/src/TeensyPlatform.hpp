// TeensyPlatform.hpp - Board adapter satisfying the PlatformPort concept.
//
// Concentrates the remaining board-level concerns that are not the RS-485 line
// or the USB transport: the microsecond clock, the status LED, and the on-die
// CPU temperature. Keeping them behind this adapter is what lets
// BridgeController stay Arduino-free and host-testable.
//
// This header depends on the Teensy core and is compiled only in the firmware
// build.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <Arduino.h>

#include <cmath>
#include <cstdint>

#include "Config.hpp"
#include "Core.hpp"
#include "Domain.hpp"

// Teensy 4.x on-die temperature monitor (C linkage; defined in the core).
#ifndef BRIDGE_HAS_CPU_TEMP
#define BRIDGE_HAS_CPU_TEMP 1
#endif
#if BRIDGE_HAS_CPU_TEMP
extern "C" float tempmonGetTemp(void);
#endif

namespace bridge::platform {

class TeensyPlatform {
 public:
  // Configure board pins and force every LED off. Call once from setup().
  auto begin() noexcept -> void {
    pinMode(config::kStatusLedPin, OUTPUT);
    pinMode(config::kTransferLedPin, OUTPUT);
    pinMode(config::kDebugLedPin, OUTPUT);
    digitalWriteFast(config::kStatusLedPin, LOW);
    digitalWriteFast(config::kTransferLedPin, LOW);
    digitalWriteFast(config::kDebugLedPin, LOW);
  }

  [[nodiscard]] auto micros() const noexcept -> uint32_t {
    return ::micros();
  }

  auto set_led(domain::Led led, bool on) noexcept -> void {
    const int pin = pin_for(led);
    digitalWriteFast(pin, on ? HIGH : LOW);
  }

  // CPU temperature in tenths of a degree Celsius, or none when unavailable.
  [[nodiscard]] auto cpu_temp_tenths() const noexcept -> core::Option<int32_t> {
#if BRIDGE_HAS_CPU_TEMP
    const float temp_c = tempmonGetTemp();
    return core::Option<int32_t>::some(static_cast<int32_t>(std::lroundf(temp_c * 10.0F)));
#else
    return core::Option<int32_t>::none();
#endif
  }

 private:
  [[nodiscard]] static auto pin_for(domain::Led led) noexcept -> int {
    switch (led) {
      case domain::Led::Transfer:
        return config::kTransferLedPin;
      case domain::Led::Error:
        return config::kDebugLedPin;
      case domain::Led::Status:
      default:
        return config::kStatusLedPin;
    }
  }
};

}  // namespace bridge::platform
