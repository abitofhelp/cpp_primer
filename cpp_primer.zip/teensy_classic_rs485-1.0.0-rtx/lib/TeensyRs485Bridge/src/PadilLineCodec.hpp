// PadilLineCodec.hpp - Hardware glue for the timed RS-485/PADIL line.
//
// This layer owns only the hardware concerns; all bit/symbol logic lives in the
// pure, host-tested PadilBitLayer:
//   * ISR context  : on_edge_isr() captures ONE (cycle, level) pair into a ring.
//   * Main loop    : poll() turns edge intervals into PadilLineDecoder calls and
//                    enforces the partial-frame timeout.
//   * Timer context: on_tx_tick() replays the differential-Manchester half-cell
//                    schedule, one transition per IntervalTimer firing.
//
// Line code is selected at compile time by config::kLineCode. Differential
// Manchester (the default) is described in PadilBitLayer.hpp.
// The NRZ branch is experimental and unverified.
//
// TX timing contract (differential Manchester):
//   * The opening boundary transition of bit 0 is emitted IMMEDIATELY in
//     begin_transmit(), before the timer starts - the line does not sit idle for
//     a bit period first.
//   * The IntervalTimer then fires once per HALF bit period and replays slots
//     1..2N (mids and boundaries), ending with the closing boundary of the last
//     bit, then holds one half-cell before releasing the driver.
//
// This module is firmware-only (Teensy core + IntervalTimer).
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <Arduino.h>

#include <atomic>
#include <cstdint>

#include "Config.hpp"
#include "Core.hpp"
#include "Domain.hpp"
#include "PadilBitLayer.hpp"
#include "Rs485Phy.hpp"

namespace bridge::padil {

// Speed is defined in PadilBitLayer.hpp (Arduino-free).

// A single captured edge: CPU cycle timestamp and the post-transition level.
struct EdgeEvent {
  uint32_t cycles;
  uint8_t level;
};

// TX lifecycle (ADR-7). A single atomic state replaces the old tx_active_ +
// tx_complete_ two-flag protocol, which had a control-flow race where the prior
// transmission's decoder/stale-edge cleanup could be skipped:
//   Idle           - no transmission; begin_transmit() succeeds ONLY from here.
//   Active         - the timer ISR is driving the bus; is_transmitting() is true
//                    only in this state.
//   CleanupPending - the bus is safely back in receive, but the main loop has
//                    NOT yet reset the decoder/stale-edge state. begin_transmit()
//                    is refused here, so the next TX cannot start until poll()
//                    performs cleanup and publishes Idle. A controller may ACK
//                    physical completion while CleanupPending.
enum class TxState : uint8_t { Idle = 0, Active = 1, CleanupPending = 2 };

class PadilLineCodec {
 public:
  auto begin(rs485::Rs485Phy& phy) noexcept -> void;

  auto set_speed(Speed speed) noexcept -> void;
  [[nodiscard]] auto speed() const noexcept -> Speed { return speed_; }

  // --- ISR context ---
  auto on_edge_isr() noexcept -> void;

  // --- Main-loop context ---
  auto poll() noexcept -> void;
  [[nodiscard]] auto take_received() noexcept -> core::Option<domain::PadilMessage> {
    return decoder_.take_message();
  }

  // --- Transmit ---
  [[nodiscard]] auto begin_transmit(const domain::PadilMessage& message) noexcept -> bool;
  auto on_tx_tick() noexcept -> void;  // IntervalTimer body only.
  [[nodiscard]] auto is_transmitting() const noexcept -> bool {
    return tx_state_.load(std::memory_order_acquire) == TxState::Active;
  }

  // --- Diagnostics ---
  [[nodiscard]] auto framing_errors() const noexcept -> uint32_t {
    return decoder_.framing_errors();
  }
  [[nodiscard]] auto edge_overflows() const noexcept -> uint32_t {
    return edge_overflows_.load(std::memory_order_relaxed);
  }
  [[nodiscard]] auto rx_msg_overflows() const noexcept -> uint32_t {
    return decoder_.rx_msg_overflows();
  }

 private:
  auto recompute_timing() noexcept -> void;
  auto finish_transmit() noexcept -> void;

  rs485::Rs485Phy* phy_ = nullptr;

  Speed speed_ = Speed::Ldrp;
  uint32_t bit_period_us_ = config::kLdrpBitPeriodUs;
  uint32_t bit_period_cycles_ = 0;
  uint32_t framing_timeout_cycles_ = 0;

  // Edge capture (ISR producer, poll() consumer).
  core::FixedQueue<EdgeEvent, config::kEdgeQueueCapacity> edge_queue_;
  bool have_prev_edge_ = false;  // Main-loop-owned (poll/begin only).
  uint32_t prev_edge_cycles_ = 0;
  uint8_t prev_level_ = 0;
  uint32_t last_progress_cycles_ = 0;

  // Pure bit layer.
  PadilLineDecoder decoder_;

  // Transmit schedule. SOM (2 bytes) + 27-byte payload = 29 bytes = 232 bits.
  static constexpr size_t kTxSomBytes = 2;
  static constexpr size_t kTxBufferBytes = kTxSomBytes + domain::kPadilPayloadSize;
  static constexpr size_t kTxTotalBits = kTxBufferBytes * 8;
  IntervalTimer tx_timer_;
  uint8_t tx_buffer_[kTxBufferBytes]{};

  // TX schedule fields (ADR-3): lifecycle-owned, NOT atomic. The contract is that
  // main writes them ONLY before tx_timer_.begin(), after which the timer ISR is
  // their sole owner until tx_timer_.end(). The ADR-7 state machine enforces this
  // - begin_transmit() succeeds only from Idle, and Idle is reached only after
  // poll() runs post-cleanup, which happens after finish_transmit() called end().
  bool tx_current_level_ = false;  // Last driven line level (TX context).
  uint32_t tx_slot_ = 0;           // Next half-cell slot to emit (timer-owned).

  // TX lifecycle state machine (ADR-7). Idle -> Active -> CleanupPending -> Idle.
  static_assert(std::atomic<TxState>::is_always_lock_free,
                "tx_state_ must be lock-free for ISR-safe access");
  std::atomic<TxState> tx_state_{TxState::Idle};

  // Counters. edge_overflows_ is written only by the GPIO ISR (fetch_add) and
  // read by the main loop; atomic so the read-modify-write and the read are
  // tear-free across the interrupt boundary.
  static_assert(std::atomic<uint32_t>::is_always_lock_free,
                "edge_overflows_ must be lock-free for ISR-safe access");
  std::atomic<uint32_t> edge_overflows_{0};
};

}  // namespace bridge::padil
