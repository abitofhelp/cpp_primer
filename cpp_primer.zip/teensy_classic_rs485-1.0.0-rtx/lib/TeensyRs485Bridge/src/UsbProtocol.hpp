// UsbProtocol.hpp - USB RawHID frame codec (encode/decode), transport-free.
//
// This is the auditable core of the host protocol. It knows the 64-byte frame
// layout and nothing about how frames are moved (that is UsbTransport's job).
// The big-endian helpers are inline here so they can be read and unit-tested in
// isolation; the encode/decode functions live in UsbProtocol.cpp.
//
// Frame layouts (byte offsets):
//   PADIL   : [0]=1  [1..8]=msg# BE  [9..35]=27-byte payload  [36..63]=0
//   ACK     : [0]=2  [1..8]=msg# BE  [9..63]=0
//   STATUS  : [0]=3  [1]=state  [2..9]=hostRx  [10..17]=hostTx
//             [18..25]=rs485Rx  [26..33]=rs485Tx  [34..37]=tempTenths i32 BE
//             [38..63]=0
//   COMMAND : [0]=4  [1]=command  [2..63] ignored   (host -> device only)
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <cstddef>
#include <cstdint>

#include "Core.hpp"
#include "Domain.hpp"

namespace bridge::usb {

// ---------------------------------------------------------------------------
// Big-endian (network-order) helpers.
//
// Implemented with explicit shifts and masks - never by pointer-casting a
// 32-bit object and copying 8 bytes (the POC's get/set64BitValue bug, which
// both truncated to 32 bits and read past the object). These are pure,
// endianness-independent, and trivial to audit.
// ---------------------------------------------------------------------------

inline auto write_u64_be(uint8_t* dst, uint64_t value) noexcept -> void {
  dst[0] = static_cast<uint8_t>(value >> 56);
  dst[1] = static_cast<uint8_t>(value >> 48);
  dst[2] = static_cast<uint8_t>(value >> 40);
  dst[3] = static_cast<uint8_t>(value >> 32);
  dst[4] = static_cast<uint8_t>(value >> 24);
  dst[5] = static_cast<uint8_t>(value >> 16);
  dst[6] = static_cast<uint8_t>(value >> 8);
  dst[7] = static_cast<uint8_t>(value);
}

[[nodiscard]] inline auto read_u64_be(const uint8_t* src) noexcept -> uint64_t {
  return (static_cast<uint64_t>(src[0]) << 56) |
         (static_cast<uint64_t>(src[1]) << 48) |
         (static_cast<uint64_t>(src[2]) << 40) |
         (static_cast<uint64_t>(src[3]) << 32) |
         (static_cast<uint64_t>(src[4]) << 24) |
         (static_cast<uint64_t>(src[5]) << 16) |
         (static_cast<uint64_t>(src[6]) << 8) |
         (static_cast<uint64_t>(src[7]));
}

inline auto write_i32_be(uint8_t* dst, int32_t value) noexcept -> void {
  // C++20 guarantees two's-complement, so this reinterpretation is portable.
  const auto u = static_cast<uint32_t>(value);
  dst[0] = static_cast<uint8_t>(u >> 24);
  dst[1] = static_cast<uint8_t>(u >> 16);
  dst[2] = static_cast<uint8_t>(u >> 8);
  dst[3] = static_cast<uint8_t>(u);
}

[[nodiscard]] inline auto read_i32_be(const uint8_t* src) noexcept -> int32_t {
  const auto u = (static_cast<uint32_t>(src[0]) << 24) |
                 (static_cast<uint32_t>(src[1]) << 16) |
                 (static_cast<uint32_t>(src[2]) << 8) |
                 (static_cast<uint32_t>(src[3]));
  return static_cast<int32_t>(u);
}

// ---------------------------------------------------------------------------
// Encoders (device -> host). Each fully zeroes the frame first, so unused and
// padding bytes are always 0.
// ---------------------------------------------------------------------------

auto encode_padil(domain::UsbFrame& frame, domain::MessageNumber number,
                  const domain::PadilMessage& payload) noexcept -> void;

auto encode_ack(domain::UsbFrame& frame, domain::MessageNumber number) noexcept -> void;

auto encode_status(domain::UsbFrame& frame, const domain::AdapterStatus& status) noexcept
    -> void;

// ---------------------------------------------------------------------------
// Decoder (host -> device). Validates length and TOM, and only accepts the two
// frame kinds the device actually receives (PADIL, Command). Ack/Status are
// reported as UnsupportedInbound rather than silently ignored.
// ---------------------------------------------------------------------------

using DecodeResult = core::Result<domain::HostFrame, domain::DecodeError>;

[[nodiscard]] auto decode_host_frame(const uint8_t* data, size_t length) noexcept
    -> DecodeResult;

[[nodiscard]] inline auto decode_host_frame(const domain::UsbFrame& frame) noexcept
    -> DecodeResult {
  return decode_host_frame(frame.bytes, domain::kUsbFrameSize);
}

}  // namespace bridge::usb
