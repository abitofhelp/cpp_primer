// Config.hpp - Compile-time configuration for the RS-485 <-> USB RawHID bridge.
//
// Everything that a board bring-up might need to change lives here: pin
// assignments, RS-485 direction-control wiring, PADIL bit timing, queue sizes,
// and service periods. Nothing in this header depends on the Arduino core, so
// it is safe to include from host-side unit tests.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <cstddef>
#include <cstdint>

namespace bridge::config {

// ---------------------------------------------------------------------------
// Pin assignments (Teensy 4.1 digital pins).
//
// These mirror the POC where it was unambiguous (RX = 2, TX = 3, status LED =
// 13) and add explicit RS-485 direction-control pins, which the POC did not
// model. Confirm the DE/(/RE) pins against the actual transceiver wiring
// before bring-up.
// ---------------------------------------------------------------------------

// RS-485 receive: reads the transceiver RO line. On Teensy 4.1 this pin is
// 3.3 V only and is NOT 5 V tolerant. If a MAX485 is powered at 5 V its RO
// output MUST be level-shifted down to 3.3 V before reaching this pin.
inline constexpr int kRs485RxPin = 2;

// RS-485 transmit: drives the transceiver DI line.
inline constexpr int kRs485TxPin = 3;

// RS-485 driver enable (DE, active HIGH on MAX485-style parts).
inline constexpr int kRs485DePin = 4;

// RS-485 receiver enable (/RE, active LOW on MAX485-style parts). Only used
// when kRs485DeReShared is false. When DE and /RE are jumpered to one signal,
// set kRs485DeReShared = true and this pin is ignored.
inline constexpr int kRs485RePin = 5;

// True when DE and /RE are tied to a single control line (one pin drives both:
// HIGH = transmit, LOW = receive). False when they are separate pins.
inline constexpr bool kRs485DeReShared = true;

// LEDs (carried over from the POC).
//   Pin 13 : on-board status / heartbeat.
//   Pin 35 : external data-transfer LED (pulses on a successful PADIL transfer).
//   Pin 34 : external debug/error LED (pulses on a decode/framing/overflow error).
// External LEDs need a series resistor to GND.
inline constexpr int kStatusLedPin = 13;
inline constexpr int kTransferLedPin = 35;
inline constexpr int kDebugLedPin = 34;

// How long a transfer/error LED stays lit after its triggering event (micros).
inline constexpr uint32_t kLedPulseUs = 50000;  // 50 ms - visible on the bench.

// ---------------------------------------------------------------------------
// PADIL line timing.
//
// LDRP and MDRP are the two supported bit periods. The decoder/encoder convert
// these to CPU cycles at runtime using F_CPU_ACTUAL (see PadilLineCodec), so no
// ticks-per-microsecond constant is hard-coded here. The POC hard-coded 528
// ticks/us, which is wrong for a 600 MHz Teensy 4.1 (should be 600).
// ---------------------------------------------------------------------------

inline constexpr uint32_t kLdrpBitPeriodUs = 32;  // Low data-rate PADIL.
inline constexpr uint32_t kMdrpBitPeriodUs = 8;   // Medium data-rate PADIL.

// Fractional tolerance applied to the bit period when validating edge
// intervals (1/8 == 12.5%, matching the POC's clockWidth/8 band). Intervals
// outside the band are rejected as framing errors, never silently rounded.
inline constexpr uint32_t kBitPeriodToleranceDiv = 8;

// Default speed selected at boot.
enum class DefaultSpeed { Ldrp, Mdrp };
inline constexpr DefaultSpeed kDefaultSpeed = DefaultSpeed::Ldrp;

// ---------------------------------------------------------------------------
// Line code.
//
// DifferentialManchester is the DEFAULT and the only fully supported/tested
// path. It matches the POC: a transition at every bit-cell boundary (the
// recovered clock) plus a mid-cell transition when the data bit is 0; decode
// compares the level across successive boundaries (changed -> 1, same -> 0).
//
// Nrz (level == bit) is an EXPERIMENTAL alternative kept behind this flag for
// bench experimentation only. It is NOT covered by the host tests and its
// no-edge timeout is unreliable for long 0x00/0xFF runs - do not ship it
// without scope confirmation that the device actually uses NRZ.
// ---------------------------------------------------------------------------
enum class LineCode : uint8_t { DifferentialManchester, Nrz };
inline constexpr LineCode kLineCode = LineCode::DifferentialManchester;

// ---------------------------------------------------------------------------
// Queue sizing (all fixed, no heap).
// ---------------------------------------------------------------------------

// ISR edge-capture ring buffer. Sized generously: a full 29-byte PADIL frame
// is ~232 bit transitions, and the main loop drains between messages.
inline constexpr size_t kEdgeQueueCapacity = 512;

// Decoded PADIL messages waiting to be shipped to the USB host.
inline constexpr size_t kRs485RxMsgQueueCapacity = 8;

// Host PADIL messages waiting to be transmitted onto RS-485.
inline constexpr size_t kRs485TxMsgQueueCapacity = 8;

// ---------------------------------------------------------------------------
// USB service timing.
// ---------------------------------------------------------------------------

// How often loop() polls RawHID for an inbound frame (microseconds).
inline constexpr uint32_t kUsbPollIntervalUs = 1000;

// How often an unsolicited Status frame is pushed to the host (microseconds).
inline constexpr uint32_t kStatusPeriodUs = 1000000;

// RawHID timeouts (milliseconds). Both are non-blocking (0) so the bridge loop
// never stalls on USB. A failed send increments a drop counter instead.
inline constexpr uint32_t kUsbRecvTimeoutMs = 0;
inline constexpr uint32_t kUsbSendTimeoutMs = 0;

// ---------------------------------------------------------------------------
// PADIL framing.
// ---------------------------------------------------------------------------

// Start-of-message marker on the RS-485 side (0xAA, 0xCC), matching the POC.
inline constexpr uint8_t kSomByte0 = 0xAA;
inline constexpr uint8_t kSomByte1 = 0xCC;

// If no edge arrives for this many bit periods mid-message, the decoder
// abandons the partial frame and counts a framing error.
inline constexpr uint32_t kFramingTimeoutBitPeriods = 4;

}  // namespace bridge::config
