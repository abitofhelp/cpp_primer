// PadilBitLayer.hpp - Pure, hardware-free PADIL bit layer (decode + TX schedule).
//
// This is the testable seam for the RS-485 line code. It has NO Arduino, timer,
// or DWT dependency, so the whole thing runs in host unit tests. The hardware
// glue (PadilLineCodec) only captures edges and replays this layer's decisions.
//
// LINE CODE (differential Manchester, matching the POC):
//   * Encode: a transition at EVERY bit-cell boundary (the recovered clock),
//     plus an ADDITIONAL transition at the cell midpoint when the data bit is 0.
//       bit 1 -> boundary transition only          (one edge per cell)
//       bit 0 -> boundary + mid transitions        (two edges per cell)
//   * Decode from inter-edge intervals:
//       interval ~= full bit period  -> bit 1   (boundary-to-boundary, no mid)
//       two intervals ~= half period -> bit 0   (mid then boundary)
//     Because there is a guaranteed edge at least once per bit period, a short
//     no-edge timeout is legitimate here (unlike NRZ).
//
// Bit ordering is MSB-first. The start-of-message marker is 0xAA 0xCC; the
// payload is exactly 27 bytes.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <cstddef>
#include <cstdint>

#include "Config.hpp"
#include "Core.hpp"
#include "Domain.hpp"

namespace bridge::padil {

using config::LineCode;

// PADIL bit-rate selection. Lives here (Arduino-free) so ports that reference it
// stay host-testable.
enum class Speed : uint8_t { Ldrp, Mdrp };

// ---------------------------------------------------------------------------
// Bit accessor and TX schedule helpers (pure, constexpr, unit-testable).
// ---------------------------------------------------------------------------

// MSB-first bit `bit_index` of a byte buffer.
[[nodiscard]] constexpr auto frame_bit_msb(const uint8_t* frame, size_t bit_index) noexcept
    -> uint8_t {
  return static_cast<uint8_t>((frame[bit_index / 8] >> (7 - (bit_index % 8))) & 0x1U);
}

// Differential-Manchester transmission is expressed as a sequence of half-cell
// slots indexed 0..2N. Even slots are cell boundaries; odd slots are cell
// midpoints. Slot 0 is the opening boundary of bit 0; slot 2N is the closing
// boundary of the last bit. Total emitted transitions/holds = 2N + 1 slots.
[[nodiscard]] constexpr auto manchester_total_half_cells(size_t total_bits) noexcept -> size_t {
  return 2 * total_bits + 1;
}

// Does the driver toggle at half-cell slot `h`?
//   boundary (h even) -> always toggle (the clock edge)
//   midpoint (h odd)  -> toggle iff the bit is 0
[[nodiscard]] constexpr auto manchester_toggle_at(size_t h, const uint8_t* frame,
                                                  size_t total_bits) noexcept -> bool {
  if ((h & 0x1U) == 0) {
    return true;  // Boundary: always transitions.
  }
  const size_t bit_index = h / 2;
  if (bit_index >= total_bits) {
    return false;  // Past the last bit (safety).
  }
  return frame_bit_msb(frame, bit_index) == 0;  // Mid transition marks a 0.
}

// ---------------------------------------------------------------------------
// PadilMessageAssembler - bit stream -> idle/SOM detection -> 27-byte capture.
//
// Shared by both line codes: it consumes a decoded bit stream and knows nothing
// about timing. Runs entirely in the main-loop context.
// ---------------------------------------------------------------------------
class PadilMessageAssembler {
 public:
  auto reset() noexcept -> void {
    state_ = State::FindIdle;
    window_ = 0;
    armed_bit_count_ = 0;
    current_byte_ = 0;
    bit_count_ = 0;
    byte_count_ = 0;
  }

  auto feed_bit(uint8_t bit) noexcept -> void {
    window_ = static_cast<uint16_t>((window_ << 1) | (bit & 0x1U));

    switch (state_) {
      case State::FindIdle: {
        const auto hi = static_cast<uint8_t>(window_ >> 8);
        const auto lo = static_cast<uint8_t>(window_ & 0xFF);
        if (hi == lo && (hi == 0xAA || hi == 0x55)) {
          state_ = State::ArmedForSom;
          armed_bit_count_ = 0;
        }
        break;
      }

      case State::ArmedForSom: {
        ++armed_bit_count_;
        // uint16_t SOM - the previous version truncated (0xAACC & 0xFF).
        constexpr uint16_t kSom =
            static_cast<uint16_t>((static_cast<uint16_t>(config::kSomByte0) << 8) |
                                  static_cast<uint16_t>(config::kSomByte1));
        if (window_ == kSom) {
          state_ = State::InMessage;
          current_byte_ = 0;
          bit_count_ = 0;
          byte_count_ = 0;
        } else if (armed_bit_count_ > 32) {
          state_ = State::FindIdle;  // Idle broke without a SOM; resync.
        }
        break;
      }

      case State::InMessage: {
        current_byte_ = static_cast<uint8_t>((current_byte_ << 1) | (bit & 0x1U));
        if (++bit_count_ == 8) {
          in_progress_.bytes[byte_count_] = current_byte_;
          current_byte_ = 0;
          bit_count_ = 0;
          if (++byte_count_ >= domain::kPadilPayloadSize) {
            if (!rx_queue_.push(in_progress_)) {
              ++rx_msg_overflows_;
            }
            state_ = State::FindIdle;
          }
        }
        break;
      }
    }
  }

  [[nodiscard]] auto take_message() noexcept -> core::Option<domain::PadilMessage> {
    return rx_queue_.pop();
  }

  [[nodiscard]] auto in_frame() const noexcept -> bool { return state_ != State::FindIdle; }
  [[nodiscard]] auto rx_msg_overflows() const noexcept -> uint32_t { return rx_msg_overflows_; }
  auto clear_overflows() noexcept -> void { rx_msg_overflows_ = 0; }

 private:
  enum class State : uint8_t { FindIdle, ArmedForSom, InMessage };

  State state_ = State::FindIdle;
  uint16_t window_ = 0;
  uint32_t armed_bit_count_ = 0;
  uint8_t current_byte_ = 0;
  uint8_t bit_count_ = 0;
  uint8_t byte_count_ = 0;
  domain::PadilMessage in_progress_{};
  core::FixedQueue<domain::PadilMessage, config::kRs485RxMsgQueueCapacity> rx_queue_;
  uint32_t rx_msg_overflows_ = 0;  // Written only in this (main-loop) context.
};

// ---------------------------------------------------------------------------
// PadilLineDecoder - inter-edge intervals -> bits -> assembler.
//
// feed_segment() takes the interval since the previous edge (in the same units
// used to configure the bit period) and the level HELD during that segment
// (the level before this edge; used only by the NRZ experiment). It enforces
// the configured tolerance and returns false, counting a framing error and
// resynchronizing, when an interval does not fit.
// ---------------------------------------------------------------------------
class PadilLineDecoder {
 public:
  auto configure(uint32_t bit_period, uint32_t tolerance_div, LineCode code) noexcept -> void {
    full_ = bit_period;
    half_ = bit_period / 2;
    tol_div_ = (tolerance_div == 0) ? 8 : tolerance_div;
    code_ = code;
    reset();
  }

  auto reset() noexcept -> void {
    half_pending_ = false;
    assembler_.reset();
  }

  [[nodiscard]] auto feed_segment(uint32_t dt, uint8_t held_level) noexcept -> bool {
    if (code_ == LineCode::DifferentialManchester) {
      return feed_manchester(dt);
    }
    return feed_nrz(dt, held_level);
  }

  [[nodiscard]] auto take_message() noexcept -> core::Option<domain::PadilMessage> {
    return assembler_.take_message();
  }

  [[nodiscard]] auto in_frame() const noexcept -> bool { return assembler_.in_frame(); }

  // Called by the hardware layer when a partial frame times out.
  auto note_timeout() noexcept -> void {
    ++framing_errors_;
    reset();
  }

  [[nodiscard]] auto framing_errors() const noexcept -> uint32_t { return framing_errors_; }
  [[nodiscard]] auto rx_msg_overflows() const noexcept -> uint32_t {
    return assembler_.rx_msg_overflows();
  }
  auto clear_counters() noexcept -> void {
    framing_errors_ = 0;
    assembler_.clear_overflows();
  }

 private:
  [[nodiscard]] auto within(uint32_t dt, uint32_t target) const noexcept -> bool {
    const uint32_t band = target / tol_div_;
    return dt >= (target - band) && dt <= (target + band);
  }

  auto fail() noexcept -> bool {
    ++framing_errors_;
    reset();
    return false;
  }

  [[nodiscard]] auto feed_manchester(uint32_t dt) noexcept -> bool {
    if (within(dt, full_)) {
      if (half_pending_) {
        return fail();  // A stray mid without its pair - inconsistent.
      }
      assembler_.feed_bit(1);  // Boundary-to-boundary, no mid -> 1.
      return true;
    }
    if (within(dt, half_)) {
      if (half_pending_) {
        half_pending_ = false;
        assembler_.feed_bit(0);  // Second half completes a 0.
      } else {
        half_pending_ = true;  // First half (the mid transition).
      }
      return true;
    }
    return fail();  // Out of tolerance for both half and full.
  }

  // EXPERIMENTAL NRZ decode: emit `n` bits of the held level, where n is the
  // number of bit periods in dt - but only if dt fits an integer multiple
  // within tolerance (so we still reject garbage rather than blindly rounding).
  [[nodiscard]] auto feed_nrz(uint32_t dt, uint8_t held_level) noexcept -> bool {
    if (full_ == 0 || dt < half_) {
      return fail();
    }
    const uint32_t n = (dt + full_ / 2) / full_;
    if (n == 0 || n > 64) {
      return fail();
    }
    const uint32_t ideal = n * full_;
    const uint32_t diff = (dt > ideal) ? (dt - ideal) : (ideal - dt);
    if (diff > (full_ / tol_div_) * n) {
      return fail();  // Does not fit an integer number of bit periods.
    }
    const uint8_t bit = (held_level != 0) ? 1U : 0U;
    for (uint32_t i = 0; i < n; ++i) {
      assembler_.feed_bit(bit);
    }
    return true;
  }

  PadilMessageAssembler assembler_;
  LineCode code_ = LineCode::DifferentialManchester;
  uint32_t full_ = 0;
  uint32_t half_ = 0;
  uint32_t tol_div_ = 8;
  bool half_pending_ = false;
  uint32_t framing_errors_ = 0;
};

}  // namespace bridge::padil
