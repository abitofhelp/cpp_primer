// Domain.hpp - Core value types for the bridge, independent of any transport.
//
// These are plain, trivially-copyable value objects: the 27-byte PADIL message,
// the 64-byte USB frame, the 64-bit message number, the adapter state/command
// enums, the aggregated status, and the decode-error and inbound-frame types
// used by the USB codec. No Arduino dependency, so this header is host-testable.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <cstddef>
#include <cstdint>

namespace bridge::domain {

// ---------------------------------------------------------------------------
// Wire-format constants (single source of truth for both codec and tests).
// ---------------------------------------------------------------------------
inline constexpr size_t kUsbFrameSize = 64;       // Every RawHID frame.
inline constexpr size_t kPadilPayloadSize = 27;   // PADIL payload, exactly.
inline constexpr size_t kPadilPayloadOffset = 9;  // USB bytes 9..35 inclusive.

// 64-bit message identifier. Always uint64_t - never unsigned long (the POC
// bug that truncated to 32 bits on this ABI).
using MessageNumber = uint64_t;

// ---------------------------------------------------------------------------
// PadilMessage - exactly 27 payload bytes.
// ---------------------------------------------------------------------------
struct PadilMessage {
  uint8_t bytes[kPadilPayloadSize];

  [[nodiscard]] friend auto operator==(const PadilMessage& a,
                                        const PadilMessage& b) noexcept -> bool {
    for (size_t i = 0; i < kPadilPayloadSize; ++i) {
      if (a.bytes[i] != b.bytes[i]) {
        return false;
      }
    }
    return true;
  }
};

// ---------------------------------------------------------------------------
// UsbFrame - exactly 64 bytes, the RawHID transfer unit.
// ---------------------------------------------------------------------------
struct UsbFrame {
  uint8_t bytes[kUsbFrameSize];

  auto clear() noexcept -> void {
    for (size_t i = 0; i < kUsbFrameSize; ++i) {
      bytes[i] = 0;
    }
  }
};

// ---------------------------------------------------------------------------
// Queue value types (carry a message number alongside the payload).
// ---------------------------------------------------------------------------

// Host -> RS-485: the host's message number travels with the payload so the ACK
// can be emitted after the payload physically completes transmission.
struct OutboundPadil {
  MessageNumber host_number;
  PadilMessage payload;
};

// RS-485 -> host: the device-assigned number is fixed when the decoded message
// is enqueued for USB and preserved across USB send failures until it is sent.
struct HostboundPadil {
  MessageNumber number;
  PadilMessage payload;
};

// ---------------------------------------------------------------------------
// Type of Message (byte 0 of every USB frame).
// ---------------------------------------------------------------------------
enum class Tom : uint8_t {
  Illegal = 0,
  Padil = 1,
  Ack = 2,
  Status = 3,
  Command = 4,
};

// ---------------------------------------------------------------------------
// Indicator LEDs (driven through the platform port).
// ---------------------------------------------------------------------------
enum class Led : uint8_t {
  Status = 0,    // Pin 13: heartbeat / firmware alive.
  Transfer = 1,  // Pin 35: successful PADIL transfer.
  Error = 2,     // Pin 34: decode / framing / overflow error.
};

// ---------------------------------------------------------------------------
// Adapter state machine (reported in Status byte 1).
// ---------------------------------------------------------------------------
enum class AdapterState : uint8_t {
  Booting = 0,
  Idle = 1,
  Receiving = 2,
  Transmitting = 3,
  Error = 4,
};

// ---------------------------------------------------------------------------
// Host commands (Command frame byte 1). Values match the wire protocol.
// ---------------------------------------------------------------------------
enum class AdapterCommand : uint8_t {
  ClearCounters = 1,
  SetLdrp = 2,
  SetMdrp = 3,
};

// ---------------------------------------------------------------------------
// AdapterStatus - everything the Status frame reports, plus internal error
// counters. The wire Status frame carries the four traffic counters, the
// state, and the temperature; the error counters below are maintained for
// diagnostics and can be surfaced in a future Status v2 without changing the
// current layout.
// ---------------------------------------------------------------------------
struct AdapterStatus {
  AdapterState state = AdapterState::Booting;

  // Traffic counters (map 1:1 to the POC's four counters).
  uint64_t host_rx = 0;   // PADIL frames received from the USB host.
  uint64_t host_tx = 0;   // PADIL frames sent to the USB host.
  uint64_t rs485_rx = 0;  // PADIL messages decoded from RS-485.
  uint64_t rs485_tx = 0;  // PADIL messages transmitted onto RS-485.

  // CPU temperature in tenths of a degree Celsius. Valid only when
  // temp_available is true; otherwise the codec emits the sentinel.
  int32_t cpu_temp_tenths_c = 0;
  bool temp_available = false;

  // Diagnostic error counters (not on the wire in Status v1).
  uint32_t framing_errors = 0;      // Malformed / timed-out RS-485 frames.
  uint32_t edge_overflows = 0;      // ISR edge ring buffer overruns.
  uint32_t rx_msg_overflows = 0;    // Decoded-message queue overruns.
  uint32_t tx_msg_overflows = 0;    // Outbound RS-485 queue overruns.
  uint32_t invalid_commands = 0;    // Unknown / malformed host commands.
  uint32_t usb_send_drops = 0;      // RawHID sends that timed out / failed.
  uint32_t usb_decode_errors = 0;   // Inbound frames that failed to decode.
  uint32_t to_host_overflows = 0;   // Decoded messages dropped: to-host queue full.
};

// Sentinel written into the Status temperature field when no reading is
// available (INT32_MIN, distinct from any plausible real reading).
inline constexpr int32_t kTempUnavailableSentinel = static_cast<int32_t>(0x80000000);

// ---------------------------------------------------------------------------
// USB decode results.
// ---------------------------------------------------------------------------
enum class DecodeError : uint8_t {
  ShortFrame = 1,          // Fewer than 64 bytes delivered.
  IllegalTom = 2,          // TOM == 0.
  UnknownTom = 3,          // TOM outside 0..4.
  UnsupportedInbound = 4,  // A valid TOM the device never receives (Ack/Status).
  UnknownCommand = 5,      // Command frame with an unrecognised command byte.
};

// The only two frame kinds the device legitimately receives from the host.
enum class HostFrameKind : uint8_t { Padil, Command };

struct HostFrame {
  HostFrameKind kind = HostFrameKind::Padil;

  // Valid when kind == Padil.
  MessageNumber number = 0;
  PadilMessage payload{};

  // Valid when kind == Command.
  AdapterCommand command = AdapterCommand::ClearCounters;
};

}  // namespace bridge::domain
