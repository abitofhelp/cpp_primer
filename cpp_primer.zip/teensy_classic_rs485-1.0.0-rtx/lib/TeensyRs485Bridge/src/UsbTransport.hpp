// UsbTransport.hpp - Thin wrapper over the PJRC RawHID transport.
//
// Kept deliberately separate from UsbProtocol (the codec): this file is the
// ONLY place that touches usb_rawhid_send()/usb_rawhid_recv(). It moves opaque
// 64-byte frames; it has no idea what the bytes mean. That separation is what
// lets the codec be host-tested without a USB stack, and lets a future
// transport (a different HID endpoint, a test double) drop in unchanged.
//
// This header depends on the Teensy core, so it is compiled only in the
// firmware build - never from host-side unit tests.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <usb_rawhid.h>

#include "Config.hpp"
#include "Domain.hpp"

namespace bridge::usb {

class UsbTransport {
 public:
  // Configure the RawHID endpoint. Call once from setup().
  auto begin() noexcept -> void { usb_rawhid_configure(); }

  // Non-blocking send. Returns true when the full 64-byte frame was accepted by
  // the USB stack, false on timeout/backpressure (the caller counts the drop).
  [[nodiscard]] auto send(const domain::UsbFrame& frame) noexcept -> bool {
    const int sent = usb_rawhid_send(frame.bytes, config::kUsbSendTimeoutMs);
    return sent == static_cast<int>(domain::kUsbFrameSize);
  }

  // Non-blocking receive. Returns true and fills `frame` when a 64-byte frame
  // is available; false when nothing is waiting.
  [[nodiscard]] auto recv(domain::UsbFrame& frame) noexcept -> bool {
    const int got = usb_rawhid_recv(frame.bytes, config::kUsbRecvTimeoutMs);
    return got == static_cast<int>(domain::kUsbFrameSize);
  }
};

}  // namespace bridge::usb
