// PadilLineCodec.cpp - Hardware glue implementation.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include "PadilLineCodec.hpp"

// F_CPU_ACTUAL is the true core clock on Teensy 4.x (600 MHz -> 600 cycles/us).
// The POC hard-coded 528, which is wrong for this board.
#ifndef F_CPU_ACTUAL
#define F_CPU_ACTUAL F_CPU
#endif

namespace bridge::padil {

namespace {
namespace cfg = ::bridge::config;

// Single instance for the C-style ISR / timer trampolines.
PadilLineCodec* g_instance = nullptr;

auto edge_trampoline() -> void {
  if (g_instance != nullptr) {
    g_instance->on_edge_isr();
  }
}

auto tx_trampoline() -> void {
  if (g_instance != nullptr) {
    g_instance->on_tx_tick();
  }
}

[[nodiscard]] auto cycles_per_us() noexcept -> uint32_t {
  return static_cast<uint32_t>(F_CPU_ACTUAL / 1000000UL);
}

}  // namespace

auto PadilLineCodec::begin(rs485::Rs485Phy& phy) noexcept -> void {
  phy_ = &phy;
  g_instance = this;

  ARM_DEMCR |= ARM_DEMCR_TRCENA;
  ARM_DWT_CTRL |= ARM_DWT_CTRL_CYCCNTENA;

  speed_ = (cfg::kDefaultSpeed == cfg::DefaultSpeed::Mdrp) ? Speed::Mdrp : Speed::Ldrp;
  bit_period_us_ = (speed_ == Speed::Mdrp) ? cfg::kMdrpBitPeriodUs : cfg::kLdrpBitPeriodUs;
  recompute_timing();

  attachInterrupt(digitalPinToInterrupt(cfg::kRs485RxPin), edge_trampoline, CHANGE);
}

auto PadilLineCodec::set_speed(Speed speed) noexcept -> void {
  speed_ = speed;
  bit_period_us_ = (speed == Speed::Mdrp) ? cfg::kMdrpBitPeriodUs : cfg::kLdrpBitPeriodUs;
  recompute_timing();
}

auto PadilLineCodec::recompute_timing() noexcept -> void {
  bit_period_cycles_ = bit_period_us_ * cycles_per_us();
  framing_timeout_cycles_ = bit_period_cycles_ * cfg::kFramingTimeoutBitPeriods;
  decoder_.configure(bit_period_cycles_, cfg::kBitPeriodToleranceDiv, cfg::kLineCode);
}

// ---------------------------------------------------------------------------
// ISR context: capture only. Edges are ignored while we drive the bus so the
// transmitter never decodes its own signal.
// ---------------------------------------------------------------------------
auto PadilLineCodec::on_edge_isr() noexcept -> void {
  if (phy_ == nullptr || phy_->is_transmitting()) {
    return;
  }
  const EdgeEvent event{ARM_DWT_CYCCNT, static_cast<uint8_t>(phy_->read_rx() ? 1 : 0)};
  if (!edge_queue_.push(event)) {
    // Only this ISR writes edge_overflows_; relaxed fetch_add is a tear-free
    // read-modify-write with no ordering requirement (a pure diagnostic count).
    edge_overflows_.fetch_add(1, std::memory_order_relaxed);
  }
}

// ---------------------------------------------------------------------------
// Main-loop decode.
// ---------------------------------------------------------------------------
auto PadilLineCodec::poll() noexcept -> void {
  // TX cleanup (ADR-7) is observed here, in the main context, rather than mutating
  // decode state from the timer ISR. When the state machine is CleanupPending the
  // bus was driven during TX, so any stale edge reference is dropped and the
  // decoder restarts clean; only then is Idle published so the next begin_transmit()
  // can start. This CANNOT be skipped: begin_transmit() refuses any non-Idle state.
  if (tx_state_.load(std::memory_order_acquire) == TxState::CleanupPending) {
    have_prev_edge_ = false;
    decoder_.reset();
    tx_state_.store(TxState::Idle, std::memory_order_release);
  }

  for (;;) {
    const auto next = edge_queue_.pop();
    if (!next) {
      break;
    }
    const EdgeEvent event = next.value();

    if (!have_prev_edge_) {
      have_prev_edge_ = true;
      prev_edge_cycles_ = event.cycles;
      prev_level_ = event.level;
      last_progress_cycles_ = event.cycles;
      continue;
    }

    const uint32_t dt = event.cycles - prev_edge_cycles_;
    // The level held during the segment that just ended is the PREVIOUS edge's
    // post-level (used only by the NRZ experiment; ignored by Manchester).
    (void)decoder_.feed_segment(dt, prev_level_);

    prev_edge_cycles_ = event.cycles;
    prev_level_ = event.level;
    last_progress_cycles_ = event.cycles;
  }

  // Partial-frame timeout. Valid for differential Manchester because the line
  // guarantees a transition at least once per bit period.
  if (decoder_.in_frame() && have_prev_edge_) {
    if ((ARM_DWT_CYCCNT - last_progress_cycles_) > framing_timeout_cycles_) {
      decoder_.note_timeout();
    }
  }
}

// ---------------------------------------------------------------------------
// Transmit.
// ---------------------------------------------------------------------------
auto PadilLineCodec::begin_transmit(const domain::PadilMessage& message) noexcept -> bool {
  // ADR-7: start ONLY from Idle. Active means a TX is in progress; CleanupPending
  // means the prior TX's decoder cleanup has not run yet - starting now would skip
  // it. begin_transmit() and poll() are both main-context, so a plain guarded load
  // is sufficient (the timer ISR only moves Active -> CleanupPending).
  if (phy_ == nullptr || tx_state_.load(std::memory_order_acquire) != TxState::Idle) {
    return false;
  }

  tx_buffer_[0] = cfg::kSomByte0;
  tx_buffer_[1] = cfg::kSomByte1;
  for (size_t i = 0; i < domain::kPadilPayloadSize; ++i) {
    tx_buffer_[kTxSomBytes + i] = message.bytes[i];
  }

  tx_state_.store(TxState::Active, std::memory_order_release);
  phy_->set_transmit();

  float tick_us = 0.0F;
  if constexpr (cfg::kLineCode == LineCode::DifferentialManchester) {
    // Emit the opening boundary (slot 0) immediately, then tick every half cell
    // for slots 1..2N.
    tx_current_level_ = !tx_current_level_;
    phy_->write_tx(tx_current_level_);
    tx_slot_ = 1;
    tick_us = static_cast<float>(bit_period_us_) / 2.0F;
  } else {
    // EXPERIMENTAL NRZ: drive bit 0 immediately, one bit per full period after.
    tx_current_level_ = (frame_bit_msb(tx_buffer_, 0) != 0);
    phy_->write_tx(tx_current_level_);
    tx_slot_ = 1;  // Next timer tick drives bit index 1.
    tick_us = static_cast<float>(bit_period_us_);
  }

  if (!tx_timer_.begin(tx_trampoline, tick_us)) {
    // Timer refused to start: release the bus and report failure rather than
    // leaving DE asserted and the state machine stuck in Active. No cleanup is
    // pending (nothing was decoded during this aborted TX), so go straight to Idle.
    phy_->set_receive();
    tx_slot_ = 0;
    tx_state_.store(TxState::Idle, std::memory_order_release);
    return false;
  }
  return true;
}

auto PadilLineCodec::on_tx_tick() noexcept -> void {
  if constexpr (cfg::kLineCode == LineCode::DifferentialManchester) {
    const uint32_t slot = tx_slot_;
    if (slot <= 2U * kTxTotalBits) {
      if (manchester_toggle_at(slot, tx_buffer_, kTxTotalBits)) {
        tx_current_level_ = !tx_current_level_;
        phy_->write_tx(tx_current_level_);
      }
      tx_slot_ = slot + 1;
    } else {
      // One half-cell after the closing boundary: hold done, release cleanly.
      finish_transmit();
    }
  } else {
    // EXPERIMENTAL NRZ path.
    const uint32_t bit_index = tx_slot_;
    if (bit_index < kTxTotalBits) {
      tx_current_level_ = (frame_bit_msb(tx_buffer_, bit_index) != 0);
      phy_->write_tx(tx_current_level_);
      tx_slot_ = bit_index + 1;
    } else {
      finish_transmit();
    }
  }
}

auto PadilLineCodec::finish_transmit() noexcept -> void {
  tx_timer_.end();
  if (phy_ != nullptr) {
    phy_->set_receive();  // Return to the safe default (DE released, then flag cleared).
  }
  // ADR-7: move Active -> CleanupPending ONLY after the bus is safely back in
  // receive. is_transmitting() now reports false (so a controller may ACK), but
  // begin_transmit() stays refused until poll() resets the decoder and publishes
  // Idle - so the prior TX's cleanup can never be skipped.
  tx_state_.store(TxState::CleanupPending, std::memory_order_release);
}

}  // namespace bridge::padil
