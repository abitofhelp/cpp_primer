// Ports.hpp - The static-dispatch port contracts for BridgeController.
//
// BridgeController is a noexcept template over three ports (USB, line, platform).
// These concepts are the contracts its adapters must satisfy. They are
// deliberately EXACT and noexcept, not permissive:
//   * `noexcept` - the controller is noexcept end to end. A throwing adapter
//     method would call std::terminate() from within a noexcept frame, so the
//     concept forbids one at compile time rather than discovering it at runtime.
//   * `std::same_as<...>` (exact return types) - not `std::convertible_to`. An
//     accessor that returned, say, `int` where `uint32_t` is expected would
//     silently convert; requiring the exact type keeps the wire/semantic contract
//     honest and catches adapter drift.
//
// The real Teensy adapters (UsbTransport, PadilLineCodec, TeensyPlatform) satisfy
// these, and so do the host test doubles - which is why BridgeController is
// Arduino-free and unit-testable. This header is Arduino-free.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <concepts>
#include <cstdint>

#include "Core.hpp"
#include "Domain.hpp"
#include "PadilBitLayer.hpp"  // padil::Speed

namespace bridge::app {

// USB RawHID transport: move opaque 64-byte frames, no protocol knowledge.
template <typename T>
concept UsbPort = requires(T t, const domain::UsbFrame& out, domain::UsbFrame& in) {
  { t.send(out) } noexcept -> std::same_as<bool>;
  { t.recv(in) } noexcept -> std::same_as<bool>;
};

// RS-485/PADIL line: decode captured edges, transmit, and report diagnostics.
template <typename T>
concept LinePort =
    requires(T t, const domain::PadilMessage& msg, padil::Speed speed) {
      { t.poll() } noexcept -> std::same_as<void>;
      { t.take_received() } noexcept -> std::same_as<core::Option<domain::PadilMessage>>;
      { t.begin_transmit(msg) } noexcept -> std::same_as<bool>;
      { t.is_transmitting() } noexcept -> std::same_as<bool>;
      { t.set_speed(speed) } noexcept -> std::same_as<void>;
      { t.framing_errors() } noexcept -> std::same_as<uint32_t>;
      { t.edge_overflows() } noexcept -> std::same_as<uint32_t>;
      { t.rx_msg_overflows() } noexcept -> std::same_as<uint32_t>;
    };

// Board services: microsecond clock, indicator LEDs, CPU temperature.
template <typename T>
concept PlatformPort = requires(T t, bool on, domain::Led led) {
  { t.micros() } noexcept -> std::same_as<uint32_t>;
  { t.set_led(led, on) } noexcept -> std::same_as<void>;
  { t.cpu_temp_tenths() } noexcept -> std::same_as<core::Option<int32_t>>;
};

// ---------------------------------------------------------------------------
// Compile-time proof that the concepts accept a conforming adapter and REJECT
// the two ways an adapter usually drifts: a throwing (non-noexcept) method, and
// a wrong (merely convertible) return type. These doubles exist only to pin the
// concept semantics; they are not used at runtime.
// ---------------------------------------------------------------------------
namespace ports_detail {

struct GoodUsb {
  auto send(const domain::UsbFrame&) noexcept -> bool { return true; }
  auto recv(domain::UsbFrame&) noexcept -> bool { return false; }
};
struct ThrowingUsb {
  auto send(const domain::UsbFrame&) -> bool { return true; }  // not noexcept
  auto recv(domain::UsbFrame&) noexcept -> bool { return false; }
};
struct WrongReturnUsb {
  auto send(const domain::UsbFrame&) noexcept -> int { return 1; }  // int, not bool
  auto recv(domain::UsbFrame&) noexcept -> bool { return false; }
};

static_assert(UsbPort<GoodUsb>, "a conforming USB adapter must satisfy UsbPort");
static_assert(!UsbPort<ThrowingUsb>, "UsbPort must reject a throwing send()");
static_assert(!UsbPort<WrongReturnUsb>, "UsbPort must reject a non-bool send()");

}  // namespace ports_detail

}  // namespace bridge::app
