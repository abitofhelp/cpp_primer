// BridgeController.hpp - Application bridge between USB RawHID and RS-485/PADIL.
//
// The controller is a template over three ports (USB, line, platform), each a
// C++20 concept. The real Teensy adapters (UsbTransport, PadilLineCodec,
// TeensyPlatform) satisfy the concepts, and so do the host test doubles - which
// is why this whole file is Arduino-free and unit-testable. All hardware lives
// in the adapters and the composition root (main.cpp); none is here.
//
// ACK policy (revised - matches the host's pacing expectation):
//   * A host PADIL frame is queued for RS-485 transmit WITHOUT an immediate ACK.
//     Its message number rides through the queue (domain::OutboundPadil).
//   * The ACK is emitted only AFTER the payload has physically completed RS-485
//     transmission, and is retained across USB backpressure until delivered.
//
// Backpressure / numbering policy:
//   * A decoded RS-485 message is assigned a device->host number when it is
//     enqueued for USB (domain::HostboundPadil) and that number is preserved
//     across USB send failures. The message is removed from the to-host queue
//     only after the RawHID send succeeds (peek -> send -> pop-on-success), so
//     nothing is lost to transient backpressure. Only a full to-host queue
//     drops a message (counted in to_host_overflows).
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <cstdint>

#include "Config.hpp"
#include "Core.hpp"
#include "Domain.hpp"
#include "PadilBitLayer.hpp"  // padil::Speed
#include "Ports.hpp"          // UsbPort / LinePort / PlatformPort concepts
#include "UsbProtocol.hpp"

namespace bridge::app {

// ---------------------------------------------------------------------------
// BridgeController
// ---------------------------------------------------------------------------
template <UsbPort Usb, LinePort Line, PlatformPort Platform>
class BridgeController {
 public:
  BridgeController(Usb& usb, Line& line, Platform& platform) noexcept
      : usb_(usb), line_(line), platform_(platform) {}

  // Reset service timers/state. Hardware bring-up happens in the composition
  // root before this is called.
  auto begin() noexcept -> void {
    const uint32_t now = platform_.micros();
    last_usb_poll_us_ = now - config::kUsbPollIntervalUs;  // Poll on first cycle.
    last_status_us_ = now;
  }

  // One non-blocking service cycle.
  auto poll() noexcept -> void {
    now_us_ = platform_.micros();

    if (elapsed(now_us_, last_usb_poll_us_) >= config::kUsbPollIntervalUs) {
      last_usb_poll_us_ = now_us_;
      service_usb_receive();
    }

    line_.poll();                 // Advance RS-485 decode from captured edges.
    drain_decoded_to_host();      // Number decoded messages, enqueue for USB.
    service_to_host();            // peek -> send -> pop-on-success.
    service_rs485_transmit();     // ACK-after-TX + start next transmit.

    if (elapsed(now_us_, last_status_us_) >= config::kStatusPeriodUs) {
      last_status_us_ = now_us_;
      service_status();
    }

    service_leds();               // Heartbeat + transfer/error pulses.
  }

  // Read-only snapshot of counters/state (the same aggregate a Status frame
  // carries). Does not touch the transport.
  [[nodiscard]] auto snapshot() const noexcept -> domain::AdapterStatus {
    return build_status();
  }

 private:
  [[nodiscard]] static auto elapsed(uint32_t now, uint32_t since) noexcept -> uint32_t {
    return now - since;  // Unsigned wrap handles the micros() rollover.
  }

  auto send_or_drop(const domain::UsbFrame& frame) noexcept -> bool {
    if (usb_.send(frame)) {
      return true;
    }
    ++usb_send_drops_;
    return false;
  }

  // --- Host -> device ------------------------------------------------------
  auto service_usb_receive() noexcept -> void {
    for (size_t i = 0; i < config::kRs485TxMsgQueueCapacity; ++i) {
      if (!usb_.recv(rx_frame_)) {
        return;
      }
      const auto decoded = usb::decode_host_frame(rx_frame_);
      if (decoded.is_err()) {
        ++usb_decode_errors_;
        if (decoded.error() == domain::DecodeError::UnknownCommand) {
          ++invalid_commands_;
        }
        continue;
      }
      handle_host_frame(decoded.value());
    }
  }

  auto handle_host_frame(const domain::HostFrame& frame) noexcept -> void {
    if (frame.kind == domain::HostFrameKind::Command) {
      handle_command(frame.command);
      return;
    }
    // PADIL from host: queue for transmit, carrying the host number. Do NOT ACK
    // now - the ACK is sent after the payload physically transmits.
    ++host_rx_;
    const domain::OutboundPadil item{frame.number, frame.payload};
    if (!tx_queue_.push(item)) {
      ++tx_msg_overflows_;  // Full: drop and do not ACK (host detects the loss).
    }
  }

  auto handle_command(domain::AdapterCommand command) noexcept -> void {
    switch (command) {
      case domain::AdapterCommand::ClearCounters:
        clear_counters();
        break;
      case domain::AdapterCommand::SetLdrp:
        line_.set_speed(padil::Speed::Ldrp);
        break;
      case domain::AdapterCommand::SetMdrp:
        line_.set_speed(padil::Speed::Mdrp);
        break;
    }
  }

  auto clear_counters() noexcept -> void {
    host_rx_ = 0;
    host_tx_ = 0;
    rs485_rx_ = 0;
    rs485_tx_ = 0;
    tx_msg_overflows_ = 0;
    to_host_overflows_ = 0;
    invalid_commands_ = 0;
    usb_send_drops_ = 0;
    usb_decode_errors_ = 0;
    // Reset the LED edge-detect baselines so cleared counters do not suppress
    // the next transfer/error pulse.
    prev_transfer_total_ = 0;
    prev_error_total_ = total_errors();  // Line-layer errors are not cleared.
    // Line-layer diagnostics (framing/edge/rx overflows) are cumulative since
    // boot and are intentionally not reset here.
  }

  // --- RS-485 -> host ------------------------------------------------------
  auto drain_decoded_to_host() noexcept -> void {
    for (;;) {
      const auto message = line_.take_received();
      if (!message) {
        return;
      }
      ++rs485_rx_;
      const domain::HostboundPadil item{out_msg_number_, message.value()};
      if (to_host_queue_.push(item)) {
        ++out_msg_number_;  // Number consumed only when the message is buffered.
      } else {
        ++to_host_overflows_;  // Buffer full: drop; the number is not consumed.
      }
    }
  }

  auto service_to_host() noexcept -> void {
    for (;;) {
      const auto next = to_host_queue_.peek();
      if (!next) {
        return;
      }
      usb::encode_padil(tx_frame_, next.value().number, next.value().payload);
      if (!send_or_drop(tx_frame_)) {
        return;  // Backpressure: keep the message (and its number) for retry.
      }
      (void)to_host_queue_.pop();  // Committed only after a successful send.
      ++host_tx_;
    }
  }

  // --- RS-485 transmit + ACK ----------------------------------------------
  auto service_rs485_transmit() noexcept -> void {
    const bool tx_now = line_.is_transmitting();

    // Physical transmit just completed -> stage the ACK.
    if (in_flight_valid_ && was_transmitting_ && !tx_now) {
      ++rs485_tx_;
      pending_ack_number_ = in_flight_number_;
      pending_ack_valid_ = true;
      in_flight_valid_ = false;
    }
    was_transmitting_ = tx_now;

    // Deliver a staged ACK, retaining it across USB backpressure.
    if (pending_ack_valid_) {
      usb::encode_ack(tx_frame_, pending_ack_number_);
      if (send_or_drop(tx_frame_)) {
        pending_ack_valid_ = false;
      }
    }

    // Start the next transmit only when the line is idle, nothing is in flight,
    // and the previous ACK has been delivered (one message paced at a time).
    if (!tx_now && !in_flight_valid_ && !pending_ack_valid_) {
      const auto next = tx_queue_.peek();
      if (next && line_.begin_transmit(next.value().payload)) {
        in_flight_number_ = next.value().host_number;
        in_flight_valid_ = true;
        was_transmitting_ = true;  // It is transmitting now.
        (void)tx_queue_.pop();
      }
    }
  }

  // --- Status --------------------------------------------------------------
  auto service_status() noexcept -> void {
    usb::encode_status(tx_frame_, build_status());
    (void)send_or_drop(tx_frame_);
    led_on_ = !led_on_;
    platform_.set_led(domain::Led::Status, led_on_);  // Heartbeat.
  }

  // Data-transfer LED (pin 35) pulses on any successful PADIL transfer; the
  // error LED (pin 34) pulses when any error counter advances. Edge-detected on
  // running totals so no counting logic is scattered through the services.
  auto service_leds() noexcept -> void {
    const uint64_t transfers = host_tx_ + rs485_tx_;
    if (transfers > prev_transfer_total_) {
      prev_transfer_total_ = transfers;
      transfer_pulse_until_ = now_us_ + config::kLedPulseUs;
    }
    const uint64_t errors = total_errors();
    if (errors > prev_error_total_) {
      prev_error_total_ = errors;
      error_pulse_until_ = now_us_ + config::kLedPulseUs;
    }
    platform_.set_led(domain::Led::Transfer, pulse_active(transfer_pulse_until_));
    platform_.set_led(domain::Led::Error, pulse_active(error_pulse_until_));
  }

  [[nodiscard]] auto total_errors() const noexcept -> uint64_t {
    return static_cast<uint64_t>(line_.framing_errors()) + line_.edge_overflows() +
           line_.rx_msg_overflows() + tx_msg_overflows_ + to_host_overflows_ +
           invalid_commands_ + usb_send_drops_ + usb_decode_errors_;
  }

  // A pulse is active while now precedes its deadline (signed diff => wrap-safe).
  [[nodiscard]] auto pulse_active(uint32_t until) const noexcept -> bool {
    return static_cast<int32_t>(until - now_us_) > 0;
  }

  [[nodiscard]] auto build_status() const noexcept -> domain::AdapterStatus {
    domain::AdapterStatus status;
    status.state = current_state();
    status.host_rx = host_rx_;
    status.host_tx = host_tx_;
    status.rs485_rx = rs485_rx_;
    status.rs485_tx = rs485_tx_;

    const auto temp = platform_.cpu_temp_tenths();
    status.temp_available = temp.has_value();
    status.cpu_temp_tenths_c = temp.value_or(0);

    status.framing_errors = line_.framing_errors();
    status.edge_overflows = line_.edge_overflows();
    status.rx_msg_overflows = line_.rx_msg_overflows();
    status.tx_msg_overflows = tx_msg_overflows_;
    status.to_host_overflows = to_host_overflows_;
    status.invalid_commands = invalid_commands_;
    status.usb_send_drops = usb_send_drops_;
    status.usb_decode_errors = usb_decode_errors_;
    return status;
  }

  [[nodiscard]] auto current_state() const noexcept -> domain::AdapterState {
    if (in_flight_valid_ || pending_ack_valid_) {
      return domain::AdapterState::Transmitting;
    }
    if (!to_host_queue_.empty() || !tx_queue_.empty()) {
      return domain::AdapterState::Receiving;
    }
    return domain::AdapterState::Idle;
  }

  Usb& usb_;
  Line& line_;
  Platform& platform_;

  core::FixedQueue<domain::OutboundPadil, config::kRs485TxMsgQueueCapacity> tx_queue_;
  core::FixedQueue<domain::HostboundPadil, config::kRs485RxMsgQueueCapacity> to_host_queue_;

  domain::UsbFrame rx_frame_{};
  domain::UsbFrame tx_frame_{};

  // Traffic counters.
  uint64_t host_rx_ = 0;
  uint64_t host_tx_ = 0;
  uint64_t rs485_rx_ = 0;
  uint64_t rs485_tx_ = 0;

  // Error counters.
  uint32_t tx_msg_overflows_ = 0;
  uint32_t to_host_overflows_ = 0;
  uint32_t invalid_commands_ = 0;
  uint32_t usb_send_drops_ = 0;
  uint32_t usb_decode_errors_ = 0;

  // Device -> host numbering. Starts at 0 to match the POC (txMessageNumber).
  domain::MessageNumber out_msg_number_ = 0;

  // ACK-after-TX bookkeeping.
  bool was_transmitting_ = false;
  bool in_flight_valid_ = false;
  domain::MessageNumber in_flight_number_ = 0;
  bool pending_ack_valid_ = false;
  domain::MessageNumber pending_ack_number_ = 0;

  // Service timing.
  uint32_t now_us_ = 0;  // Captured at the top of each poll().
  uint32_t last_usb_poll_us_ = 0;
  uint32_t last_status_us_ = 0;

  // LED state.
  bool led_on_ = false;                 // Heartbeat toggle.
  uint32_t transfer_pulse_until_ = 0;   // Transfer LED deadline.
  uint32_t error_pulse_until_ = 0;      // Error LED deadline.
  uint64_t prev_transfer_total_ = 0;    // Edge-detect baseline (host_tx+rs485_tx).
  uint64_t prev_error_total_ = 0;       // Edge-detect baseline (all error counters).
};

// Deduction guide so the composition root can write BridgeController{u, l, p}.
template <typename U, typename L, typename P>
BridgeController(U&, L&, P&) -> BridgeController<U, L, P>;

}  // namespace bridge::app
