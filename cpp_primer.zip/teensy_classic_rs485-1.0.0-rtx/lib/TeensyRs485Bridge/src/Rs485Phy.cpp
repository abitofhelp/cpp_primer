// Rs485Phy.cpp - Teensy 4.1 implementation of the RS-485 physical layer.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include "Rs485Phy.hpp"

#include <Arduino.h>

#include "Config.hpp"

namespace bridge::rs485 {

namespace {
namespace cfg = ::bridge::config;

// ARM data memory barrier (ADR-2). Orders the receive-suppression flag store
// against the DE//RE GPIO (MMIO/device-memory) writes - a relaxed atomic on
// normal memory does not order against peripheral writes. The "memory" clobber
// also makes it a compiler barrier. This TU is firmware-only (ARM), so inline
// asm is safe and avoids depending on a CMSIS __DMB() macro the core may not export.
inline auto data_memory_barrier() noexcept -> void {
  asm volatile("dmb" ::: "memory");
}
}  // namespace

auto Rs485Phy::begin() noexcept -> void {
  pinMode(cfg::kRs485DePin, OUTPUT);
  if (!cfg::kRs485DeReShared) {
    pinMode(cfg::kRs485RePin, OUTPUT);
  }
  pinMode(cfg::kRs485TxPin, OUTPUT);
  pinMode(cfg::kRs485RxPin, INPUT);

  // Idle the TX line and start in receive mode - the safe default so the
  // adapter never drives a shared bus unexpectedly at power-up.
  digitalWriteFast(cfg::kRs485TxPin, LOW);
  set_receive();
}

auto Rs485Phy::set_direction(bool transmit) noexcept -> void {
  // ADR-2 direction sequencing. A relaxed atomic flag alone does NOT order a
  // normal-memory store against the DE//RE peripheral (MMIO) writes, so an
  // explicit ARM `dmb` (data_memory_barrier()) enforces the hardware order; it is
  // also a compiler barrier, so neither the compiler nor the CPU reorders across it.
  if (transmit) {
    // Entering TX: PUBLISH the suppression flag BEFORE enabling the driver, so
    // the edge ISR cannot capture our own first transmitted transition.
    transmitting_.store(true, std::memory_order_relaxed);
    data_memory_barrier();
    digitalWriteFast(cfg::kRs485DePin, HIGH);  // DE active HIGH -> driver on.
    if (!cfg::kRs485DeReShared) {
      digitalWriteFast(cfg::kRs485RePin, HIGH);  // /RE HIGH -> receiver off.
    }
  } else {
    // Leaving TX: DISABLE the driver FIRST, then clear suppression, so no
    // trailing self-driven edge is decoded as bus input.
    digitalWriteFast(cfg::kRs485DePin, LOW);  // DE LOW -> driver off.
    if (!cfg::kRs485DeReShared) {
      digitalWriteFast(cfg::kRs485RePin, LOW);  // /RE LOW -> receiver on.
    }
    data_memory_barrier();
    transmitting_.store(false, std::memory_order_relaxed);
  }
}

auto Rs485Phy::set_receive() noexcept -> void { set_direction(false); }

auto Rs485Phy::set_transmit() noexcept -> void { set_direction(true); }

auto Rs485Phy::read_rx() const noexcept -> bool {
  return digitalReadFast(cfg::kRs485RxPin) != LOW;
}

auto Rs485Phy::write_tx(bool level) noexcept -> void {
  digitalWriteFast(cfg::kRs485TxPin, level ? HIGH : LOW);
}

}  // namespace bridge::rs485
