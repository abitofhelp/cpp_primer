// Rs485Phy.hpp - Half-duplex RS-485 physical-layer abstraction.
//
// Owns direction control (DE and /RE) and the raw RX/TX logic-level access.
// The line codec talks to the bus ONLY through this interface, so the codec
// carries no knowledge of a specific transceiver. Swapping the prototype
// MAX485 for the target TI THVD2450V is a change confined to this module (and
// possibly the Config pins) - the USB framing and application protocol are
// untouched.
//
// >>> ELECTRICAL WARNING (Teensy 4.1 is 3.3 V, NOT 5 V tolerant) <<<
// A MAX485 powered at 5 V drives its RO (receiver output) at 5 V logic. Wiring
// RO directly to kRs485RxPin can damage the Teensy. RO MUST be level-shifted
// to 3.3 V (divider or level-shifter IC) before reaching the input pin. The
// THVD2450V can be operated at 3.3 V, which removes this hazard - prefer that
// on the target board. DI/DE//RE inputs are 3.3 V-compatible on both parts.
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#pragma once

#include <atomic>

namespace bridge::rs485 {

// Direction-control model for MAX485-style transceivers:
//   DE  is active HIGH (driver enabled when HIGH).
//   /RE is active LOW  (receiver enabled when LOW).
// To transmit: DE = HIGH, /RE = HIGH (driver on, receiver off).
// To receive : DE = LOW,  /RE = LOW  (driver off, receiver on).
// Because both move together, a single shared control line works: HIGH =
// transmit, LOW = receive (see Config::kRs485DeReShared).
class Rs485Phy {
 public:
  // Configure pins and enter receive mode. Call once from setup().
  auto begin() noexcept -> void;

  // Enter receive mode: driver disabled, receiver enabled. This is the safe
  // default and is re-entered automatically after every transmission.
  auto set_receive() noexcept -> void;

  // Enter transmit mode: driver enabled, receiver disabled.
  auto set_transmit() noexcept -> void;

  // Read the current logic level on the RX pin (transceiver RO, level-shifted).
  [[nodiscard]] auto read_rx() const noexcept -> bool;

  // Drive the TX pin (transceiver DI) to `level`. Only affects the bus while in
  // transmit mode; in receive mode the driver is disabled.
  auto write_tx(bool level) noexcept -> void;

  [[nodiscard]] auto is_transmitting() const noexcept -> bool {
    return transmitting_.load(std::memory_order_relaxed);
  }

 private:
  auto set_direction(bool transmit) noexcept -> void;

  // Receive-suppression flag: written from the main loop and the TX timer ISR
  // (set_receive at end of transmit); read from the GPIO edge ISR to gate
  // self-reception. std::atomic (not volatile) so the flag is a real, tear-free
  // synchronization variable; set_direction() adds an explicit ARM `DMB` (ADR-2)
  // to order this flag against the DE//RE MMIO writes, which a normal-memory
  // atomic does not do on its own.
  static_assert(std::atomic<bool>::is_always_lock_free,
                "transmitting_ must be lock-free for ISR-safe access");
  std::atomic<bool> transmitting_{false};
};

}  // namespace bridge::rs485
