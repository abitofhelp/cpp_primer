# Changelog

All notable changes to `teensy_classic_rs485` are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html),
and commit messages follow
[Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) — so entries
below are grouped by the commit type that produced them (`feat`, `fix`, `docs`,
`build`, `test`, …).

## [Unreleased]

_The 1.0.0 firmware is software- and documentation-complete and is released as such.
The remaining milestone — full RS-485 bench validation with transceiver hardware (the
ADR-1, ADR-2, ADR-4, and ADR-5 gates marked "pending HW") — is tracked in
[`docs/decisions/`](docs/decisions/) and
[`docs/HARDWARE_VALIDATION.md`](docs/HARDWARE_VALIDATION.md), and will land in a point
release once bench time on RS-485 hardware is available._

## [1.0.0] - 2026-07-14

Teensy 4.1 + MAX485 **RS-485 ↔ USB RawHID bridge** firmware, built on a hexagonal
(ports & adapters) / DDD / Clean hybrid architecture in C++20, with a build and
configuration environment aligned to the `teensy_sos` reference.

### Features

- **Canonical shared library** (`lib/TeensyRs485Bridge/`) — the single C++20
  implementation compiled by BOTH command-line frontends: domain types, the PADIL
  protocol and differential-Manchester line codec, the port concepts, the templated
  `BridgeController`, and the Teensy platform/RS-485/USB-RawHID adapters. Both
  composition roots are thin and hold no duplicated logic.
- **Hexagonal firmware core** — `BridgeController` application logic behind exact,
  `noexcept` C++20 concept ports (`UsbPort`, `LinePort`, `PlatformPort` in
  `Ports.hpp`), with adapters for RawHID USB transport, the PADIL line codec, MAX485
  direction control, and the Teensy platform.
- **Concurrency & correctness hardening** — the ISR↔main SPSC edge queue uses
  `std::atomic` acquire/release ordering (lock-free, verified in disassembly); the
  RS-485 direction control publishes its receive-suppression flag with an explicit
  ARM `dmb` to close a self-reception race; the transmit lifecycle is an explicit
  `Idle→Active→CleanupPending→Idle` state machine that cannot skip decoder cleanup;
  and `Option::value_or` returns by value. The decisions are recorded as ADRs in
  [`docs/decisions/`](docs/decisions/).
- **PADIL protocol over RS-485** — 27-byte PADIL messages (SOM `0xAA 0xCC`) carried
  over the RS-485 electrical layer, bridged to fixed **64-byte USB RawHID** frames
  (TOM: 1 = PADIL, 2 = ACK, 3 = Status, 4 = Command), with ACK policy, backpressure,
  and monotonic frame numbering.
- **PlatformIO CLI frontend** (default) — `make build` / `make upload`, an offline
  package cache (`make pio-prime` / `pio-bundle` / `build-offline`) for
  restricted-network builds, and standalone air-gap `.hex` flashing (`make flash`).
- **Arduino CLI frontend** — `make arduino-build` / `make arduino-upload` compile the
  same canonical library with GNU C++20 and USB Raw HID (`--board-options usb=rawhid`);
  `make build-all` builds both frontends (identical firmware size).
- **Cross-platform Makefile** — macOS, Linux, and Windows/MSYS2 host detection
  (`$(EXE)`, `g++` vs `c++`) for host tests, and a `CPATH`-sanitized firmware build.
- **Host unit tests** (`make test`) — 177 checks across the shared kernel
  (FixedQueue, including a wraparound stress and the `value_or` temporary-lifetime
  guard), the USB RawHID codec, the PADIL bit layer, and the `BridgeController`
  (ACK / backpressure / numbering, plus the ADR-7 TX-cleanup regression), on any
  C++20 compiler.
- **Review packaging** (`make package`) — a clean ZIP that excludes junk and
  private artifacts.

### Documentation

- Architecture overview with the ISR/main/timer ownership map
  ([`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)), the concurrency/port ADRs
  ([`docs/decisions/`](docs/decisions/)), a RawHID-specific debugging guide
  ([`docs/DEBUGGING.md`](docs/DEBUGGING.md)), and a build/toolchain inventory
  ([`docs/PACKAGE_INVENTORY.md`](docs/PACKAGE_INVENTORY.md)).
- Original-POC hardware/software review issue documents (Typst → PDF), a build
  guide, a hardware bench-validation procedure, and rendered PlantUML
  architecture / sequence / timing diagrams.

### Tests

- Host suites for the FixedQueue kernel, the USB RawHID codec, the PADIL
  differential-Manchester bit layer, and the `BridgeController` state machine.

### Notes

- Validated: host test suites pass (177 checks, 0 failures) and **both frontends
  compile** the firmware to identical size (`FLASH code:15,972`) — PlatformIO
  (`make build`) and Arduino CLI (`make arduino-build`). The release build is
  verified lock-free in disassembly (no `__atomic_*` libcalls).
- **Hardware smoke test passed** — the firmware was flashed to a physical Teensy 4.1
  via both frontends and boots into its 1 s status heartbeat (pin 13). The remaining
  milestone is the **full RS-485 bench validation** with transceiver hardware:
  the RO → pin-2 protection divider (≤ 3.3 V), the differential-Manchester timing,
  DE assert/release, and the ADR-4 ISR timing qualification. See
  [`docs/HARDWARE_VALIDATION.md`](docs/HARDWARE_VALIDATION.md) and
  [`docs/decisions/`](docs/decisions/).
- Proprietary to RTX/Raytheon, All Rights Reserved. A more complete proprietary
  license statement is TBD.

[Unreleased]: https://github.com/abitofhelp/teensy_classic_rs485/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/abitofhelp/teensy_classic_rs485/releases/tag/v1.0.0
