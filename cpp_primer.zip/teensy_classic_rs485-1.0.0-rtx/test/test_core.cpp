// test_core.cpp - Host-side unit tests for the shared kernel (FixedQueue).
//
// Build & run:
//   c++ -std=c++20 -I../src test_core.cpp -o test_core && ./test_core
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include <cstdint>
#include <cstdio>
#include <type_traits>

#include "Core.hpp"

namespace {

int g_checks = 0;
int g_failures = 0;
void check(bool cond, const char* what) {
  ++g_checks;
  if (!cond) {
    ++g_failures;
    std::printf("  FAIL: %s\n", what);
  }
}

using bridge::core::FixedQueue;
using bridge::core::Option;

// Returns a temporary; used to exercise value_or's temporary-fallback path.
[[nodiscard]] auto make_fallback() noexcept -> int { return 99; }

void test_option_value_or() {
  std::printf("test_option_value_or\n");
  // Must return T BY VALUE: a const T& return would dangle when the fallback is
  // a temporary (value_or(0)) - this static_assert is the compile-time guard.
  static_assert(std::is_same_v<decltype(Option<int>::none().value_or(0)), int>,
                "value_or must return T by value, not a reference that can dangle");

  check(Option<int>::none().value_or(42) == 42, "value_or returns the fallback for none");
  check(Option<int>::some(7).value_or(42) == 7, "value_or returns the value when present");

  // Temporary-lifetime path: bind the result to a reference. With return-by-value
  // the returned prvalue is lifetime-extended and valid; the old const T& return
  // would have referenced a destroyed temporary here.
  const auto& bound = Option<int>::none().value_or(make_fallback());
  check(bound == 99, "value_or result stays valid after a temporary fallback");
}

// Single-threaded exhaustion of the ring: millions of interleaved push/pop cycles
// that repeatedly cross the wrap boundary and hit the full/empty edges. Proves
// FIFO order and occupancy accounting over far more wraps than any hand case.
// (True concurrent ordering is guaranteed by the acquire/release atomics and the
// lock-free disassembly check; this guards the ring arithmetic.)
void test_fixed_queue_wraparound_stress() {
  std::printf("test_fixed_queue_wraparound_stress\n");
  FixedQueue<uint32_t, 8> q;  // usable capacity 7
  uint32_t next_push = 0;     // next value to push
  uint32_t next_pop = 0;      // next value expected out
  uint32_t in_flight = 0;
  bool order_ok = true;
  bool count_ok = true;
  const uint32_t kIterations = 5'000'000;
  for (uint32_t i = 0; i < kIterations; ++i) {
    const bool do_push = (in_flight == 0) || (in_flight < 7 && (i % 3 != 0));
    if (do_push) {
      if (q.push(next_push)) {
        ++next_push;
        ++in_flight;
      }
    } else {
      const auto v = q.pop();
      if (v) {
        if (v.value() != next_pop) {
          order_ok = false;
        }
        ++next_pop;
        --in_flight;
      }
    }
    if (q.count() != in_flight) {
      count_ok = false;
    }
  }
  while (auto v = q.pop()) {  // drain the remainder
    if (v.value() != next_pop) {
      order_ok = false;
    }
    ++next_pop;
  }
  check(order_ok, "FIFO order preserved across millions of wraps");
  check(count_ok, "count() tracks occupancy throughout (single-threaded)");
  check(next_pop == next_push, "every pushed value was popped exactly once");
  check(q.empty(), "queue is empty after the stress drain");
}

void test_fixed_queue() {
  std::printf("test_fixed_queue\n");
  FixedQueue<int, 4> q;  // usable capacity = N - 1 = 3

  check(q.capacity() == 3, "usable capacity is N-1 (documented)");
  check(q.empty(), "new queue is empty");
  check(q.count() == 0, "new queue count is 0");
  check(!q.pop().has_value(), "empty pop returns none");
  check(!q.peek().has_value(), "empty peek returns none");

  check(q.push(10) && q.push(20) && q.push(30), "push up to usable capacity succeeds");
  check(q.count() == 3, "count reflects three fills");
  check(!q.push(40), "full queue rejects push");
  check(q.count() == 3, "rejected push did not change count");

  auto pk = q.peek();
  check(pk.has_value() && pk.value() == 10, "peek returns the front");
  check(q.count() == 3, "peek does not remove");
  auto p = q.pop();
  check(p.has_value() && p.value() == 10, "pop after peek returns the same item");
  check(q.count() == 2, "pop removed one");

  // Wraparound: the internal indices roll past the end of the ring.
  check(q.push(40), "push after a pop succeeds");   // buffer wraps here
  check(q.count() == 3, "count is 3 again");
  check(q.pop().value() == 20, "FIFO order preserved (20)");
  check(q.pop().value() == 30, "FIFO order preserved (30)");
  check(q.push(50) && q.push(60), "refill across the wrap boundary");
  check(q.count() == 3, "full again after wrap");
  check(!q.push(70), "still rejects when full after wraparound");

  check(q.pop().value() == 40, "wraparound order preserved (40)");
  check(q.pop().value() == 50, "wraparound order preserved (50)");
  check(q.pop().value() == 60, "wraparound order preserved (60)");
  check(q.empty(), "queue empty after draining");
  check(!q.pop().has_value(), "pop on a drained queue returns none");
}

}  // namespace

int main() {
  test_fixed_queue();
  test_option_value_or();
  test_fixed_queue_wraparound_stress();
  std::printf("\n%d checks, %d failures\n", g_checks, g_failures);
  return g_failures == 0 ? 0 : 1;
}
