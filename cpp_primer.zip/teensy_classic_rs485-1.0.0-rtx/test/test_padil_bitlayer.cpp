// test_padil_bitlayer.cpp - Host-side unit tests for the pure PADIL bit layer.
//
// Runs on the development host (no Teensy toolchain) because PadilBitLayer is
// Arduino-free. It proves the parts the review flagged: differential-Manchester
// interval decode, SOM (0xAA 0xCC) detection, exact 27-byte capture, tolerance
// accept/reject, and the TX half-cell toggle schedule.
//
// Build & run:
//   c++ -std=c++20 -I../src test_padil_bitlayer.cpp -o test_padil_bitlayer
//   ./test_padil_bitlayer
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include <cstdint>
#include <cstdio>
#include <vector>

#include "Config.hpp"
#include "Domain.hpp"
#include "PadilBitLayer.hpp"

namespace {

int g_checks = 0;
int g_failures = 0;

void check(bool cond, const char* what) {
  ++g_checks;
  if (!cond) {
    ++g_failures;
    std::printf("  FAIL: %s\n", what);
  }
}

using namespace bridge;
using bridge::config::LineCode;

constexpr uint32_t kFull = 1000;  // Arbitrary "bit period" in test units.
constexpr uint32_t kHalf = 500;

// Emit differential-Manchester intervals for one MSB-first bit.
void emit_bit(uint8_t bit, std::vector<uint32_t>& out) {
  if (bit != 0) {
    out.push_back(kFull);  // Boundary-to-boundary, no mid -> 1.
  } else {
    out.push_back(kHalf);  // Mid then boundary -> two halves -> 0.
    out.push_back(kHalf);
  }
}

void emit_byte(uint8_t byte, std::vector<uint32_t>& out) {
  for (int i = 7; i >= 0; --i) {
    emit_bit(static_cast<uint8_t>((byte >> i) & 0x1U), out);
  }
}

// --- Default line code -----------------------------------------------------
void test_default_line_code() {
  std::printf("test_default_line_code\n");
  check(config::kLineCode == LineCode::DifferentialManchester,
        "differential Manchester is the default line code");
}

// --- TX schedule for the SOM ----------------------------------------------
void test_tx_schedule_som() {
  std::printf("test_tx_schedule_som\n");
  const uint8_t som[2] = {0xAA, 0xCC};
  const size_t bits = 16;

  check(padil::manchester_total_half_cells(bits) == 33, "SOM half-cell count = 2N+1");
  // First symbol must be a boundary transition (emitted immediately at TX start).
  check(padil::manchester_toggle_at(0, som, bits), "slot 0 (opening boundary) toggles");

  // 0xAA = 1,0,1,0,1,0,1,0. bit0=1: no mid; bit1=0: mid toggles.
  check(!padil::manchester_toggle_at(1, som, bits), "slot 1 (mid of bit0=1) does NOT toggle");
  check(padil::manchester_toggle_at(2, som, bits), "slot 2 (boundary) toggles");
  check(padil::manchester_toggle_at(3, som, bits), "slot 3 (mid of bit1=0) toggles");
  check(padil::manchester_toggle_at(4, som, bits), "slot 4 (boundary) toggles");
  check(!padil::manchester_toggle_at(5, som, bits), "slot 5 (mid of bit2=1) does NOT toggle");

  // Every even slot (boundary) must toggle.
  bool all_boundaries = true;
  for (size_t h = 0; h <= 2 * bits; h += 2) {
    if (!padil::manchester_toggle_at(h, som, bits)) {
      all_boundaries = false;
    }
  }
  check(all_boundaries, "every boundary slot toggles");
}

// --- Direct assembler: SOM detection + 27-byte capture ---------------------
void feed_byte_bits(padil::PadilMessageAssembler& asm_, uint8_t byte) {
  for (int i = 7; i >= 0; --i) {
    asm_.feed_bit(static_cast<uint8_t>((byte >> i) & 0x1U));
  }
}

void test_assembler_som_and_capture() {
  std::printf("test_assembler_som_and_capture\n");
  padil::PadilMessageAssembler asm_;
  asm_.reset();

  // Idle to arm, then SOM.
  feed_byte_bits(asm_, 0xAA);
  feed_byte_bits(asm_, 0xAA);
  check(!asm_.take_message().has_value(), "no message captured from idle alone");
  feed_byte_bits(asm_, 0xAA);
  feed_byte_bits(asm_, 0xCC);
  check(asm_.in_frame(), "SOM 0xAA 0xCC transitions into message capture");

  domain::PadilMessage expected{};
  for (int i = 0; i < 27; ++i) {
    expected.bytes[i] = static_cast<uint8_t>(i * 7 + 1);
    feed_byte_bits(asm_, expected.bytes[i]);
  }
  check(!asm_.in_frame(), "returns to idle after 27 payload bytes");

  auto msg = asm_.take_message();
  check(msg.has_value(), "a message was captured");
  check(msg.has_value() && msg.value() == expected, "captured payload matches (all 27 bytes)");
  check(!asm_.take_message().has_value(), "only one message queued");
}

// --- Full interval decode round-trip --------------------------------------
void test_decode_round_trip() {
  std::printf("test_decode_round_trip\n");
  padil::PadilLineDecoder dec;
  dec.configure(kFull, config::kBitPeriodToleranceDiv, LineCode::DifferentialManchester);

  domain::PadilMessage expected{};
  for (int i = 0; i < 27; ++i) {
    expected.bytes[i] = static_cast<uint8_t>(0x10 + i);
  }

  std::vector<uint32_t> intervals;
  emit_byte(0xAA, intervals);  // idle
  emit_byte(0xAA, intervals);  // idle -> armed
  emit_byte(0xAA, intervals);  // SOM byte 0
  emit_byte(0xCC, intervals);  // SOM byte 1 -> in message
  for (int i = 0; i < 27; ++i) {
    emit_byte(expected.bytes[i], intervals);
  }

  bool all_ok = true;
  for (uint32_t dt : intervals) {
    if (!dec.feed_segment(dt, 0)) {
      all_ok = false;
    }
  }
  check(all_ok, "no framing errors on a clean Manchester stream");
  check(dec.framing_errors() == 0, "framing error count is zero");

  auto msg = dec.take_message();
  check(msg.has_value(), "message decoded from interval stream");
  check(msg.has_value() && msg.value() == expected, "decoded payload matches encoded payload");
}

// --- Tolerance accept / reject --------------------------------------------
void test_tolerance() {
  std::printf("test_tolerance\n");
  padil::PadilLineDecoder dec;
  dec.configure(kFull, 8, LineCode::DifferentialManchester);  // band = +/-12.5%

  // Full band is [875, 1125].
  check(dec.feed_segment(1000, 0), "nominal full interval accepted");
  check(dec.feed_segment(880, 0), "full - just inside lower band accepted");
  check(dec.feed_segment(1120, 0), "full + just inside upper band accepted");

  const uint32_t before = dec.framing_errors();
  check(!dec.feed_segment(1300, 0), "gross-long interval rejected");
  check(!dec.feed_segment(700, 0), "between half and full is rejected");
  check(dec.framing_errors() == before + 2, "two rejects counted as framing errors");

  // Half pairing.
  dec.reset();
  check(dec.feed_segment(500, 0), "first half accepted (pending)");
  check(dec.feed_segment(500, 0), "second half accepted (completes a 0 bit)");

  // A full arriving mid-pair is inconsistent.
  dec.reset();
  check(dec.feed_segment(500, 0), "half accepted (pending)");
  const uint32_t before2 = dec.framing_errors();
  check(!dec.feed_segment(1000, 0), "full while half-pending is rejected");
  check(dec.framing_errors() == before2 + 1, "inconsistent pairing counted");
}

// Feed the differential-Manchester intervals for a whole byte to a decoder.
void feed_byte_intervals(padil::PadilLineDecoder& dec, uint8_t byte) {
  std::vector<uint32_t> iv;
  emit_byte(byte, iv);
  for (uint32_t dt : iv) {
    (void)dec.feed_segment(dt, 0);
  }
}

// --- Back-to-back messages -------------------------------------------------
void test_back_to_back_messages() {
  std::printf("test_back_to_back_messages\n");
  padil::PadilLineDecoder dec;
  dec.configure(kFull, config::kBitPeriodToleranceDiv, LineCode::DifferentialManchester);

  domain::PadilMessage a{};
  domain::PadilMessage b{};
  for (int i = 0; i < 27; ++i) {
    a.bytes[i] = static_cast<uint8_t>(0x10 + i);
    b.bytes[i] = static_cast<uint8_t>(0x80 - i);
  }

  auto feed_frame = [&](const domain::PadilMessage& m) {
    feed_byte_intervals(dec, 0xAA);  // idle
    feed_byte_intervals(dec, 0xAA);  // idle -> armed
    feed_byte_intervals(dec, 0xAA);  // SOM byte 0
    feed_byte_intervals(dec, 0xCC);  // SOM byte 1
    for (int i = 0; i < 27; ++i) {
      feed_byte_intervals(dec, m.bytes[i]);
    }
  };
  feed_frame(a);
  feed_frame(b);

  auto m1 = dec.take_message();
  auto m2 = dec.take_message();
  check(m1.has_value() && m1.value() == a, "first back-to-back message decodes");
  check(m2.has_value() && m2.value() == b, "second back-to-back message decodes");
  check(dec.framing_errors() == 0, "no framing errors across two clean frames");
}

// --- Bad SOM resynchronizes -------------------------------------------------
void test_bad_som_resync() {
  std::printf("test_bad_som_resync\n");
  padil::PadilMessageAssembler asm_;
  asm_.reset();

  // Arm on idle, then feed a long non-SOM run so the SOM search gives up and
  // resynchronizes back to idle search.
  feed_byte_bits(asm_, 0xAA);
  feed_byte_bits(asm_, 0xAA);
  for (int i = 0; i < 40; ++i) {
    asm_.feed_bit(0);  // never forms 0xAACC; > 32 bits => resync to FindIdle
  }

  // A proper frame after the resync must still decode.
  domain::PadilMessage expected{};
  feed_byte_bits(asm_, 0xAA);
  feed_byte_bits(asm_, 0xAA);
  feed_byte_bits(asm_, 0xAA);
  feed_byte_bits(asm_, 0xCC);
  for (int i = 0; i < 27; ++i) {
    expected.bytes[i] = static_cast<uint8_t>(i + 3);
    feed_byte_bits(asm_, expected.bytes[i]);
  }
  auto m = asm_.take_message();
  check(m.has_value() && m.value() == expected,
        "assembler resynchronizes after a bad SOM and decodes the next frame");
}

// --- Partial frame timeout resets the assembler ----------------------------
void test_partial_frame_timeout() {
  std::printf("test_partial_frame_timeout\n");
  padil::PadilLineDecoder dec;
  dec.configure(kFull, config::kBitPeriodToleranceDiv, LineCode::DifferentialManchester);

  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xCC);       // now in message
  feed_byte_intervals(dec, 0x11);       // a few payload bytes...
  feed_byte_intervals(dec, 0x22);
  check(dec.in_frame(), "decoder is mid-frame after a partial message");

  dec.note_timeout();                    // hardware layer would call this
  check(!dec.in_frame(), "note_timeout resets the assembler");
  check(dec.framing_errors() == 1, "timeout counted as a framing error");

  // A clean frame after the timeout still decodes.
  domain::PadilMessage expected{};
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xCC);
  for (int i = 0; i < 27; ++i) {
    expected.bytes[i] = static_cast<uint8_t>(i);
    feed_byte_intervals(dec, expected.bytes[i]);
  }
  auto m = dec.take_message();
  check(m.has_value() && m.value() == expected, "decoder recovers after a timeout");
}

// --- Wrong interval sequence increments framing error ----------------------
void test_wrong_interval_framing() {
  std::printf("test_wrong_interval_framing\n");
  padil::PadilLineDecoder dec;
  dec.configure(kFull, 8, LineCode::DifferentialManchester);

  const uint32_t before = dec.framing_errors();
  check(!dec.feed_segment(kFull * 3, 0), "a grossly wrong interval is rejected");
  check(dec.framing_errors() == before + 1, "wrong interval increments the framing error count");
}

// --- Convention / polarity is explicit and tested ---------------------------
void test_convention_and_polarity() {
  std::printf("test_convention_and_polarity\n");
  // This asserts the ASSUMED differential-Manchester convention:
  //   mid-cell transition => bit 0 ; boundary-only => bit 1.
  // Payload bytes 0x00 (all mids), 0xFF (all boundaries), 0xAA and 0x55
  // (alternating) exercise both extremes. Polarity on the real bus MUST still
  // be confirmed with a scope (see HARDWARE_VALIDATION.md); if it is inverted,
  // only PadilBitLayer changes.
  padil::PadilLineDecoder dec;
  dec.configure(kFull, config::kBitPeriodToleranceDiv, LineCode::DifferentialManchester);

  domain::PadilMessage expected{};
  const uint8_t pattern[4] = {0x00, 0xFF, 0xAA, 0x55};
  for (int i = 0; i < 27; ++i) {
    expected.bytes[i] = pattern[i % 4];
  }
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xAA);
  feed_byte_intervals(dec, 0xCC);
  for (int i = 0; i < 27; ++i) {
    feed_byte_intervals(dec, expected.bytes[i]);
  }
  auto m = dec.take_message();
  check(m.has_value() && m.value() == expected,
        "all-0 (mids), all-1 (boundaries) and alternating bytes decode per the assumed convention");
}

}  // namespace

int main() {
  test_default_line_code();
  test_tx_schedule_som();
  test_assembler_som_and_capture();
  test_decode_round_trip();
  test_tolerance();
  test_back_to_back_messages();
  test_bad_som_resync();
  test_partial_frame_timeout();
  test_wrong_interval_framing();
  test_convention_and_polarity();

  std::printf("\n%d checks, %d failures\n", g_checks, g_failures);
  return g_failures == 0 ? 0 : 1;
}
