// test_usb_protocol.cpp - Host-side unit tests for the USB RawHID codec.
//
// This suite compiles and runs on the DEVELOPMENT HOST with a stock C++20
// compiler - no Teensy toolchain required - because UsbProtocol/Domain/Core
// carry zero Arduino dependencies. It is the auditable proof that frame
// encode/decode, the big-endian helpers, and the 27-byte payload boundary are
// correct.
//
// In the full project layout this would be a Catch2 suite built by its own GPR;
// it is written here with a tiny self-contained harness so it runs anywhere
// with a single `c++ -std=c++20` invocation (see test/README or the build note
// at the bottom of this file).
//
// Build & run:
//   c++ -std=c++20 -I../src test_usb_protocol.cpp ../src/UsbProtocol.cpp -o test_usb_protocol
//   ./test_usb_protocol
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include <cstdint>
#include <cstdio>

#include "Domain.hpp"
#include "UsbProtocol.hpp"

namespace {

int g_checks = 0;
int g_failures = 0;

void check(bool cond, const char* what) {
  ++g_checks;
  if (!cond) {
    ++g_failures;
    std::printf("  FAIL: %s\n", what);
  }
}

using namespace bridge;
using bridge::domain::DecodeError;
using bridge::domain::HostFrameKind;
using bridge::domain::Tom;

// --- Big-endian helpers ----------------------------------------------------
void test_endian() {
  std::printf("test_endian\n");
  uint8_t buf[8] = {};

  const uint64_t n = 0x0102030405060708ULL;
  usb::write_u64_be(buf, n);
  check(buf[0] == 0x01 && buf[7] == 0x08, "u64 BE MSB-first byte order");
  check(usb::read_u64_be(buf) == n, "u64 BE round-trip");

  // A value that overflows 32 bits - the POC's unsigned-long bug would drop the
  // high word here.
  const uint64_t big = 0xF1E2D3C4B5A69788ULL;
  usb::write_u64_be(buf, big);
  check(usb::read_u64_be(buf) == big, "u64 BE preserves the full 64 bits");

  uint8_t i32buf[4] = {};
  usb::write_i32_be(i32buf, -12345);
  check(usb::read_i32_be(i32buf) == -12345, "i32 BE round-trip (negative)");
  usb::write_i32_be(i32buf, 255);  // 25.5 C in tenths.
  check(i32buf[0] == 0 && i32buf[3] == 0xFF, "i32 BE MSB-first byte order");
}

// --- PADIL encode ----------------------------------------------------------
void test_encode_padil() {
  std::printf("test_encode_padil\n");
  domain::PadilMessage payload{};
  for (int i = 0; i < 27; ++i) {
    payload.bytes[i] = static_cast<uint8_t>(0xA0 + i);
  }
  domain::UsbFrame frame{};
  usb::encode_padil(frame, 0x1122334455667788ULL, payload);

  check(frame.bytes[0] == static_cast<uint8_t>(Tom::Padil), "PADIL TOM byte == 1");
  check(usb::read_u64_be(&frame.bytes[1]) == 0x1122334455667788ULL, "PADIL msg number");

  bool payload_ok = true;
  for (int i = 0; i < 27; ++i) {
    if (frame.bytes[9 + i] != static_cast<uint8_t>(0xA0 + i)) {
      payload_ok = false;
    }
  }
  check(payload_ok, "PADIL payload copied to bytes 9..35 (all 27)");
  check(frame.bytes[35] == static_cast<uint8_t>(0xA0 + 26), "PADIL last payload byte at 35");
  check(frame.bytes[36] == 0, "PADIL byte 36 is padding (0), not payload");

  bool padding_ok = true;
  for (int i = 36; i < 64; ++i) {
    if (frame.bytes[i] != 0) {
      padding_ok = false;
    }
  }
  check(padding_ok, "PADIL bytes 36..63 are zero padding");
}

// --- ACK encode ------------------------------------------------------------
void test_encode_ack() {
  std::printf("test_encode_ack\n");
  domain::UsbFrame frame{};
  usb::encode_ack(frame, 0xDEADBEEFCAFEF00DULL);
  check(frame.bytes[0] == static_cast<uint8_t>(Tom::Ack), "ACK TOM byte == 2");
  check(usb::read_u64_be(&frame.bytes[1]) == 0xDEADBEEFCAFEF00DULL, "ACK msg number");
  bool rest_zero = true;
  for (int i = 9; i < 64; ++i) {
    if (frame.bytes[i] != 0) {
      rest_zero = false;
    }
  }
  check(rest_zero, "ACK bytes 9..63 are zero");
}

// --- Status encode ---------------------------------------------------------
void test_encode_status() {
  std::printf("test_encode_status\n");
  domain::AdapterStatus s;
  s.state = domain::AdapterState::Transmitting;
  s.host_rx = 0x1111111111111111ULL;
  s.host_tx = 0x2222222222222222ULL;
  s.rs485_rx = 0x3333333333333333ULL;
  s.rs485_tx = 0x4444444444444444ULL;
  s.cpu_temp_tenths_c = 421;  // 42.1 C
  s.temp_available = true;

  domain::UsbFrame frame{};
  usb::encode_status(frame, s);
  check(frame.bytes[0] == static_cast<uint8_t>(Tom::Status), "STATUS TOM byte == 3");
  check(frame.bytes[1] == static_cast<uint8_t>(domain::AdapterState::Transmitting),
        "STATUS state byte");
  check(usb::read_u64_be(&frame.bytes[2]) == s.host_rx, "STATUS host_rx at 2..9");
  check(usb::read_u64_be(&frame.bytes[10]) == s.host_tx, "STATUS host_tx at 10..17");
  check(usb::read_u64_be(&frame.bytes[18]) == s.rs485_rx, "STATUS rs485_rx at 18..25");
  check(usb::read_u64_be(&frame.bytes[26]) == s.rs485_tx, "STATUS rs485_tx at 26..33");
  check(usb::read_i32_be(&frame.bytes[34]) == 421, "STATUS temp at 34..37");
  bool rest_zero = true;
  for (int i = 38; i < 64; ++i) {
    if (frame.bytes[i] != 0) {
      rest_zero = false;
    }
  }
  check(rest_zero, "STATUS bytes 38..63 are zero");

  // Temperature unavailable -> sentinel.
  s.temp_available = false;
  usb::encode_status(frame, s);
  check(usb::read_i32_be(&frame.bytes[34]) == domain::kTempUnavailableSentinel,
        "STATUS temp sentinel when unavailable");
}

// --- Decode ----------------------------------------------------------------
void test_decode() {
  std::printf("test_decode\n");

  // PADIL round-trip through decode.
  domain::PadilMessage payload{};
  for (int i = 0; i < 27; ++i) {
    payload.bytes[i] = static_cast<uint8_t>(i + 1);
  }
  domain::UsbFrame frame{};
  usb::encode_padil(frame, 0x0102030405060708ULL, payload);
  auto d = usb::decode_host_frame(frame);
  check(d.is_ok(), "decode PADIL is ok");
  check(d.value().kind == HostFrameKind::Padil, "decode PADIL kind");
  check(d.value().number == 0x0102030405060708ULL, "decode PADIL number");
  check(d.value().payload == payload, "decode PADIL payload matches (27 bytes)");

  // Command frame.
  domain::UsbFrame cmd{};
  cmd.bytes[0] = static_cast<uint8_t>(Tom::Command);
  cmd.bytes[1] = static_cast<uint8_t>(domain::AdapterCommand::SetMdrp);
  auto dc = usb::decode_host_frame(cmd);
  check(dc.is_ok(), "decode Command is ok");
  check(dc.value().kind == HostFrameKind::Command, "decode Command kind");
  check(dc.value().command == domain::AdapterCommand::SetMdrp, "decode Command value");

  // Illegal TOM 0.
  domain::UsbFrame illegal{};
  illegal.bytes[0] = 0;
  check(usb::decode_host_frame(illegal).error() == DecodeError::IllegalTom, "TOM 0 illegal");

  // Ack inbound is unsupported (device never receives it).
  domain::UsbFrame ack{};
  ack.bytes[0] = static_cast<uint8_t>(Tom::Ack);
  check(usb::decode_host_frame(ack).error() == DecodeError::UnsupportedInbound,
        "inbound ACK unsupported");

  // Unknown command byte.
  domain::UsbFrame badcmd{};
  badcmd.bytes[0] = static_cast<uint8_t>(Tom::Command);
  badcmd.bytes[1] = 99;
  check(usb::decode_host_frame(badcmd).error() == DecodeError::UnknownCommand,
        "unknown command byte");

  // Short frame.
  uint8_t shortbuf[10] = {static_cast<uint8_t>(Tom::Padil)};
  check(usb::decode_host_frame(shortbuf, sizeof(shortbuf)).error() == DecodeError::ShortFrame,
        "short frame rejected");
}

// --- Padding is zero after re-encoding into a reused frame ------------------
void test_encode_reuse_padding() {
  std::printf("test_encode_reuse_padding\n");
  domain::UsbFrame frame{};
  domain::PadilMessage p{};
  for (int i = 0; i < 27; ++i) {
    p.bytes[i] = 0xFF;
  }
  // Fill the frame with a PADIL (payload + high number), then re-encode an ACK
  // into the SAME frame - no stale PADIL bytes may survive.
  usb::encode_padil(frame, 0xFFFFFFFFFFFFFFFFULL, p);
  usb::encode_ack(frame, 0x42);
  check(frame.bytes[0] == static_cast<uint8_t>(Tom::Ack), "reused frame TOM updated to ACK");
  check(usb::read_u64_be(&frame.bytes[1]) == 0x42, "reused frame number updated");
  bool zero = true;
  for (int i = 9; i < 64; ++i) {
    if (frame.bytes[i] != 0) {
      zero = false;
    }
  }
  check(zero, "no stale payload survives re-encode into a reused frame");
}

// --- Decode rejections ------------------------------------------------------
void test_decode_rejections() {
  std::printf("test_decode_rejections\n");
  domain::UsbFrame f{};
  f.bytes[0] = 5;  // TOM > 4
  check(usb::decode_host_frame(f).error() == DecodeError::UnknownTom, "TOM > 4 rejected");

  f.clear();
  f.bytes[0] = static_cast<uint8_t>(Tom::Status);
  check(usb::decode_host_frame(f).error() == DecodeError::UnsupportedInbound,
        "inbound Status rejected");

  f.clear();
  f.bytes[0] = static_cast<uint8_t>(Tom::Ack);
  check(usb::decode_host_frame(f).error() == DecodeError::UnsupportedInbound,
        "inbound ACK rejected");
}

// --- Command decode: padding ignored, clear-counters decoded ---------------
void test_decode_command_variants() {
  std::printf("test_decode_command_variants\n");
  domain::UsbFrame f{};
  f.bytes[0] = static_cast<uint8_t>(Tom::Command);
  f.bytes[1] = static_cast<uint8_t>(domain::AdapterCommand::ClearCounters);
  for (int i = 2; i < 64; ++i) {
    f.bytes[i] = 0xAB;  // garbage padding after the command byte
  }
  auto d = usb::decode_host_frame(f);
  check(d.is_ok() && d.value().kind == HostFrameKind::Command,
        "command decodes despite non-zero padding");
  check(d.is_ok() && d.value().command == domain::AdapterCommand::ClearCounters,
        "clear-counters command decoded");
}

}  // namespace

int main() {
  test_endian();
  test_encode_padil();
  test_encode_ack();
  test_encode_status();
  test_decode();
  test_encode_reuse_padding();
  test_decode_rejections();
  test_decode_command_variants();

  std::printf("\n%d checks, %d failures\n", g_checks, g_failures);
  return g_failures == 0 ? 0 : 1;
}
