// test_bridge_controller.cpp - Host-side unit tests for the application bridge.
//
// BridgeController is a template over the USB / line / platform ports, so it can
// be exercised on the host with plain test doubles - no Teensy toolchain. These
// tests cover the correction slice: ACK-after-physical-TX, USB backpressure
// retention, device->host numbering, and the counters.
//
// Build & run:
//   c++ -std=c++20 -I../src test_bridge_controller.cpp ../src/UsbProtocol.cpp
//       -o test_bridge_controller
//   ./test_bridge_controller
//
// Copyright (c) 2026 RTX/Raytheon, All Rights Reserved.

#include <cstdint>
#include <cstdio>
#include <deque>
#include <vector>

#include "BridgeController.hpp"
#include "Domain.hpp"
#include "PadilBitLayer.hpp"
#include "UsbProtocol.hpp"

namespace {

int g_checks = 0;
int g_failures = 0;
void check(bool cond, const char* what) {
  ++g_checks;
  if (!cond) {
    ++g_failures;
    std::printf("  FAIL: %s\n", what);
  }
}

using namespace bridge;
using domain::Led;
using domain::PadilMessage;
using domain::Tom;
using domain::UsbFrame;

// --- Test doubles ----------------------------------------------------------

struct FakeUsb {
  std::vector<UsbFrame> sent;
  std::deque<UsbFrame> to_recv;
  bool fail_send = false;

  auto send(const UsbFrame& f) noexcept -> bool {
    if (fail_send) {
      return false;
    }
    sent.push_back(f);
    return true;
  }
  auto recv(UsbFrame& f) noexcept -> bool {
    if (to_recv.empty()) {
      return false;
    }
    f = to_recv.front();
    to_recv.pop_front();
    return true;
  }
};

struct FakeLine {
  std::deque<PadilMessage> received;      // Decoded RS-485 messages to hand up.
  std::vector<PadilMessage> transmitted;  // Payloads passed to begin_transmit.
  bool transmitting = false;
  padil::Speed speed = padil::Speed::Ldrp;

  auto poll() noexcept -> void {}
  auto take_received() noexcept -> core::Option<PadilMessage> {
    if (received.empty()) {
      return core::Option<PadilMessage>::none();
    }
    const PadilMessage m = received.front();
    received.pop_front();
    return core::Option<PadilMessage>::some(m);
  }
  auto begin_transmit(const PadilMessage& m) noexcept -> bool {
    if (transmitting) {
      return false;
    }
    transmitted.push_back(m);
    transmitting = true;
    return true;
  }
  auto is_transmitting() const noexcept -> bool { return transmitting; }
  auto set_speed(padil::Speed s) noexcept -> void { speed = s; }
  auto framing_errors() const noexcept -> uint32_t { return 0; }
  auto edge_overflows() const noexcept -> uint32_t { return 0; }
  auto rx_msg_overflows() const noexcept -> uint32_t { return 0; }

  // Test helper: simulate the physical transmit completing.
  auto complete_tx() noexcept -> void { transmitting = false; }
};

struct FakePlatform {
  uint32_t t = 100000;
  bool leds[3] = {false, false, false};
  auto micros() const noexcept -> uint32_t { return t; }
  auto set_led(domain::Led led, bool on) noexcept -> void { leds[static_cast<int>(led)] = on; }
  auto cpu_temp_tenths() const noexcept -> core::Option<int32_t> {
    return core::Option<int32_t>::none();
  }
  auto led(domain::Led l) const noexcept -> bool { return leds[static_cast<int>(l)]; }
};

// A line double that faithfully models the ADR-7 TX state machine
// (Idle -> Active -> CleanupPending -> Idle) so the controller's interaction with
// it can be regression-tested: begin_transmit() succeeds ONLY from Idle, the
// timer-ISR completion moves Active -> CleanupPending, and poll() performs cleanup
// and returns to Idle. It records the cleanup count observed at each TX start so a
// test can prove a new TX never begins before the prior TX's cleanup ran.
struct StatefulLine {
  enum class St { Idle, Active, CleanupPending };
  St state = St::Idle;
  int tx_started = 0;
  int cleanup_runs = 0;
  int cleanup_runs_at_last_tx = -1;
  std::vector<PadilMessage> transmitted;
  std::deque<PadilMessage> received;

  auto poll() noexcept -> void {
    if (state == St::CleanupPending) {
      ++cleanup_runs;
      state = St::Idle;
    }
  }
  auto take_received() noexcept -> core::Option<PadilMessage> {
    if (received.empty()) {
      return core::Option<PadilMessage>::none();
    }
    const PadilMessage m = received.front();
    received.pop_front();
    return core::Option<PadilMessage>::some(m);
  }
  auto begin_transmit(const PadilMessage& m) noexcept -> bool {
    if (state != St::Idle) {
      return false;  // ADR-7: a new TX may start ONLY from Idle.
    }
    state = St::Active;
    ++tx_started;
    transmitted.push_back(m);
    cleanup_runs_at_last_tx = cleanup_runs;  // How many cleanups had run when this TX began.
    return true;
  }
  auto is_transmitting() const noexcept -> bool { return state == St::Active; }
  auto set_speed(padil::Speed) noexcept -> void {}
  auto framing_errors() const noexcept -> uint32_t { return 0; }
  auto edge_overflows() const noexcept -> uint32_t { return 0; }
  auto rx_msg_overflows() const noexcept -> uint32_t { return 0; }

  // Simulate the timer ISR finishing the physical transmit between poll cycles.
  auto inject_completion() noexcept -> void {
    if (state == St::Active) {
      state = St::CleanupPending;
    }
  }
};

// --- Helpers ---------------------------------------------------------------

PadilMessage make_payload(uint8_t seed) {
  PadilMessage p{};
  for (int i = 0; i < 27; ++i) {
    p.bytes[i] = static_cast<uint8_t>(seed + i);
  }
  return p;
}

void push_inbound_padil(FakeUsb& usb, uint64_t number, const PadilMessage& p) {
  UsbFrame f{};
  usb::encode_padil(f, number, p);
  usb.to_recv.push_back(f);
}

int count_tom(const std::vector<UsbFrame>& sent, Tom tom) {
  int n = 0;
  for (const auto& f : sent) {
    if (f.bytes[0] == static_cast<uint8_t>(tom)) {
      ++n;
    }
  }
  return n;
}

// Last sent frame of a given TOM, or a zeroed frame.
UsbFrame last_of(const std::vector<UsbFrame>& sent, Tom tom) {
  UsbFrame out{};
  for (const auto& f : sent) {
    if (f.bytes[0] == static_cast<uint8_t>(tom)) {
      out = f;
    }
  }
  return out;
}

// --- Tests -----------------------------------------------------------------

void test_ack_after_physical_tx() {
  std::printf("test_ack_after_physical_tx\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&]() {
    plat.t += 2000;
    bridge.poll();
  };

  const PadilMessage a = make_payload(0x10);
  push_inbound_padil(usb, 42, a);
  tick();

  // Accepted and started on the wire, but NOT yet ACKed.
  check(line.transmitted.size() == 1 && line.transmitted[0] == a,
        "host PADIL was queued and transmit started");
  check(count_tom(usb.sent, Tom::Ack) == 0, "no ACK before physical TX completes");
  check(bridge.snapshot().host_rx == 1, "host_rx counted the inbound PADIL");

  // Physical transmit completes -> ACK now, with the host's number.
  line.complete_tx();
  tick();
  check(count_tom(usb.sent, Tom::Ack) == 1, "exactly one ACK after TX completion");
  const UsbFrame ack = last_of(usb.sent, Tom::Ack);
  check(usb::read_u64_be(&ack.bytes[1]) == 42, "ACK carries the host message number");
  check(bridge.snapshot().rs485_tx == 1, "rs485_tx counted the physical transmit");
}

void test_backpressure_retains_message() {
  std::printf("test_backpressure_retains_message\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&]() {
    plat.t += 2000;
    bridge.poll();
  };

  const PadilMessage b = make_payload(0x80);
  line.received.push_back(b);
  usb.fail_send = true;
  tick();

  check(count_tom(usb.sent, Tom::Padil) == 0, "nothing sent while USB is failing");
  check(bridge.snapshot().rs485_rx == 1, "decoded message counted as received");
  check(bridge.snapshot().usb_send_drops >= 1, "USB send failure counted");
  check(bridge.snapshot().host_tx == 0, "no successful send yet");

  // USB recovers: the SAME message and number are delivered exactly once.
  usb.fail_send = false;
  tick();
  check(count_tom(usb.sent, Tom::Padil) == 1, "message delivered once after recovery");
  const UsbFrame padil = last_of(usb.sent, Tom::Padil);
  check(usb::read_u64_be(&padil.bytes[1]) == 0, "device->host number is 0 and stable");
  bool payload_ok = true;
  for (int i = 0; i < 27; ++i) {
    if (padil.bytes[9 + i] != b.bytes[i]) {
      payload_ok = false;
    }
  }
  check(payload_ok, "delivered payload matches the decoded message");
  check(bridge.snapshot().host_tx == 1, "host_tx counted exactly one delivery");
}

void test_numbering_is_monotonic() {
  std::printf("test_numbering_is_monotonic\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&]() {
    plat.t += 2000;
    bridge.poll();
  };

  line.received.push_back(make_payload(1));
  line.received.push_back(make_payload(2));
  tick();  // both drained, both sent (USB healthy)

  check(count_tom(usb.sent, Tom::Padil) == 2, "two messages sent");
  check(usb::read_u64_be(&usb.sent[0].bytes[1]) == 0, "first device->host number is 0 (POC-aligned)");
  check(usb::read_u64_be(&usb.sent[1].bytes[1]) == 1, "second device->host number is 1");
}

void test_command_and_drops() {
  std::printf("test_command_and_drops\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&]() {
    plat.t += 2000;
    bridge.poll();
  };

  // Set-MDRP command routes to the line port.
  UsbFrame cmd{};
  cmd.bytes[0] = static_cast<uint8_t>(Tom::Command);
  cmd.bytes[1] = static_cast<uint8_t>(domain::AdapterCommand::SetMdrp);
  usb.to_recv.push_back(cmd);
  tick();
  check(line.speed == padil::Speed::Mdrp, "SetMdrp command applied to line port");

  // Unknown command counts as invalid + decode error.
  UsbFrame bad{};
  bad.bytes[0] = static_cast<uint8_t>(Tom::Command);
  bad.bytes[1] = 99;
  usb.to_recv.push_back(bad);
  tick();
  check(bridge.snapshot().invalid_commands == 1, "unknown command counted");
  check(bridge.snapshot().usb_decode_errors == 1, "decode error counted");
}

void test_status_cadence_and_counters() {
  std::printf("test_status_cadence_and_counters\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  push_inbound_padil(usb, 7, make_payload(1));  // host_rx
  line.received.push_back(make_payload(2));      // rs485_rx -> host_tx
  tick(2000);
  check(count_tom(usb.sent, Tom::Status) == 0, "no status before the period elapses");

  tick(config::kStatusPeriodUs);  // cross exactly one status period
  check(count_tom(usb.sent, Tom::Status) == 1, "one status frame per period");
  const UsbFrame st = last_of(usb.sent, Tom::Status);
  check(usb::read_u64_be(&st.bytes[2]) == 1, "status host_rx counter matches events");
  check(usb::read_u64_be(&st.bytes[10]) == 1, "status host_tx counter matches events");
  check(usb::read_u64_be(&st.bytes[18]) == 1, "status rs485_rx counter matches events");
  check(usb::read_u64_be(&st.bytes[26]) == 0, "status rs485_tx counter (no TX completed)");
}

void test_clear_counters() {
  std::printf("test_clear_counters\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  push_inbound_padil(usb, 1, make_payload(1));
  UsbFrame bad{};
  bad.bytes[0] = 99;  // unknown TOM -> decode error
  usb.to_recv.push_back(bad);
  tick(2000);
  check(bridge.snapshot().host_rx == 1, "host_rx counted before clear");
  check(bridge.snapshot().usb_decode_errors == 1, "decode error counted before clear");

  UsbFrame clr{};
  clr.bytes[0] = static_cast<uint8_t>(Tom::Command);
  clr.bytes[1] = static_cast<uint8_t>(domain::AdapterCommand::ClearCounters);
  usb.to_recv.push_back(clr);
  tick(2000);
  check(bridge.snapshot().host_rx == 0, "host_rx cleared");
  check(bridge.snapshot().usb_decode_errors == 0, "decode errors cleared");
}

void test_speed_command_routing() {
  std::printf("test_speed_command_routing\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  UsbFrame mdrp{};
  mdrp.bytes[0] = static_cast<uint8_t>(Tom::Command);
  mdrp.bytes[1] = static_cast<uint8_t>(domain::AdapterCommand::SetMdrp);
  usb.to_recv.push_back(mdrp);
  tick(2000);
  check(line.speed == padil::Speed::Mdrp, "SetMdrp routed to line port");

  UsbFrame ldrp{};
  ldrp.bytes[0] = static_cast<uint8_t>(Tom::Command);
  ldrp.bytes[1] = static_cast<uint8_t>(domain::AdapterCommand::SetLdrp);
  usb.to_recv.push_back(ldrp);
  tick(2000);
  check(line.speed == padil::Speed::Ldrp, "SetLdrp routed to line port");
}

void test_tx_queue_full_not_acked() {
  std::printf("test_tx_queue_full_not_acked\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  // Push more host PADIL frames than the TX queue can hold, without ever
  // completing a physical transmit.
  for (uint64_t i = 0; i < 10; ++i) {
    push_inbound_padil(usb, i, make_payload(static_cast<uint8_t>(i)));
  }
  tick(2000);
  check(bridge.snapshot().tx_msg_overflows >= 1, "overflow counted when TX queue is full");
  check(count_tom(usb.sent, Tom::Ack) == 0,
        "nothing is ACKed - accepted frames await physical TX, dropped frames never ACK");
}

void test_ack_retained_on_send_failure() {
  std::printf("test_ack_retained_on_send_failure\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  push_inbound_padil(usb, 55, make_payload(3));
  tick(2000);                 // start transmit
  line.complete_tx();
  usb.fail_send = true;
  tick(2000);                 // completion detected, ACK send fails
  check(count_tom(usb.sent, Tom::Ack) == 0, "ACK not delivered while USB fails");
  check(bridge.snapshot().usb_send_drops >= 1, "failed ACK send counted");

  usb.fail_send = false;
  tick(2000);                 // retry the retained ACK
  check(count_tom(usb.sent, Tom::Ack) == 1, "retained ACK delivered on retry");
  const UsbFrame ack = last_of(usb.sent, Tom::Ack);
  check(usb::read_u64_be(&ack.bytes[1]) == 55, "retained ACK carries the right number");
}

void test_pacing_and_pending_ack_blocks_next() {
  std::printf("test_pacing_and_pending_ack_blocks_next\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  push_inbound_padil(usb, 1, make_payload(1));
  push_inbound_padil(usb, 2, make_payload(2));
  tick(2000);
  check(line.transmitted.size() == 1, "only one message transmits at a time (paced)");

  // Complete the first TX but make the ACK fail: the pending ACK must block the
  // next transmit.
  line.complete_tx();
  usb.fail_send = true;
  tick(2000);
  check(line.transmitted.size() == 1, "pending ACK blocks the next transmit");

  // ACK delivered -> next transmit starts.
  usb.fail_send = false;
  tick(2000);
  check(line.transmitted.size() == 2, "next transmit starts once the ACK is delivered");
}

void test_decode_errors_dont_corrupt_queues() {
  std::printf("test_decode_errors_dont_corrupt_queues\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  push_inbound_padil(usb, 1, make_payload(1));  // good
  UsbFrame bad{};
  bad.bytes[0] = 99;                             // garbage between good frames
  usb.to_recv.push_back(bad);
  push_inbound_padil(usb, 2, make_payload(2));  // good
  tick(2000);

  check(bridge.snapshot().host_rx == 2, "both good frames accepted despite garbage between");
  check(bridge.snapshot().usb_decode_errors == 1, "the garbage frame is counted, not queued");
  check(line.transmitted.size() == 1, "transmit pipeline still runs normally");
}

void test_sustained_input_predictable() {
  std::printf("test_sustained_input_predictable\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  const uint64_t total = 20;
  for (uint64_t i = 0; i < total; ++i) {
    push_inbound_padil(usb, i, make_payload(static_cast<uint8_t>(i)));
    if (line.is_transmitting()) {
      line.complete_tx();
    }
    tick(2000);
  }
  // Drain: keep completing transmits until everything accepted has gone out.
  for (int i = 0; i < 60; ++i) {
    if (line.is_transmitting()) {
      line.complete_tx();
    }
    tick(2000);
  }

  const auto s = bridge.snapshot();
  check(s.host_rx == total, "every host frame was received");
  const uint64_t accepted = s.host_rx - s.tx_msg_overflows;
  check(s.rs485_tx == accepted, "every accepted frame was eventually transmitted");
  check(count_tom(usb.sent, Tom::Ack) == static_cast<int>(s.rs485_tx),
        "one ACK per physically transmitted frame");
}

void test_led_behavior() {
  std::printf("test_led_behavior\n");
  FakeUsb usb;
  FakeLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();
  auto tick = [&](uint32_t dt) {
    plat.t += dt;
    bridge.poll();
  };

  tick(2000);
  check(!plat.led(Led::Transfer), "transfer LED off at idle");
  check(!plat.led(Led::Error), "error LED off at idle");

  // A successful PADIL delivery pulses the transfer LED.
  line.received.push_back(make_payload(1));
  tick(2000);
  check(plat.led(Led::Transfer), "transfer LED pulses on a successful PADIL transfer");
  tick(config::kLedPulseUs + 1000);
  check(!plat.led(Led::Transfer), "transfer LED clears after the pulse window");

  // A decode error pulses the error LED.
  UsbFrame bad{};
  bad.bytes[0] = 99;
  usb.to_recv.push_back(bad);
  tick(2000);
  check(plat.led(Led::Error), "error LED pulses on a decode error");
  tick(config::kLedPulseUs + 1000);
  check(!plat.led(Led::Error), "error LED clears after the pulse window");

  // Crossing a status period toggles the heartbeat LED.
  const bool before = plat.led(Led::Status);
  tick(config::kStatusPeriodUs + 1000);
  check(plat.led(Led::Status) != before, "status/heartbeat LED toggles on the status tick");
}

// ADR-7 regression: the prior transmission's decoder cleanup must never be
// skipped when the next transmission is queued. Inject TX completion between the
// controller's poll() and its transmit servicing, then prove the second TX begins
// ONLY after the first TX's cleanup has run.
void test_adr7_tx_cleanup_not_skipped() {
  std::printf("test_adr7_tx_cleanup_not_skipped\n");
  FakeUsb usb;
  StatefulLine line;
  FakePlatform plat;
  app::BridgeController bridge{usb, line, plat};
  bridge.begin();

  // Contract: a new TX is refused while cleanup is pending.
  line.state = StatefulLine::St::CleanupPending;
  check(!line.begin_transmit(make_payload(0)), "begin_transmit is refused while CleanupPending");
  line.state = StatefulLine::St::Idle;

  // Queue two host PADIL frames for transmit.
  push_inbound_padil(usb, 1000, make_payload(1));
  push_inbound_padil(usb, 1001, make_payload(2));

  bridge.poll();  // Cycle 1: receive both; begin the first TX.
  check(line.tx_started == 1, "first TX started");
  check(line.is_transmitting(), "line is Active after the first begin");
  check(line.cleanup_runs == 0, "no cleanup has run yet");

  // The timer ISR completes the physical TX between poll cycles.
  line.inject_completion();
  check(!line.is_transmitting(), "completion moves out of Active (CleanupPending)");

  bridge.poll();  // Cycle 2: poll() cleans up FIRST, then the second TX may begin.
  check(line.cleanup_runs == 1, "the prior TX's cleanup ran exactly once");
  check(line.tx_started == 2, "second TX started");
  check(line.cleanup_runs_at_last_tx == 1,
        "second TX began ONLY after the first TX's cleanup (ADR-7: cleanup never skipped)");
}

}  // namespace

int main() {
  test_ack_after_physical_tx();
  test_backpressure_retains_message();
  test_numbering_is_monotonic();
  test_command_and_drops();
  test_status_cadence_and_counters();
  test_clear_counters();
  test_speed_command_routing();
  test_tx_queue_full_not_acked();
  test_ack_retained_on_send_failure();
  test_pacing_and_pending_ack_blocks_next();
  test_decode_errors_dont_corrupt_queues();
  test_sustained_input_predictable();
  test_led_behavior();
  test_adr7_tx_cleanup_not_skipped();

  std::printf("\n%d checks, %d failures\n", g_checks, g_failures);
  return g_failures == 0 ? 0 : 1;
}
