# Teensy 4.1 RS-485 ↔ USB RawHID Bridge (firmware)

Firmware that bridges a half-duplex **RS-485-side timed PADIL protocol** to a
host application over **USB RawHID**. It replaces an earlier single-file
proof-of-concept with a small, layered, testable C++20 package.

This slice covers the **transformation core plus the RS-485 interface** only.
There is intentionally **no OLED/display code**.

---

## Hardware assumptions

| Item | Value |
|---|---|
| MCU board | Teensy 4.1 (PJRC / SparkFun DEV-16996), 600 MHz i.MX RT1062 |
| Prototype transceiver | MAX485-style RS-485 |
| Target transceiver | TI THVD2450V (drop-in via `Rs485Phy`) |
| USB transport | RawHID, fixed 64-byte frames |
| Logic level | **3.3 V only — Teensy 4.1 pins are NOT 5 V tolerant** |

### ⚠️ MAX485 voltage warning (read before wiring)

A MAX485 powered at **5 V** drives its **RO** (receiver output) at 5 V logic.
Wiring **RO directly to a Teensy input pin can destroy the pin or the chip.**

- Level-shift **RO → Teensy RX** down to 3.3 V (resistor divider or a proper
  level-shifter IC) whenever the MAX485 is at 5 V, **or**
- Power the transceiver at 3.3 V (the **THVD2450V** is happy at 3.3 V, which
  removes the hazard — prefer it on the target board).

`DI`, `DE`, and `/RE` are inputs on the transceiver and accept the Teensy's
3.3 V drive directly. The hazard is only on the **RO → Teensy** direction.

---

## Teensy pin configuration

All pins live in [`lib/TeensyRs485Bridge/src/Config.hpp`](lib/TeensyRs485Bridge/src/Config.hpp). Defaults:

| Signal | Pin | Direction | Notes |
|---|---|---|---|
| RS-485 RX (from RO) | **2** | input | Must be ≤ 3.3 V (see warning) |
| RS-485 TX (to DI) | **3** | output | |
| DE (driver enable) | **4** | output | Active HIGH |
| /RE (receiver enable) | **5** | output | Active LOW; ignored if shared |
| Status LED | **13** | output | On-board; heartbeat |
| Transfer LED | **35** | output | External + series R to GND; pulses on a PADIL transfer |
| Debug/error LED | **34** | output | External + series R to GND; pulses on an error |

The MAX485 RO → pin-2 path must include the 2.2 kΩ / 3.3 kΩ protection divider
(see the voltage warning above); pin assignments are defined in
[`lib/TeensyRs485Bridge/src/Config.hpp`](lib/TeensyRs485Bridge/src/Config.hpp).

`kRs485DeReShared` (default **true**) selects whether DE and /RE are tied to one
control line (HIGH = transmit, LOW = receive) or driven as separate pins. The
firmware **defaults to receive mode** at boot and returns to receive after every
transmission.

---

## USB RawHID frame contract

Every frame is **exactly 64 bytes**. Byte 0 is the **TOM** (Type of Message).
Multi-byte integers are **big-endian / network order**.

| TOM | 0 | 1 | 2 | 3 | 4 |
|---|---|---|---|---|---|
| Meaning | illegal | PADIL/data | ACK | Status | Command |

**PADIL** (`TOM=1`) — device ⇄ host
```
[0]      = 1
[1..8]   = 64-bit message number (uint64, BE)
[9..35]  = 27-byte PADIL payload   (exactly 27 bytes)
[36..63] = zero padding
```

**ACK** (`TOM=2`) — device → host
```
[0]      = 2
[1..8]   = acknowledged message number (uint64, BE)
[9..63]  = zero
```

**Status** (`TOM=3`) — device → host
```
[0]      = 3
[1]      = adapter state (0 booting,1 idle,2 receiving,3 transmitting,4 error)
[2..9]   = host RX counter   (uint64, BE)
[10..17] = host TX counter   (uint64, BE)
[18..25] = RS-485 RX counter (uint64, BE)
[26..33] = RS-485 TX counter (uint64, BE)
[34..37] = CPU temperature, tenths °C (int32, BE); sentinel 0x80000000 if N/A
[38..63] = zero
```

**Command** (`TOM=4`) — host → device
```
[0]      = 4
[1]      = 1 clear counters | 2 set LDRP speed | 3 set MDRP speed
[2..63]  = ignored
```

### ACK policy

- A host **PADIL** frame is ACK'd only **after the payload physically completes
  RS-485 transmission** (matching the POC), not on queue acceptance. The ACK is
  retained across USB backpressure, and the bridge paces one message at a time
  (the next transmit is held until the ACK is delivered). If the TX queue is full
  the frame is **dropped and never ACK'd**, so the host detects the loss.
- PADIL messages decoded **from RS-485** are forwarded to the host with a
  device-assigned **monotonic** message number **starting at 0** (POC-aligned),
  preserved across USB backpressure. The host is **not** required to ACK them and
  the device does not wait for one.

---

## Building

### Build system

- **`platformio.ini`** owns the firmware build (board, framework, flags).
- **`Makefile`** wraps the common commands (`build`, `arduino-build`, `build-all`,
  `test`, `burn`, `flash`, `diagrams`, …).
- **CMake is intentionally not used** in this POC — a second build definition
  would duplicate what `platformio.ini` already models and invites drift. A
  future portable firmware *library* may add CMake if needed; this slice does not.

See [`docs/BUILD.md`](docs/BUILD.md) for tools, commands, assumptions, and the
burn-candidate rule.

### PlatformIO (recommended, reproducible)

```bash
pio run -e teensy41            # builds; auto-fetches the Teensy toolchain
pio run -e teensy41 -t upload  # flashes over USB
```

USB type is set to Raw HID via `-D USB_RAWHID` in [`platformio.ini`](platformio.ini).

### Example Teensy 4.1 target build result

After installing PlatformIO, run:

```sh
make check-tools
make build
```

A successful build produces artifacts similar to:

```text
.pio/build/teensy41/firmware.hex
.pio/build/teensy41/firmware.elf
```

Example from the first successful PlatformIO build:

```text
PlatformIO Core:          6.1.19
Teensy platform:          5.2.0
arm-none-eabi toolchain:  15.2.1
Arduino-Teensy framework: 1.162.0

FLASH: code 15,636 + data 9,128 + headers 9,024
RAM1:  variables 11,904 + code 13,080 + pad 19,688
RAM2:  variables 1,632
```

These values are illustrative, not contractual. They will change as the firmware
evolves. The important acceptance criterion is that `make build` completes
successfully for the `teensy41` target.

Warnings from the upstream Teensy/Arduino framework may appear. Project-owned
warnings should be fixed or consciously documented.

### Arduino CLI (second frontend)

The same canonical library also builds under the **Arduino CLI** (not the Arduino
IDE), producing identical firmware. It selects USB Raw HID via `--board-options
usb=rawhid` and compiles the shared `lib/TeensyRs485Bridge` with GNU C++20:

```bash
make arduino-build     # compile the sketch against the canonical library
make arduino-upload    # build + flash a connected Teensy 4.1
make build-all         # build BOTH frontends (PlatformIO + Arduino CLI)
```

The Arduino composition root is
[`arduino/teensy_classic_rs485/teensy_classic_rs485.ino`](arduino/teensy_classic_rs485/teensy_classic_rs485.ino)
— a thin wiring layer with no duplicated logic (both frontends compile
`lib/TeensyRs485Bridge`). **The Arduino IDE is not supported.**

### Host-side codec test (no Teensy toolchain)

The shared kernel, codec, PADIL bit layer, and bridge controller are all
host-testable with no Teensy toolchain. Easiest is `make test`:

```bash
make test
# == Core / FixedQueue ==   32 checks, 0 failures
# == USB codec ==           42 checks, 0 failures
# == PADIL bit layer ==     41 checks, 0 failures
# == BridgeController ==    62 checks, 0 failures   (177 total)
```

---

## Bring-up procedure

1. **Bench-check electrical first.** Confirm the RS-485 RX path is level-shifted
   to ≤ 3.3 V (or the transceiver runs at 3.3 V). Verify DE//RE wiring against
   `Config.hpp` and `kRs485DeReShared`.
2. **Flash and confirm liveness.** The status LED (pin 13) blinks at the status
   period (~1 s). The host should see periodic Status frames. The transfer LED
   (pin 35) pulses on a successful PADIL transfer; the debug/error LED (pin 34)
   pulses on a decode/framing/overflow error.
3. **Verify direction control** with a scope on DE/(/RE): default LOW (receive),
   HIGH only during transmit, back LOW immediately after.
4. **Exercise USB → RS-485.** Send a PADIL frame from the host; confirm an ACK
   comes back and a scope shows SOM + payload on TX at the selected bit period.
5. **Exercise RS-485 → USB.** Feed a known PADIL message in; confirm a PADIL
   frame arrives at the host with the right 27-byte payload.
6. **Verify timing** against [`docs/HARDWARE_VALIDATION.md`](docs/HARDWARE_VALIDATION.md)
   — especially the MDRP 8 µs path.

---

## Architecture (module map)

```
main.cpp                 composition root: owns the adapters, wires the bridge
 └─ BridgeController<Usb,Line,Platform>   application bridge (header-only template,
     │                                     Arduino-free): counters, queues, ACK
     │                                     policy, backpressure, numbering  ← host-tested
     ├─ UsbTransport      : UsbPort        RawHID send/recv (only usb_rawhid_* caller)
     │   └─ UsbProtocol   frame codec: encode/decode + big-endian helpers   ← host-tested
     ├─ PadilLineCodec    : LinePort       hardware glue: ISR edge capture, DWT, timer TX
     │   └─ PadilBitLayer differential-Manchester decode + TX schedule       ← host-tested
     ├─ Rs485Phy          DE//RE direction + raw RX/TX pin I/O (used by the codec)
     └─ TeensyPlatform    : PlatformPort   micros, status LED, CPU temperature
Core.hpp                 Result / Option / FixedQueue (header-only)
Domain.hpp               value types: PadilMessage, UsbFrame, Outbound/Hostbound, status
Config.hpp               all pins, timing, queue sizes, service periods, line code
```

The bridge depends on its ports as exact, `noexcept` C++20 concepts (`UsbPort`,
`LinePort`, `PlatformPort` in `Ports.hpp`), not concrete types — so
`BridgeController`, `UsbProtocol`, `PadilBitLayer`, `Domain`, and `Core` are all
Arduino-free and unit-testable on the host. The concrete adapters and the
composition root are the only files that touch the Teensy core.

For the ISR/main/timer **execution-context ownership map** and the concurrency
design, see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) and the ADRs in
[`docs/decisions/`](docs/decisions/); for the **functional error-handling model**
(Result/Option, the layered boundary rule, and how to extend it) see
[`docs/ERROR_HANDLING.md`](docs/ERROR_HANDLING.md); for on-device debugging (RawHID,
no serial monitor) see [`docs/DEBUGGING.md`](docs/DEBUGGING.md).

---

## Known limitations

- **The PADIL line code is implemented as differential Manchester** (matching the
  POC: boundary transition every cell + mid-cell transition for `0`; idle 0xAA;
  SOM 0xAA 0xCC; 27-byte payload). This is the default and the only host-tested
  path; NRZ is retained only behind `config::kLineCode` as an unverified
  experiment. **The convention and polarity still must be confirmed with a scope**
  — see [`docs/HARDWARE_VALIDATION.md`](docs/HARDWARE_VALIDATION.md).
- **MDRP transmit** ticks the `IntervalTimer` at **half** the bit period (4 µs,
  ~250 kHz) because differential Manchester needs half-cell resolution. Feasible
  on Teensy 4.1 but must be verified under load.
- **ACK is sent after physical RS-485 transmit completion** (not on queue
  acceptance), and the bridge paces one message at a time (it holds the next
  transmit until the prior ACK is delivered). If the host does not gate on ACKs,
  this can be relaxed.
- **Under sustained USB backpressure**, decoded messages are retained and retried
  (nothing is lost to transient failures); only a full to-host queue drops the
  newest message (`to_host_overflows`).
- **No host status *request*.** Status is emitted periodically; there is no
  `TOM=3` inbound request (the protocol does not define one).
- **CPU temperature** relies on `tempmonGetTemp()` (Teensy 4.x). Build with
  `-D BRIDGE_HAS_CPU_TEMP=0` on a target without it; the sentinel is emitted.
- This slice does not implement ret/echo suppression assumptions beyond gating
  the edge ISR while transmitting; confirm the transceiver/bus echo behavior.

---

## Copyright & License

**Copyright** © 2026 RTX/Raytheon, All Rights Reserved.
**Author** Michael Gardner.
**License** Proprietary to RTX/Raytheon. A more complete proprietary license statement is TBD.
